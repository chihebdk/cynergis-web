export type BaseEdgeData = {
  properties: {
    hasFocus: boolean | undefined;
    isError?: boolean;
    isSubflowStart?: boolean;
  };
};

export type WorkflowEdgeData = BaseEdgeData & {};
