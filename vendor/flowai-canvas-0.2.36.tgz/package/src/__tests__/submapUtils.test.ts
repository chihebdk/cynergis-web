import { describe, it, expect } from "vitest";
import {
  getSubmapNodeId,
  getSubmapStartMarkerId,
  getSubmapEndMarkerId,
  getSubmapGroupNodeId,
  extractSubmapInstanceId,
  buildSubmapNode,
  buildSubmapStartMarker,
  buildSubmapEndMarker,
  buildSubmapGroupNode,
  buildCollapsedEdges,
  buildExpandedEdges,
  computeCollapseSubmap,
  getEdgesForNodes,
  pickSubmapColorIndex,
  getSubmapColor,
  SUBMAP_COLOR_COUNT,
} from "../utils/submapUtils";
import type { SubmapModel as Submap } from "../CanvasProvider";
import { makeNode, makeEdge, makeChain } from "./helpers";

// Use hyphen-free IDs that match real cuid2 format
const SID = "submapabcdef";
const IID = "instxyz12345";

// ─── ID helpers ───────────────────────────────────────────────────

describe("ID helpers", () => {
  it("getSubmapNodeId returns correct format", () => {
    expect(getSubmapNodeId(SID, IID)).toBe(`submap-${SID}-${IID}`);
  });

  it("getSubmapStartMarkerId returns correct format", () => {
    expect(getSubmapStartMarkerId(SID, IID)).toBe(`submap-start-${SID}-${IID}`);
  });

  it("getSubmapEndMarkerId returns correct format", () => {
    expect(getSubmapEndMarkerId(SID, IID)).toBe(`submap-end-${SID}-${IID}`);
  });

  it("getSubmapGroupNodeId returns correct format", () => {
    expect(getSubmapGroupNodeId(SID, IID)).toBe(`submap-group-${SID}-${IID}`);
  });

  it("extractSubmapInstanceId extracts instanceId from SubmapNode id", () => {
    expect(extractSubmapInstanceId(getSubmapNodeId(SID, IID))).toBe(IID);
  });

  it("extractSubmapInstanceId extracts instanceId from StartMarker id", () => {
    expect(extractSubmapInstanceId(getSubmapStartMarkerId(SID, IID))).toBe(IID);
  });

  it("extractSubmapInstanceId extracts instanceId from EndMarker id", () => {
    expect(extractSubmapInstanceId(getSubmapEndMarkerId(SID, IID))).toBe(IID);
  });

  it("extractSubmapInstanceId extracts instanceId from GroupNode id", () => {
    expect(extractSubmapInstanceId(getSubmapGroupNodeId(SID, IID))).toBe(IID);
  });

  it("extractSubmapInstanceId returns undefined for non-submap ids", () => {
    expect(extractSubmapInstanceId("regular-node-id")).toBeUndefined();
  });
});

// ─── Node builders ────────────────────────────────────────────────

describe("buildSubmapNode", () => {
  const node = buildSubmapNode(SID, IID, "My Submap", { x: 10, y: 20 });

  it("uses instance-scoped id", () => {
    expect(node.id).toBe(getSubmapNodeId(SID, IID));
  });

  it("type is SubmapNode", () => {
    expect(node.type).toBe("SubmapNode");
  });

  it("data contains submapId, submapInstanceId and name", () => {
    expect(node.data.submapId).toBe(SID);
    expect(node.data.submapInstanceId).toBe(IID);
    expect(node.data.name).toBe("My Submap");
  });

  it("position is preserved", () => {
    expect(node.position).toEqual({ x: 10, y: 20 });
  });
});

describe("buildSubmapStartMarker", () => {
  const marker = buildSubmapStartMarker(SID, IID, "My Submap", { x: 0, y: 0 });

  it("type is SubmapStartNode", () => {
    expect(marker.type).toBe("SubmapStartNode");
  });

  it("id is instance-scoped", () => {
    expect(marker.id).toBe(getSubmapStartMarkerId(SID, IID));
  });

  it("label includes Start", () => {
    expect((marker.data as any).label).toContain("Start");
  });

  it("is not draggable", () => {
    expect(marker.draggable).toBe(false);
  });
});

describe("buildSubmapEndMarker", () => {
  const marker = buildSubmapEndMarker(SID, IID, "My Submap", { x: 0, y: 0 });

  it("type is SubmapEndNode", () => {
    expect(marker.type).toBe("SubmapEndNode");
  });

  it("id is instance-scoped", () => {
    expect(marker.id).toBe(getSubmapEndMarkerId(SID, IID));
  });

  it("label includes End", () => {
    expect((marker.data as any).label).toContain("End");
  });
});

describe("buildSubmapGroupNode", () => {
  const group = buildSubmapGroupNode(SID, IID, "My Submap", ["n1", "n2"]);

  it("type is SubmapGroupNode", () => {
    expect(group.type).toBe("SubmapGroupNode");
  });

  it("id is instance-scoped", () => {
    expect(group.id).toBe(getSubmapGroupNodeId(SID, IID));
  });

  it("data contains memberNodeIds", () => {
    expect((group.data as any).memberNodeIds).toEqual(["n1", "n2"]);
  });

  it("is not draggable or selectable", () => {
    expect(group.draggable).toBe(false);
    expect(group.selectable).toBe(false);
  });
});

// ─── Edge builders ────────────────────────────────────────────────

describe("buildCollapsedEdges", () => {
  const submapNodeId = getSubmapNodeId(SID, IID);

  it("returns empty array if no incoming and no outgoing", () => {
    const edges = buildCollapsedEdges(SID, IID, undefined, []);
    expect(edges).toHaveLength(0);
  });

  it("creates parent→SubmapNode edge from incomingToStart", () => {
    const incoming = makeEdge("parent", "start");
    const edges = buildCollapsedEdges(SID, IID, incoming, []);
    expect(edges).toHaveLength(1);
    expect(edges[0].source).toBe("parent");
    expect(edges[0].target).toBe(submapNodeId);
  });

  it("creates SubmapNode→children edges from outgoingFromEnd", () => {
    const out1 = makeEdge("end", "childA");
    const out2 = makeEdge("end", "childB");
    const edges = buildCollapsedEdges(SID, IID, undefined, [out1, out2]);
    expect(edges).toHaveLength(2);
    expect(edges.every((e) => e.source === submapNodeId)).toBe(true);
    expect(edges.map((e) => e.target).sort()).toEqual(["childA", "childB"].sort());
  });

  it("creates both incoming and outgoing edges together", () => {
    const incoming = makeEdge("parent", "start");
    const outgoing = [makeEdge("end", "childA")];
    const edges = buildCollapsedEdges(SID, IID, incoming, outgoing);
    expect(edges).toHaveLength(2);
  });
});

describe("buildExpandedEdges", () => {
  const submap: Submap = {
    id: SID,
    name: "Test",
    startNodeId: "n-start",
    endNodeId: "n-end",
    collapsed: false,
  };
  const startMarkerId = getSubmapStartMarkerId(SID, IID);
  const endMarkerId = getSubmapEndMarkerId(SID, IID);

  it("builds parent→startMarker and startMarker→startNode edges when incoming present", () => {
    const incoming = makeEdge("parent", getSubmapNodeId(SID, IID));
    const edges = buildExpandedEdges(submap, IID, incoming, []);
    const targets = edges.map((e) => e.target);
    expect(targets).toContain(startMarkerId);
    expect(targets).toContain("n-start");
  });

  it("always builds endNode→endMarker edge", () => {
    const edges = buildExpandedEdges(submap, IID, undefined, []);
    expect(edges.some((e) => e.source === "n-end" && e.target === endMarkerId)).toBe(true);
  });

  it("builds endMarker→children edges from outgoing", () => {
    const outgoing = [makeEdge(getSubmapNodeId(SID, IID), "childA")];
    const edges = buildExpandedEdges(submap, IID, undefined, outgoing);
    expect(edges.some((e) => e.source === endMarkerId && e.target === "childA")).toBe(true);
  });
});

// ─── getEdgesForNodes ─────────────────────────────────────────────

describe("getEdgesForNodes", () => {
  it("returns edge IDs where source or target is in nodeIds", () => {
    const edges = [
      makeEdge("a", "b"),
      makeEdge("b", "c"),
      makeEdge("c", "d"),
    ];
    const result = getEdgesForNodes(edges, new Set(["b"]));
    expect([...result].sort()).toEqual(["a=>b", "b=>c"].sort());
  });

  it("returns empty set if no edges touch nodeIds", () => {
    const edges = [makeEdge("a", "b")];
    const result = getEdgesForNodes(edges, new Set(["z"]));
    expect(result.size).toBe(0);
  });
});

// ─── computeCollapseSubmap ────────────────────────────────────────

describe("computeCollapseSubmap", () => {
  const submap: Submap = {
    id: SID,
    name: "Test Submap",
    startNodeId: "n1",
    endNodeId: "n2",
    collapsed: false,
  };

  it("returns null if start marker is not in nodes (nothing to collapse)", () => {
    const { nodes, edges } = makeChain(["n1", "n2"]);
    // No markers present at all — but computeCollapseSubmap uses startMarker position only as fallback
    // It should still produce a result with fallback position
    const result = computeCollapseSubmap(submap, IID, nodes, edges);
    // Chain exists so result should be non-null
    expect(result).not.toBeNull();
  });

  it("nodesToRemove includes chain nodes and all submap-specific nodes", () => {
    const { nodes, edges } = makeChain(["n1", "n2"]);
    const result = computeCollapseSubmap(submap, IID, nodes, edges)!;
    expect(result.nodesToRemove.has("n1")).toBe(true);
    expect(result.nodesToRemove.has("n2")).toBe(true);
    expect(result.nodesToRemove.has(getSubmapStartMarkerId(SID, IID))).toBe(true);
    expect(result.nodesToRemove.has(getSubmapEndMarkerId(SID, IID))).toBe(true);
    expect(result.nodesToRemove.has(getSubmapGroupNodeId(SID, IID))).toBe(true);
  });

  it("submapNode has correct id", () => {
    const { nodes, edges } = makeChain(["n1", "n2"]);
    const result = computeCollapseSubmap(submap, IID, nodes, edges)!;
    expect(result.submapNode.id).toBe(getSubmapNodeId(SID, IID));
  });

  it("collapsedEdges connect parent→SubmapNode when incoming exists", () => {
    const { nodes, edges } = makeChain(["parent", "n1", "n2", "child"]);
    // Add the start marker to nodes so incoming edge can be found
    const startMarkerId = getSubmapStartMarkerId(SID, IID);
    nodes.push(makeNode(startMarkerId));
    edges.push(makeEdge("parent", startMarkerId));
    // Rebuild so startMarker edge is the incoming-to-start-marker
    const result = computeCollapseSubmap(submap, IID, nodes, edges)!;
    const submapNodeId = getSubmapNodeId(SID, IID);
    expect(result.collapsedEdges.some((e) => e.source === "parent" && e.target === submapNodeId)).toBe(true);
  });
});

// ─── Color helpers ────────────────────────────────────────────────

describe("pickSubmapColorIndex", () => {
  it("returns a valid index in range [0, SUBMAP_COLOR_COUNT)", () => {
    const idx = pickSubmapColorIndex([]);
    expect(idx).toBeGreaterThanOrEqual(0);
    expect(idx).toBeLessThan(SUBMAP_COLOR_COUNT);
  });

  it("avoids already-used indices when possible", () => {
    const used = Array.from({ length: SUBMAP_COLOR_COUNT - 1 }, (_, i) => i);
    const idx = pickSubmapColorIndex(used);
    expect(idx).toBe(SUBMAP_COLOR_COUNT - 1);
  });

  it("falls back to any index if all are used", () => {
    const used = Array.from({ length: SUBMAP_COLOR_COUNT }, (_, i) => i);
    const idx = pickSubmapColorIndex(used);
    expect(idx).toBeGreaterThanOrEqual(0);
    expect(idx).toBeLessThan(SUBMAP_COLOR_COUNT);
  });
});

describe("getSubmapColor", () => {
  it("returns a color object with required fields", () => {
    const color = getSubmapColor(SID, 0);
    expect(color).toHaveProperty("bg");
    expect(color).toHaveProperty("border");
    expect(color).toHaveProperty("labelColor");
    expect(color).toHaveProperty("nameColor");
    expect(color).toHaveProperty("containerBg");
  });

  it("is deterministic for the same submapId and colorIndex", () => {
    expect(getSubmapColor(SID, 2)).toEqual(getSubmapColor(SID, 2));
  });

  it("falls back to hash-based color when colorIndex is undefined", () => {
    const color = getSubmapColor(SID);
    expect(color).toHaveProperty("bg");
  });
});
