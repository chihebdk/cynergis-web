/**
 * Shared test helpers — build minimal Node/Edge fixtures without any React/RF dependency.
 */
import type { Node, Edge } from "@xyflow/react";

export function makeNode(id: string, extra?: Partial<Node>): Node {
  return {
    id,
    type: "EventNode",
    position: { x: 0, y: 0 },
    data: { properties: { layoutCategory: "hierarchy" } },
    ...extra,
  };
}

export function makeEdge(source: string, target: string, extra?: Partial<Edge>): Edge {
  return {
    id: `${source}=>${target}`,
    source,
    target,
    data: { properties: { isError: false } },
    ...extra,
  };
}

/**
 * Build a linear chain:  root → n1 → n2 → ... → nN
 * Returns { nodes, edges } where nodes[0] is root.
 */
export function makeChain(ids: string[]): { nodes: Node[]; edges: Edge[] } {
  const nodes = ids.map((id) => makeNode(id));
  const edges: Edge[] = [];
  for (let i = 0; i < ids.length - 1; i++) {
    edges.push(makeEdge(ids[i], ids[i + 1]));
  }
  return { nodes, edges };
}
