import { describe, it, expect } from "vitest";
import {
  addNode,
  getDescendants,
  getChainBetween,
  isEligibleSubmapEnd,
  getSiblings,
  swapNodes,
} from "../utils";
import { makeNode, makeEdge, makeChain } from "./helpers";

// ─── addNode ──────────────────────────────────────────────────────

describe("addNode", () => {
  it("prepends the new node to the nodes array", () => {
    const { nodes, edges } = makeChain(["root"]);
    const child = makeNode("child1");
    addNode("root", child, nodes, edges);
    expect(nodes[0].id).toBe("child1");
  });

  it("appends an edge from parent to new node", () => {
    const { nodes, edges } = makeChain(["root"]);
    const child = makeNode("child1");
    addNode("root", child, nodes, edges);
    const edge = edges.find((e) => e.source === "root" && e.target === "child1");
    expect(edge).toBeDefined();
    expect(edge?.id).toBe("root=>child1");
  });

  it("sets isError=true on edge when node type is ErrorNode", () => {
    const { nodes, edges } = makeChain(["root"]);
    const errNode = makeNode("err1", { type: "ErrorNode" });
    addNode("root", errNode, nodes, edges);
    const edge = edges.find((e) => e.target === "err1");
    expect((edge?.data as any)?.properties?.isError).toBe(true);
  });

  it("does not affect other existing nodes", () => {
    const { nodes, edges } = makeChain(["root", "existing"]);
    const child = makeNode("new");
    addNode("root", child, nodes, edges);
    expect(nodes.some((n) => n.id === "existing")).toBe(true);
  });
});

// ─── getDescendants ───────────────────────────────────────────────

describe("getDescendants", () => {
  it("returns empty array for a leaf node", () => {
    const { nodes, edges } = makeChain(["root"]);
    expect(getDescendants("root", nodes, edges)).toHaveLength(0);
  });

  it("returns direct child", () => {
    const { nodes, edges } = makeChain(["root", "child"]);
    const desc = getDescendants("root", nodes, edges);
    expect(desc.map((n) => n.id)).toContain("child");
  });

  it("returns all descendants in a linear chain", () => {
    const { nodes, edges } = makeChain(["a", "b", "c", "d"]);
    const desc = getDescendants("a", nodes, edges);
    expect(desc.map((n) => n.id)).toEqual(["b", "c", "d"]);
  });

  it("handles branching tree", () => {
    const nodes = [makeNode("root"), makeNode("c1"), makeNode("c2"), makeNode("gc1")];
    const edges = [
      makeEdge("root", "c1"),
      makeEdge("root", "c2"),
      makeEdge("c1", "gc1"),
    ];
    const desc = getDescendants("root", nodes, edges).map((n) => n.id).sort();
    expect(desc).toEqual(["c1", "c2", "gc1"].sort());
  });

  it("does not include the node itself", () => {
    const { nodes, edges } = makeChain(["root", "child"]);
    const desc = getDescendants("root", nodes, edges);
    expect(desc.map((n) => n.id)).not.toContain("root");
  });
});

// ─── getChainBetween ──────────────────────────────────────────────

describe("getChainBetween", () => {
  it("returns empty array if start node not found", () => {
    const { nodes, edges } = makeChain(["a", "b"]);
    expect(getChainBetween("missing", "b", nodes, edges)).toHaveLength(0);
  });

  it("returns [start] when start equals end (no descendants beyond end)", () => {
    const { nodes, edges } = makeChain(["a", "b"]);
    const chain = getChainBetween("a", "b", nodes, edges);
    // start=a, end=b. descendants of a = [b]. beyond b = []. chain = [a, b]
    expect(chain.map((n) => n.id)).toEqual(["a", "b"]);
  });

  it("returns chain from start to end inclusive, excluding beyond-end nodes", () => {
    const { nodes, edges } = makeChain(["a", "b", "c", "d"]);
    const chain = getChainBetween("a", "c", nodes, edges);
    // beyond c = [d]. chain = [a, b, c]
    expect(chain.map((n) => n.id)).toEqual(["a", "b", "c"]);
  });

  it("chain of single node when end has no descendants and start=end", () => {
    const { nodes, edges } = makeChain(["a", "b"]);
    const chain = getChainBetween("b", "b", nodes, edges);
    expect(chain.map((n) => n.id)).toContain("b");
  });
});

// ─── isEligibleSubmapEnd ──────────────────────────────────────────

describe("isEligibleSubmapEnd", () => {
  it("returns false if node is not a descendant of start", () => {
    const { nodes, edges } = makeChain(["a", "b"]);
    expect(isEligibleSubmapEnd("a", "b", nodes, edges)).toBe(false);
  });

  it("returns true for a descendant with no siblings (linear chain)", () => {
    const { nodes, edges } = makeChain(["a", "b", "c"]);
    expect(isEligibleSubmapEnd("b", "a", nodes, edges)).toBe(true);
    expect(isEligibleSubmapEnd("c", "a", nodes, edges)).toBe(true);
  });

  it("returns false if node has siblings", () => {
    const nodes = [makeNode("a"), makeNode("b"), makeNode("c")];
    const edges = [makeEdge("a", "b"), makeEdge("a", "c")];
    // b has sibling c
    expect(isEligibleSubmapEnd("b", "a", nodes, edges)).toBe(false);
  });

  it("returns false for a node not in the graph", () => {
    const { nodes, edges } = makeChain(["a", "b"]);
    expect(isEligibleSubmapEnd("z", "a", nodes, edges)).toBe(false);
  });
});

// ─── getSiblings ──────────────────────────────────────────────────

describe("getSiblings", () => {
  it("returns null for root node (no parent)", () => {
    const { nodes, edges } = makeChain(["root", "child"]);
    const root = nodes.find((n) => n.id === "root")!;
    expect(getSiblings(root, nodes, edges)).toBeNull();
  });

  it("returns empty array for only-child", () => {
    const { nodes, edges } = makeChain(["root", "child"]);
    const child = nodes.find((n) => n.id === "child")!;
    expect(getSiblings(child, nodes, edges)).toHaveLength(0);
  });

  it("returns other siblings but not self", () => {
    const nodes = [makeNode("root"), makeNode("c1"), makeNode("c2")];
    const edges = [makeEdge("root", "c1"), makeEdge("root", "c2")];
    const c1 = nodes.find((n) => n.id === "c1")!;
    const siblings = getSiblings(c1, nodes, edges)!;
    expect(siblings.map((n) => n.id)).toEqual(["c2"]);
  });
});

// ─── swapNodes ────────────────────────────────────────────────────

describe("swapNodes", () => {
  it("swaps two nodes by position", () => {
    const nodes = [makeNode("a"), makeNode("b"), makeNode("c")];
    swapNodes(nodes, nodes[0], nodes[2]);
    expect(nodes[0].id).toBe("c");
    expect(nodes[2].id).toBe("a");
    expect(nodes[1].id).toBe("b");
  });

  it("throws if either node is not found", () => {
    const nodes = [makeNode("a"), makeNode("b")];
    const ghost = makeNode("ghost");
    expect(() => swapNodes(nodes, nodes[0], ghost)).toThrow();
  });
});
