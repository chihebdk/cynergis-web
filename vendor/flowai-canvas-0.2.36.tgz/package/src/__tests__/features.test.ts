/**
 * Feature-level tests.
 *
 * These tests exercise the pure canvas logic (utility functions + submap utils)
 * without mounting React components or mocking React Flow hooks.
 * They simulate what the hooks do by operating directly on Node/Edge arrays.
 */
import { describe, it, expect, beforeEach } from "vitest";
import type { Node, Edge } from "@xyflow/react";
import {
  addNode,
  getDescendants,
  getChainBetween,
  isEligibleSubmapEnd,
} from "../utils";
import {
  buildSubmapNode,
  buildSubmapStartMarker,
  buildSubmapEndMarker,
  buildSubmapGroupNode,
  buildCollapsedEdges,
  buildExpandedEdges,
  computeCollapseSubmap,
  getSubmapNodeId,
  getSubmapStartMarkerId,
  getSubmapEndMarkerId,
  getSubmapGroupNodeId,
  getEdgesForNodes,
} from "../utils/submapUtils";
import type { SubmapModel as Submap } from "../CanvasProvider";
import { makeNode, makeEdge, makeChain } from "./helpers";

// ─── Feature 1: Adding and deleting nodes ─────────────────────────

describe("Feature 1 — Adding nodes", () => {
  it("adds a child node and connecting edge to the canvas", () => {
    const nodes: Node[] = [makeNode("root")];
    const edges: Edge[] = [];
    const child = makeNode("child");

    addNode("root", child, nodes, edges);

    expect(nodes.some((n) => n.id === "child")).toBe(true);
    expect(edges.some((e) => e.source === "root" && e.target === "child")).toBe(true);
  });

  it("adds multiple children to the same parent", () => {
    const nodes: Node[] = [makeNode("root")];
    const edges: Edge[] = [];

    addNode("root", makeNode("c1"), nodes, edges);
    addNode("root", makeNode("c2"), nodes, edges);
    addNode("root", makeNode("c3"), nodes, edges);

    const children = edges.filter((e) => e.source === "root").map((e) => e.target);
    expect(children.sort()).toEqual(["c1", "c2", "c3"].sort());
  });

  it("adds a grandchild two levels deep", () => {
    const nodes: Node[] = [makeNode("root")];
    const edges: Edge[] = [];

    addNode("root", makeNode("child"), nodes, edges);
    addNode("child", makeNode("grandchild"), nodes, edges);

    expect(edges.some((e) => e.source === "child" && e.target === "grandchild")).toBe(true);
  });
});

describe("Feature 1 — Deleting nodes", () => {
  it("removing a node and its edge disconnects it from parent", () => {
    const { nodes, edges } = makeChain(["root", "child", "grandchild"]);

    // Simulate deleteAll: remove child + grandchild + their edges
    const toDelete = new Set(["child", "grandchild"]);
    const edgesToRemove = getEdgesForNodes(edges, toDelete);

    const newNodes = nodes.filter((n) => !toDelete.has(n.id));
    const newEdges = edges.filter((e) => !edgesToRemove.has(e.id));

    expect(newNodes.map((n) => n.id)).toEqual(["root"]);
    expect(newEdges).toHaveLength(0);
  });

  it("getDescendants returns all nodes that should be deleted in subtree", () => {
    const nodes = [makeNode("root"), makeNode("c1"), makeNode("c2"), makeNode("gc1")];
    const edges = [
      makeEdge("root", "c1"),
      makeEdge("root", "c2"),
      makeEdge("c1", "gc1"),
    ];
    const desc = getDescendants("root", nodes, edges).map((n) => n.id).sort();
    expect(desc).toEqual(["c1", "c2", "gc1"].sort());
  });

  it("deleting only the target node leaves its children orphaned (confirmDelete behaviour)", () => {
    const { nodes, edges } = makeChain(["root", "child", "grandchild"]);

    // Remove only "child" node and its direct edges
    const toDelete = new Set(["child"]);
    const edgesToRemove = getEdgesForNodes(edges, toDelete);
    const newNodes = nodes.filter((n) => !toDelete.has(n.id));
    const newEdges = edges.filter((e) => !edgesToRemove.has(e.id));

    // grandchild still exists but has no parent edge
    expect(newNodes.some((n) => n.id === "grandchild")).toBe(true);
    expect(newEdges.some((e) => e.target === "grandchild")).toBe(false);
  });
});

// ─── Feature 2: Creating a submap ─────────────────────────────────

describe("Feature 2 — Creating a submap", () => {
  const SID = "submap-1";
  const IID = "instance-1";

  it("isEligibleSubmapEnd is true for linear chain", () => {
    const { nodes, edges } = makeChain(["a", "b", "c"]);
    expect(isEligibleSubmapEnd("b", "a", nodes, edges)).toBe(true);
    expect(isEligibleSubmapEnd("c", "a", nodes, edges)).toBe(true);
  });

  it("isEligibleSubmapEnd is false when node has siblings", () => {
    const nodes = [makeNode("a"), makeNode("b"), makeNode("c")];
    const edges = [makeEdge("a", "b"), makeEdge("a", "c")];
    expect(isEligibleSubmapEnd("b", "a", nodes, edges)).toBe(false);
  });

  it("getChainBetween returns correct nodes for submap boundary", () => {
    const { nodes, edges } = makeChain(["a", "b", "c", "d"]);
    const chain = getChainBetween("b", "c", nodes, edges);
    expect(chain.map((n) => n.id)).toEqual(["b", "c"]);
    // d is beyond c, should not be included
    expect(chain.some((n) => n.id === "d")).toBe(false);
  });

  it("confirmSubmap: chain nodes are replaced by a single SubmapNode", () => {
    const { nodes, edges } = makeChain(["parent", "n1", "n2", "child"]);
    const chainIds = new Set(["n1", "n2"]);

    const incomingToStart = edges.find((e) => e.target === "n1");
    const outgoingFromEnd = edges.filter((e) => e.source === "n2");
    const submapNode = buildSubmapNode(SID, IID, "My Submap", { x: 0, y: 0 });
    const newEdges = buildCollapsedEdges(SID, IID, incomingToStart, outgoingFromEnd);

    const internalEdgeIds = new Set(
      edges.filter((e) => chainIds.has(e.source) && chainIds.has(e.target)).map((e) => e.id)
    );
    const edgesToRemove = new Set([
      ...(incomingToStart ? [incomingToStart.id] : []),
      ...outgoingFromEnd.map((e) => e.id),
      ...internalEdgeIds,
    ]);

    const finalNodes = [...nodes.filter((n) => !chainIds.has(n.id)), submapNode];
    const finalEdges = [...edges.filter((e) => !edgesToRemove.has(e.id)), ...newEdges];

    // Chain nodes removed
    expect(finalNodes.some((n) => n.id === "n1")).toBe(false);
    expect(finalNodes.some((n) => n.id === "n2")).toBe(false);
    // SubmapNode added
    expect(finalNodes.some((n) => n.id === getSubmapNodeId(SID, IID))).toBe(true);
    // parent→SubmapNode edge exists
    expect(finalEdges.some((e) => e.source === "parent" && e.target === getSubmapNodeId(SID, IID))).toBe(true);
    // SubmapNode→child edge exists
    expect(finalEdges.some((e) => e.source === getSubmapNodeId(SID, IID) && e.target === "child")).toBe(true);
  });

  it("collapsed submap data has correct submapId and submapInstanceId", () => {
    const node = buildSubmapNode(SID, IID, "My Submap", { x: 0, y: 0 });
    expect(node.data.submapId).toBe(SID);
    expect(node.data.submapInstanceId).toBe(IID);
  });
});

// ─── Feature 3: Expand / collapse a submap ────────────────────────

describe("Feature 3 — Expand a submap", () => {
  const SID = "submap-2";
  const IID = "instance-2";
  const submap: Submap = { id: SID, name: "Test", startNodeId: "n1", endNodeId: "n2", collapsed: true };

  it("expandSubmap replaces SubmapNode with start marker, member nodes, end marker, group node", () => {
    const submapNodeId = getSubmapNodeId(SID, IID);
    const nodes: Node[] = [makeNode("parent"), buildSubmapNode(SID, IID, "Test", { x: 0, y: 0 }), makeNode("child")];
    const edges: Edge[] = [makeEdge("parent", submapNodeId), makeEdge(submapNodeId, "child")];

    const position = { x: 0, y: 0 };
    const memberNodes: Node[] = [makeNode("n1"), makeNode("n2")];
    const memberEdges: Edge[] = [makeEdge("n1", "n2")];

    const incomingEdge = edges.find((e) => e.target === submapNodeId);
    const outgoingEdges = edges.filter((e) => e.source === submapNodeId);

    const markerStart = buildSubmapStartMarker(SID, IID, "Test", position);
    const markerEnd = buildSubmapEndMarker(SID, IID, "Test", position);
    const groupNode = buildSubmapGroupNode(SID, IID, "Test", memberNodes.map((n) => n.id));
    const newEdges = buildExpandedEdges(submap, IID, incomingEdge, outgoingEdges);

    const finalNodes = [
      ...nodes.filter((n) => n.id !== submapNodeId),
      markerStart,
      ...memberNodes,
      markerEnd,
      groupNode,
    ];
    const finalEdges = [
      ...edges.filter((e) => e.source !== submapNodeId && e.target !== submapNodeId),
      ...memberEdges,
      ...newEdges,
    ];

    // SubmapNode removed
    expect(finalNodes.some((n) => n.id === submapNodeId)).toBe(false);
    // Markers present
    expect(finalNodes.some((n) => n.id === getSubmapStartMarkerId(SID, IID))).toBe(true);
    expect(finalNodes.some((n) => n.id === getSubmapEndMarkerId(SID, IID))).toBe(true);
    // Group node present
    expect(finalNodes.some((n) => n.id === getSubmapGroupNodeId(SID, IID))).toBe(true);
    // Member nodes present
    expect(finalNodes.some((n) => n.id === "n1")).toBe(true);
    expect(finalNodes.some((n) => n.id === "n2")).toBe(true);
    // parent→startMarker edge
    expect(finalEdges.some((e) => e.source === "parent" && e.target === getSubmapStartMarkerId(SID, IID))).toBe(true);
    // startMarker→n1 edge
    expect(finalEdges.some((e) => e.source === getSubmapStartMarkerId(SID, IID) && e.target === "n1")).toBe(true);
    // n2→endMarker edge
    expect(finalEdges.some((e) => e.source === "n2" && e.target === getSubmapEndMarkerId(SID, IID))).toBe(true);
    // endMarker→child edge
    expect(finalEdges.some((e) => e.source === getSubmapEndMarkerId(SID, IID) && e.target === "child")).toBe(true);
  });
});

describe("Feature 3 — Collapse a submap", () => {
  const SID = "submap-3";
  const IID = "instance-3";
  const submap: Submap = { id: SID, name: "Test", startNodeId: "n1", endNodeId: "n2", collapsed: false };

  it("computeCollapseSubmap removes markers+members and inserts SubmapNode", () => {
    const startMarkerId = getSubmapStartMarkerId(SID, IID);
    const endMarkerId = getSubmapEndMarkerId(SID, IID);
    const groupNodeId = getSubmapGroupNodeId(SID, IID);

    const nodes: Node[] = [
      makeNode("parent"),
      makeNode(startMarkerId),
      makeNode("n1"),
      makeNode("n2"),
      makeNode(endMarkerId),
      makeNode(groupNodeId),
      makeNode("child"),
    ];
    const edges: Edge[] = [
      makeEdge("parent", startMarkerId),
      makeEdge(startMarkerId, "n1"),
      makeEdge("n1", "n2"),
      makeEdge("n2", endMarkerId),
      makeEdge(endMarkerId, "child"),
    ];

    const result = computeCollapseSubmap(submap, IID, nodes, edges)!;

    expect(result).not.toBeNull();
    expect(result.nodesToRemove.has("n1")).toBe(true);
    expect(result.nodesToRemove.has("n2")).toBe(true);
    expect(result.nodesToRemove.has(startMarkerId)).toBe(true);
    expect(result.nodesToRemove.has(endMarkerId)).toBe(true);
    expect(result.nodesToRemove.has(groupNodeId)).toBe(true);

    const submapNodeId = getSubmapNodeId(SID, IID);
    expect(result.submapNode.id).toBe(submapNodeId);
    expect(result.collapsedEdges.some((e) => e.source === "parent" && e.target === submapNodeId)).toBe(true);
    expect(result.collapsedEdges.some((e) => e.source === submapNodeId && e.target === "child")).toBe(true);
  });
});

// ─── Feature 4: Add node inside a submap ─────────────────────────

describe("Feature 4 — Add node inside an expanded submap", () => {
  it("adds a new member node inside the submap chain", () => {
    // Simulate an expanded submap: parent→startMarker→n1→n2→endMarker→child
    const SID = "submap-4";
    const IID = "instance-4";
    const startMarkerId = getSubmapStartMarkerId(SID, IID);
    const endMarkerId = getSubmapEndMarkerId(SID, IID);

    const nodes: Node[] = [
      makeNode("parent"),
      makeNode(startMarkerId),
      makeNode("n1"),
      makeNode("n2"),
      makeNode(endMarkerId),
      makeNode("child"),
    ];
    const edges: Edge[] = [
      makeEdge("parent", startMarkerId),
      makeEdge(startMarkerId, "n1"),
      makeEdge("n1", "n2"),
      makeEdge("n2", endMarkerId),
      makeEdge(endMarkerId, "child"),
    ];

    // Add new node "n3" as child of "n2" (inside the submap)
    const newNode = makeNode("n3");
    addNode("n2", newNode, nodes, edges);

    expect(nodes.some((n) => n.id === "n3")).toBe(true);
    expect(edges.some((e) => e.source === "n2" && e.target === "n3")).toBe(true);
  });

  it("new node inside submap is a descendant of the start node", () => {
    const SID = "submap-4b";
    const IID = "instance-4b";
    const startMarkerId = getSubmapStartMarkerId(SID, IID);

    const nodes: Node[] = [makeNode(startMarkerId), makeNode("n1")];
    const edges: Edge[] = [makeEdge(startMarkerId, "n1")];

    addNode("n1", makeNode("n2"), nodes, edges);

    const desc = getDescendants(startMarkerId, nodes, edges).map((n) => n.id);
    expect(desc).toContain("n1");
    expect(desc).toContain("n2");
  });
});

// ─── Feature 5: Children rotation with one or more submaps ────────

describe("Feature 5 — Children rotation with submaps", () => {
  it("multiple SubmapNode instances for same submapId have unique node IDs", () => {
    const SID = "shared-submap";
    const IID_A = "inst-a";
    const IID_B = "inst-b";

    const nodeA = buildSubmapNode(SID, IID_A, "Shared", { x: 0, y: 0 });
    const nodeB = buildSubmapNode(SID, IID_B, "Shared", { x: 200, y: 0 });

    expect(nodeA.id).not.toBe(nodeB.id);
    expect(nodeA.data.submapId).toBe(nodeB.data.submapId);
    expect(nodeA.data.submapInstanceId).not.toBe(nodeB.data.submapInstanceId);
  });

  it("a parent can have multiple submap instances as children", () => {
    const nodes: Node[] = [makeNode("root")];
    const edges: Edge[] = [];

    const SID = "shared-submap-2";
    const IID_A = "inst-a2";
    const IID_B = "inst-b2";

    const s1 = buildSubmapNode(SID, IID_A, "Shared", { x: 0, y: 0 });
    const s2 = buildSubmapNode(SID, IID_B, "Shared", { x: 200, y: 0 });

    addNode("root", s1, nodes, edges);
    addNode("root", s2, nodes, edges);

    const children = edges.filter((e) => e.source === "root").map((e) => e.target);
    expect(children).toContain(getSubmapNodeId(SID, IID_A));
    expect(children).toContain(getSubmapNodeId(SID, IID_B));
    expect(children).toHaveLength(2);
  });

  it("collapsing one instance does not affect the other", () => {
    const SID = "shared-submap-3";
    const IID_A = "inst-a3";
    const IID_B = "inst-b3";
    const submap: Submap = { id: SID, name: "Shared", startNodeId: "m1", endNodeId: "m2", collapsed: false };

    const startA = getSubmapStartMarkerId(SID, IID_A);
    const endA = getSubmapEndMarkerId(SID, IID_A);
    const startB = getSubmapStartMarkerId(SID, IID_B);
    const endB = getSubmapEndMarkerId(SID, IID_B);

    const nodes: Node[] = [
      makeNode("root"),
      makeNode(startA), makeNode("m1"), makeNode("m2"), makeNode(endA),
      makeNode(startB), makeNode("m1-copy"), makeNode("m2-copy"), makeNode(endB),
      makeNode("childA"), makeNode("childB"),
    ];
    const edges: Edge[] = [
      makeEdge("root", startA),
      makeEdge(startA, "m1"), makeEdge("m1", "m2"), makeEdge("m2", endA), makeEdge(endA, "childA"),
      makeEdge("root", startB),
      makeEdge(startB, "m1-copy"), makeEdge("m1-copy", "m2-copy"), makeEdge("m2-copy", endB), makeEdge(endB, "childB"),
    ];

    // Collapse only instance A
    const resultA = computeCollapseSubmap(submap, IID_A, nodes, edges)!;
    expect(resultA).not.toBeNull();

    // After collapse of A, instance B markers must still be present
    expect(resultA.nodesToRemove.has(startB)).toBe(false);
    expect(resultA.nodesToRemove.has(endB)).toBe(false);
    // Instance A markers should be removed
    expect(resultA.nodesToRemove.has(startA)).toBe(true);
    expect(resultA.nodesToRemove.has(endA)).toBe(true);
  });

  it("two different submaps can exist as siblings under the same parent", () => {
    const nodes: Node[] = [makeNode("root")];
    const edges: Edge[] = [];

    const s1 = buildSubmapNode("submap-X", "inst-x", "Submap X", { x: 0, y: 0 });
    const s2 = buildSubmapNode("submap-Y", "inst-y", "Submap Y", { x: 200, y: 0 });

    addNode("root", s1, nodes, edges);
    addNode("root", s2, nodes, edges);

    expect(nodes.some((n) => n.data?.submapId === "submap-X")).toBe(true);
    expect(nodes.some((n) => n.data?.submapId === "submap-Y")).toBe(true);
    expect(edges.filter((e) => e.source === "root")).toHaveLength(2);
  });
});
