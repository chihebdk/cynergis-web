"use client";

import { memo } from "react";
import { NodeProps, Handle, Position } from "@xyflow/react";
import { getSubmapColor } from "../utils/submapUtils";
import { useSubmapCache } from "../CanvasProvider";
import { useSubmapActions } from "../hooks/useSubmapActions";
import { CollapseSubflow } from "../components/icons";
import { Ungroup } from "lucide-react";
import { SubmapModel as Submap } from "../CanvasProvider";

type SubmapGroupNodeData = {
  submapId: string;
  submapInstanceId: string;
  name: string;
  memberNodeIds: string[];
  width?: number;
  height?: number;
};

const SubmapGroupNode = memo(({ data }: NodeProps) => {
  const { submapId, submapInstanceId, name, width, height } = data as unknown as SubmapGroupNodeData;
  const { getItem: getSubmap } = useSubmapCache();
  const { collapseSubmap, ungroupSubmap } = useSubmapActions();
  const color = getSubmapColor(submapId, (getSubmap(submapId) as Submap | undefined)?.colorIndex);

  return (
    <div
      className="submap-container rounded-lg border-2 border-dashed"
      style={
        {
          width: width || 200,
          height: height || 200,
          pointerEvents: "none",
          "--submap-bg": color.bg,
          "--submap-border": color.border,
          "--submap-label": color.labelColor,
          "--submap-container-bg": color.containerBg,
        } as React.CSSProperties
      }
    >
      <div
        className="submap-container-label absolute -top-6 left-2 text-xs font-semibold px-2 py-0.5 rounded"
        style={{ pointerEvents: "auto" }}
      >
        {name}
      </div>
      <button
        type="button"
        className="absolute right-2 -top-6 hover:scale-125 transition-transform duration-200 cursor-pointer"
        title="Collapse Submap"
        style={{ pointerEvents: "auto" }}
        onClick={(e) => {
          e.stopPropagation();
          collapseSubmap(submapId, submapInstanceId);
        }}
      >
        <CollapseSubflow width={18} color={color.labelColor} />
      </button>
      <button
        type="button"
        className="absolute right-8 -top-6 hover:scale-125 transition-transform duration-200 cursor-pointer"
        title="Ungroup Submap"
        style={{ pointerEvents: "auto" }}
        onClick={(e) => {
          e.stopPropagation();
          ungroupSubmap(submapId, submapInstanceId);
        }}
      >
        <Ungroup width={16} color={color.labelColor} />
      </button>
      <Handle type="target" position={Position.Left} style={{ visibility: "hidden" }} />
      <Handle type="source" position={Position.Right} style={{ visibility: "hidden" }} />
    </div>
  );
});

SubmapGroupNode.displayName = "SubmapGroupNode";
export default SubmapGroupNode;
