"use client";

import { memo } from "react";
import {
  BaseEdge,
  EdgeLabelRenderer,
  EdgeProps,
  Edge,
  getSmoothStepPath,
  useReactFlow,
} from "@xyflow/react";
import { EdgeToolbar } from "../controls/EdgeToolbar";
import { useEdgeTypeConfig, useCanvasConfig } from "../CanvasProvider";
import type { WorkflowEdgeData } from "../types/EdgeTypes";

const WorkflowEdgeComponent = ({
  id,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  markerEnd,
  style,
  data,
}: EdgeProps<Edge<WorkflowEdgeData>>) => {
  const { getNode, getEdge } = useReactFlow();
  const edgeConfig = useEdgeTypeConfig("WorkflowEdge");
  const canvasConfig = useCanvasConfig();
  const laneCount = canvasConfig.lanes?.show ? (canvasConfig.lanes?.titles?.length ?? 0) : 0;

  const edge = getEdge(id);
  const target = edge?.target || "";
  const draggingTarget = getNode(target)?.dragging;

  // The StartNode wraps its visible orange box in a centering div equal to the full
  // node width. The Handle sits at the wrapper's right edge, but the orange box is
  // narrower — shift sourceX left so the edge starts at the orange box's right edge.
  const sourceNode = getNode(edge?.source || "");
  const adjustedSourceX =
    sourceNode?.type === "StartNode" ? sourceX - 35 : sourceX;

  const [edgePath, labelX, labelY] = getSmoothStepPath({
    sourceX: adjustedSourceX,
    sourceY,
    sourcePosition,
    targetX,
    targetY,
    targetPosition,
    borderRadius: edgeConfig.borderRadius ?? 15,
  });

  const focused =
    data?.properties?.hasFocus === undefined || data?.properties?.hasFocus;
  const isError = data?.properties?.isError;
  return (
    <>
      <BaseEdge
        path={edgePath}
        markerEnd={edgeConfig.markerEnd ? markerEnd : undefined}
        style={{
          ...style,
          opacity: draggingTarget ? 0.2 : edgeConfig.opacity,
          stroke: isError ? "red" : edgeConfig.stroke,
          strokeWidth: edgeConfig.strokeWidth,
          strokeDasharray: focused
            ? (edgeConfig.focusedStyle === "dashed" ? "3 3" : "")
            : (edgeConfig.unfocusedStyle === "dashed" ? "3 3" : ""),
        }}
      />

      {focused && (
        <EdgeLabelRenderer>
          <div
            data-edge-id={id}
            style={{
              position: "absolute",
              transform: `translate(-50%, -50%) translate(${labelX}px, ${labelY}px)`,
              pointerEvents: "all",
              zIndex: 10,
            }}
            className="nodrag nopan group"
          >
            <div className="opacity-0 group-hover:opacity-100 transition-all duration-200">
              <EdgeToolbar id={id} toolbar={(() => {
                const items = edgeConfig.toolbar ?? [];
                if (laneCount === 0) return items;
                const targetNode = getNode(target);
                const targetDepth = (targetNode?.data as any)?.properties?.depth ?? 0;
                if (targetDepth >= laneCount - 1) {
                  return items.filter((t: string) => !["addNode", "addCondition", "addError", "addReference", "addSubflow"].includes(t));
                }
                return items;
              })()} />
            </div>
          </div>
        </EdgeLabelRenderer>
      )}
    </>
  );
};

export const WorkflowEdge = memo(WorkflowEdgeComponent);
