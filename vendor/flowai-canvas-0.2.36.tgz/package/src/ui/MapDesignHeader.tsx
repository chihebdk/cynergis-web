"use client";

import { useEventMapCache, useCanvasServices } from "../CanvasProvider";

export const MapDesignHeader = () => {
  const eventMap = useEventMapCache().selected;
  const { headerComponents } = useCanvasServices();
  const Header = headerComponents?.Header;
  const ProfileDropdown = headerComponents?.ProfileDropdown;

  const content = (
    <>
      <p className="text-lg font-medium text-gray-600">{eventMap?.name}</p>
      <div className="ml-auto flex items-center space-x-4">
        {ProfileDropdown && <ProfileDropdown />}
      </div>
    </>
  );

  if (Header) {
    return <Header className="flex justify-between">{content}</Header>;
  }

  return <header className="flex justify-between">{content}</header>;
};
