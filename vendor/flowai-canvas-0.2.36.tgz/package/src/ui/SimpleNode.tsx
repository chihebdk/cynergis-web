"use client";

import { memo } from "react";
import { BaseNode } from "./BaseNode";
import Handles from "./Handles";
import { baseNodeSize } from "../config/settings";
import { useNodeCache } from "../CanvasProvider";
import { useNodeTypeConfig } from "../CanvasProvider";
import { ReferenceListPopover } from "../controls/ReferenceListPopover";
import { useReferenceOriginNavigation } from "../hooks/useReferenceNavigation";
import { IconGoToOriginal } from "../icons/index.js";
import type { BaseNodeData } from "../types/NodeTypes";

type SimpleNodeProps = {
  id: string;
  data?: BaseNodeData;
};

const SimpleNodeComponent: React.FC<SimpleNodeProps> = ({ id, data }) => {
  const { getItem, selected: selectedNode } = useNodeCache();
  const node = getItem(id);
  const selected = node?.id === selectedNode?.id;
  const nodeConfig = useNodeTypeConfig("SimpleNode");

  const { referenceNodes, referenceCount, showBackButton, goBackToRef } =
    useReferenceOriginNavigation(id);

  return (
    <BaseNode id={id} inFocus={data?.properties?.hasFocus} isDragged={data?.properties?.dragging} options={{ toolbar: nodeConfig?.toolbar, contextMenuItems: nodeConfig?.contextMenu, decorators: nodeConfig?.decorators }}>
      <div className="flex items-center relative">
        {showBackButton && (
          <button
            type="button"
            className="absolute -top-5 right-0 hover:scale-125 transition-transform duration-200 cursor-pointer text-gray-500"
            title="Back to reference node"
            onClick={goBackToRef}
          >
            <IconGoToOriginal width={16} style={{ transform: "scaleX(-1)" }} />
          </button>
        )}
        {referenceCount > 0 && (
          <ReferenceListPopover targetId={id} referenceNodes={referenceNodes}>
            <div
              className="absolute left-[-28px] top-0 flex flex-col items-center z-10 cursor-pointer"
              title={`Referenced by ${referenceCount} node${referenceCount > 1 ? "s" : ""}`}
            >
              <span className="text-xs font-bold text-gray-500">{referenceCount}</span>
              <div className="h-px w-7 bg-gray-400 mt-0.5" />
            </div>
          </ReferenceListPopover>
        )}
        <div
          className={`border-2 rounded-lg bg-white p-2 flex flex-col ${
            selected ? "border-primary shadow-lg" : "border-gray-300 hover:shadow-md"
          }`}
          style={{ width: baseNodeSize.width, height: baseNodeSize.height }}
        >
          <textarea
            className="w-full h-full resize-none border-0 outline-none text-sm bg-transparent"
            placeholder="Type here..."
            readOnly={!selected}
            maxLength={75}
            value={node?.summary ?? ""}
            onChange={(e) => {
              if (node) node.summary = e.target.value;
            }}
          />
          <Handles />
        </div>
      </div>
    </BaseNode>
  );
};

export const SimpleNode = memo(SimpleNodeComponent);
