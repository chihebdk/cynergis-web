"use client";

import { memo } from "react";
import { BaseNode } from "./BaseNode";
import Handles from "./Handles";
import { baseNodeSize } from "../config/settings";
import { useNodeCache, useNodeTypeConfig } from "../CanvasProvider";
import { useReferenceNodeNavigation } from "../hooks/useReferenceNavigation";
import { IconGoToOriginal } from "../icons/index.js";
import type { BaseNodeData } from "../types/NodeTypes";

type ReferenceNodeProps = {
  id: string;
  data?: BaseNodeData;
};

const ReferenceNodeComponent: React.FC<ReferenceNodeProps> = ({ id, data }) => {
  const { getItem, selected: selectedNode } = useNodeCache();
  const refRow = getItem(id) as any;
  const target = refRow?.refNodeId ? (getItem(refRow.refNodeId) as any) : undefined;
  const selected = refRow?.id === selectedNode?.id;
  const hasFocus = data?.properties?.hasFocus;

  const { targetId, goToOriginal } = useReferenceNodeNavigation(id);
  const nodeConfig = useNodeTypeConfig("ReferenceNode");

  return (
    <BaseNode
      id={id}
      inFocus={hasFocus}
      isDragged={data?.properties?.dragging}
      options={{ toolbar: nodeConfig.toolbar, contextMenuItems: nodeConfig.contextMenu, decorators: nodeConfig.decorators }}
    >
      <div className="flex items-center relative">
        {hasFocus && targetId && (
          <button
            type="button"
            className="absolute -top-5 right-0 hover:scale-125 transition-transform duration-200 cursor-pointer text-gray-500"
            title="Go to original node"
            onClick={goToOriginal}
          >
            <IconGoToOriginal width={16} />
          </button>
        )}
        <div
          className={`border-2 rounded-lg bg-white p-2 flex flex-col border-dashed ${
            selected ? "border-primary shadow-lg" : "border-gray-400 hover:shadow-md"
          }`}
          style={{ width: baseNodeSize.width, height: baseNodeSize.height }}
        >
          <div className="text-xs text-gray-400 mb-1">ref</div>
          <textarea
            className="w-full h-full resize-none border-0 outline-none text-sm bg-transparent"
            readOnly
            value={target?.summary ?? ""}
          />
          <Handles />
        </div>
      </div>
    </BaseNode>
  );
};

export const ReferenceNode = memo(ReferenceNodeComponent);
