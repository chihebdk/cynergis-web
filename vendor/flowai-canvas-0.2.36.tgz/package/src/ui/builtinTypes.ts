import type { NodeTypes, EdgeTypes } from "@xyflow/react";
import { SimpleNode } from "./SimpleNode";
import { StartNode } from "./StartNode";
import { ReferenceNode } from "./ReferenceNode";
import { TerminalNode } from "./TerminalNode";
import { SubmapNode } from "./SubmapNode";
import SubmapGroupNode from "./SubmapGroupNode";
import { SubmapStartNode, SubmapEndNode } from "./SubmapMarkerNode";
import { WorkflowEdge } from "./WorkflowEdge";
import { TerminalEdge } from "./TerminalEdge";

export const builtinNodeTypes: NodeTypes = {
  SimpleNode,
  EventNode: SimpleNode,
  StartNode,
  ReferenceNode,
  TerminalNode,
  SubmapNode,
  SubmapGroupNode,
  SubmapStartNode,
  SubmapEndNode,
};

export const builtinEdgeTypes: EdgeTypes = {
  WorkflowEdge,
  TerminalEdge,
};

export function resolveNodeTypes(custom?: NodeTypes): NodeTypes {
  return { ...builtinNodeTypes, ...(custom ?? {}) };
}

export function resolveEdgeTypes(custom?: EdgeTypes): EdgeTypes {
  return { ...builtinEdgeTypes, ...(custom ?? {}) };
}
