import { memo } from "react";
import {
  Edge,
  BaseEdge,
  EdgeProps,
  getSmoothStepPath,
} from "@xyflow/react";

const TerminalEdgeComponent = ({
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
}: EdgeProps<Edge>) => {
  const [edgePath] = getSmoothStepPath({
    sourceX,
    sourceY,
    sourcePosition,
    targetX,
    targetY,
    targetPosition,
    borderRadius: 15,
  });

  return (
    <BaseEdge
      path={edgePath}
      style={{
        stroke: "#9ca3af",
        strokeWidth: 1.5,
      }}
    />
  );
};

export const TerminalEdge = memo(TerminalEdgeComponent);
