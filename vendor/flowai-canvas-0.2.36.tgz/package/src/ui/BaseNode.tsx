import { ReactNode, useEffect } from "react";
import { cn } from "../lib/utils";
import {
  Card,
} from "../components/shadcn/card";
import { useDecorator } from "../hooks/useDecorator";
import { NodeToolbar } from "../controls/NodeToolbar";
import {
  ContextMenu,
  ContextMenuTrigger,
} from "../components/shadcn/context-menu";
import { NodeContextMenu } from "../controls/NodeContextMenu";
import { readOptions } from "../utils";
import { useChildrenRotationScrollHandler } from "../hooks/useChildrenRotationScrollHandler";
import MoveToTopToolbar from "../controls/MoveToTopToolbar";
import { DeleteNodeToolbar } from "../controls/DeleteNodeToolbar";
import { useNodeCache } from "../CanvasProvider";
import { useSubmapCache } from "../CanvasProvider";
import { useCanvasConfig } from "../CanvasProvider";
import { SubmapModel as Submap } from "../CanvasProvider";
import { ProxyEntity } from "@flowai/state";
import { useCanvasEphemeralStore as useEphemeralStore } from "../CanvasProvider";
import { extractSubmapInstanceId, getSubmapNodeId, getSubmapEndMarkerId } from "../utils/submapUtils";
import { useReactFlow } from "@xyflow/react";

type BaseNodeProps = {
  id: string;
  selected?: boolean;
  inFocus?: boolean;
  isDragged?: boolean;
  children: ReactNode;
  className?: string;
  options?: {
    [key: string]: any;
  };
  colors?: string;
};

export const BaseNode: React.FC<BaseNodeProps> = ({
  id,
  selected,
  inFocus,
  isDragged,
  children,
  className,
  options,
}: BaseNodeProps) => {
  const { toolbar: rawToolbar, contextMenuItems, decorators } = readOptions(options);
  const { getItem: getNodeModel } = useNodeCache();
  const nodeModel = getNodeModel(id);
  const { getItems: getSubmaps } = useSubmapCache();
  const isSubmapEndNode = (getSubmaps() as Submap[]).some((s) => s.endNodeId === id);

  // Resolve isEndNode: for regular nodes check directly,
  // for collapsed SubmapNodes or SubmapEndNode markers check the submap's endNodeId
  let isEndNode = !!(nodeModel as any)?.isEndNode;
  if (!nodeModel) {
    const instanceId = extractSubmapInstanceId(id);
    if (instanceId) {
      const submap = (getSubmaps() as Submap[]).find(
        (s) => s.id && (getSubmapNodeId(s.id, instanceId) === id || getSubmapEndMarkerId(s.id, instanceId) === id)
      );
      if (submap) {
        const endModel = getNodeModel(submap.endNodeId);
        isEndNode = !!(endModel as any)?.isEndNode;
      }
    }
  }

  // Check if node is at the last lane (cannot add children beyond lane count)
  const canvasConfig = useCanvasConfig();
  const laneCount = canvasConfig.lanes?.show ? (canvasConfig.lanes?.titles?.length ?? 0) : 0;
  const { getNode } = useReactFlow();
  const rfNode = getNode(id);
  const nodeDepth = (rfNode?.data as any)?.properties?.depth ?? 0;
  const isAtLastLane = laneCount > 0 && nodeDepth >= laneCount - 1;

  const toolbar = (isSubmapEndNode || isEndNode || isAtLastLane)
    ? rawToolbar.filter((t: string) => !["addNode", "addCondition", "addError", "addReference", "addSubflow"].includes(t))
    : rawToolbar;
  const cutStore = useEphemeralStore("cutNode");
  const cutDescendantIds = (cutStore.getItem("descendantIds") as string[]) || [];
  const isCut = cutDescendantIds.includes(id);
  const hasCutNode = !!cutStore.getItem("id");

  const deleteStore = useEphemeralStore("deleteNode");
  const deleteDescendantIds = (deleteStore.getItem("descendantIds") as string[]) || [];
  const isMarkedForDelete = deleteDescendantIds.includes(id);
  const hasDeleteNode = !!deleteStore.getItem("id");
  const isDeleteRoot = (deleteStore.getItem("id") as string) === id;

  const submapStore = useEphemeralStore("submapMode");
  const isSubmapMode = !!submapStore.getItem("startNodeId");
  const isSubmapStart = (submapStore.getItem("startNodeId") as string) === id;

  const registeredDecorators = useDecorator((decorator) => {
    return decorators.includes(decorator);
  });

  const onwheel = useChildrenRotationScrollHandler();
  const { setNodes } = useReactFlow();

  // When this node is the delete root: hide its terminal sibling and boost its
  // zIndex so the delete popup renders above all other nodes/edges.
  useEffect(() => {
    const terminalId = `terminal-${id}`;
    setNodes((nds) => {
      return nds.map((n) => {
        if (n.id === id) {
          const newZ = isDeleteRoot ? 9999 : ((n.data as any)?._prevZIndex ?? 1);
          if (n.zIndex === newZ) return n;
          return isDeleteRoot
            ? { ...n, zIndex: newZ, data: { ...(n.data as object), _prevZIndex: n.zIndex ?? 1 } }
            : { ...n, zIndex: newZ };
        }
        if (n.id === terminalId) {
          if (n.hidden === isDeleteRoot) return n;
          return { ...n, hidden: isDeleteRoot };
        }
        return n;
      });
    });
  }, [isDeleteRoot, id, setNodes]);

  const showNodeToolbar = !isDragged && (inFocus === undefined || inFocus);

  return (
    <div
      className={cn("flex items-center group", className)}
      onWheel={(e) => {
        return onwheel(id, e.deltaY);
      }}
    >
      <div className="relative">
        <ContextMenu>
          <ContextMenuTrigger>
            <Card
              className={cn(
                "size-full p-0 min-w-24 min-h-24 z-100 relative",
                inFocus ? "shadow-2xl" : `shadow-lg`,
                selected
                  ? "outline outline-2 outline-[#0ea5e9] outline-offset-[-2px] shadow-2xl"
                  : `border-0 hover:shadow-2xl`,
                (isCut || isMarkedForDelete) && "opacity-50 border-dashed border-2 border-gray-400",
              )}
            >
              {isSubmapStart && <div className="submap-start-border" />}
              {children}
            </Card>
          </ContextMenuTrigger>
          {((nodeModel as unknown as ProxyEntity)?.persisted || (!nodeModel && contextMenuItems && contextMenuItems.length > 0)) && (inFocus === undefined || inFocus) && (
            <NodeContextMenu id={id} items={contextMenuItems ?? []} />
          )}
        </ContextMenu>

        {registeredDecorators}
      </div>

      {((nodeModel as unknown as ProxyEntity)?.persisted || (!nodeModel && toolbar && toolbar.length > 0)) && !hasCutNode && !isSubmapMode && (
        hasDeleteNode ? (
          isDeleteRoot ? (
            <div className="opacity-100 transition-all duration-200">
              <DeleteNodeToolbar id={id} />
            </div>
          ) : null
        ) : (
          <div className=" opacity-0 group-hover:opacity-100 transition-all duration-200 ">
            {showNodeToolbar ? (
              <NodeToolbar id={id} toolbar={toolbar ?? []} />
            ) : (
              <MoveToTopToolbar id={id} />
            )}
          </div>
        )
      )}
    </div>
  );
};
