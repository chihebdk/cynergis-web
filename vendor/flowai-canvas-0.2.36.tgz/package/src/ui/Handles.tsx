import { memo } from "react";
import { Handle, Position, useReactFlow } from "@xyflow/react";

type Props = {};

const Handles: React.FC<Props> = (_props) => {
  //check if we are not on canvas mode, otherwise return empty
  //used for rendering nodes in storybook
  try {
    const _reactFlowInstance = useReactFlow();
  } catch {
    return <></>;
  }

  return (
    <>
      <Handle
        className="invisible"
        type="target"
        position={Position.Left}
        isConnectable={false}
      />
      <Handle
        className="invisible"
        type="source"
        position={Position.Right}
        isConnectable={false}
      />
    </>
  );
};

export default memo(Handles);
