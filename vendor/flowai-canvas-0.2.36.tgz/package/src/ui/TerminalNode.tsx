import { memo } from "react";
import Handles from "./Handles";
import { baseNodeSize } from "../config/settings";

const TerminalNodeComponent = () => (
  <div
    className="flex items-center justify-start"
    style={{ width: baseNodeSize.width, height: baseNodeSize.height }}
  >
    <div
      className="rounded-full bg-white border-2 border-gray-500 flex items-center justify-center"
      style={{ width: 32, height: 32 }}
    >
      <div
        className="rounded-full bg-gray-500"
        style={{ width: 18, height: 18 }}
      />
    </div>
    <Handles />
  </div>
);

export const TerminalNode = memo(TerminalNodeComponent);
