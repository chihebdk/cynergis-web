"use client";

import { memo, useMemo, useState, useCallback, useRef, useEffect } from "react";
import { useViewport } from "@xyflow/react";
import { layoutConfig, baseNodeSize } from "../config/settings";

type LaneBorderConfig = {
  show?: boolean;
  color?: string;
  strokeWidth?: number;
};

export type VerticalLanesProps = {
  laneWidth?: number;
  colors?: string[];
  opacity?: number;
  border?: LaneBorderConfig;
  titles?: string[];
  onTitleChange?: (index: number, title: string) => void;
};

const DEFAULT_COLORS = ["#dbeafe", "#fce7f3", "#d1fae5", "#fef3c7", "#e0e7ff", "#fde2e2", "#d5f5f6", "#fde68a"];
const DEFAULT_LANE_WIDTH = baseNodeSize.width + 150; // 315px — matches layout engine column spacing

/* ── Editable title label ─────────────────────────────────────── */
const LaneTitle = ({
  title,
  index,
  onTitleChange,
}: {
  title: string;
  index: number;
  onTitleChange?: (index: number, title: string) => void;
}) => {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(title);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setValue(title);
  }, [title]);

  useEffect(() => {
    if (editing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editing]);

  const commit = useCallback(() => {
    setEditing(false);
    const trimmed = value.trim();
    if (trimmed && trimmed !== title) {
      onTitleChange?.(index, trimmed);
    } else {
      setValue(title);
    }
  }, [value, title, index, onTitleChange]);

  if (editing) {
    return (
      <input
        ref={inputRef}
        className="no-wheel"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === "Enter") commit();
          if (e.key === "Escape") { setValue(title); setEditing(false); }
        }}
        style={{
          background: "transparent",
          border: "none",
          borderBottom: "1px solid #94a3b8",
          outline: "none",
          textAlign: "center",
          fontSize: 12,
          fontWeight: 600,
          color: "#475569",
          width: "100%",
          padding: "2px 4px",
        }}
      />
    );
  }

  return (
    <span
      onDoubleClick={() => setEditing(true)}
      style={{
        cursor: "default",
        fontSize: 12,
        fontWeight: 600,
        color: "#475569",
        userSelect: "none",
        whiteSpace: "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis",
        maxWidth: "100%",
        display: "block",
        textAlign: "center",
        padding: "2px 4px",
      }}
    >
      {title}
    </span>
  );
};

/* ── Main component ───────────────────────────────────────────── */
const VerticalLanesComponent = ({
  laneWidth: laneWidthProp,
  colors = DEFAULT_COLORS,
  opacity = 0.3,
  border,
  titles,
  onTitleChange,
}: VerticalLanesProps) => {
  const { x: vpX, y: vpY, zoom } = useViewport();

  const laneWidth = laneWidthProp ?? DEFAULT_LANE_WIDTH;
  const laneCount = titles?.length ?? 0;

  const lanes = useMemo(() => {
    if (laneCount === 0) return [];

    // Center nodes within lanes: padding = (laneWidth - nodeWidth) / 2
    const padding = (laneWidth - baseNodeSize.width) / 2;
    const startX = layoutConfig.startNodePosition.x - padding;

    return Array.from({ length: laneCount }, (_, i) => ({
      x: startX + i * laneWidth,
      width: laneWidth,
    }));
  }, [laneCount, laneWidth]);

  if (lanes.length === 0) return null;

  const laneTop = -5000;
  const laneHeight = 15000;

  const showBorder = border?.show !== false;
  const borderColor = border?.color ?? "#94a3b8";
  const borderStrokeWidth = border?.strokeWidth ?? 1;

  const hasTitles = titles && titles.length > 0;

  return (
    <>
      {/* SVG lane backgrounds + borders */}
      <svg
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          pointerEvents: "none",
          overflow: "visible",
        }}
      >
        <g transform={`translate(${vpX}, ${vpY}) scale(${zoom})`}>
          {lanes.map((lane, i) => (
            <rect
              key={`lane-${i}`}
              x={lane.x}
              y={laneTop}
              width={lane.width}
              height={laneHeight}
              fill={colors[i % colors.length]}
              opacity={opacity}
            />
          ))}
          {showBorder &&
            lanes.slice(1).map((lane, i) => (
              <line
                key={`border-${i}`}
                x1={lane.x}
                y1={laneTop}
                x2={lane.x}
                y2={laneTop + laneHeight}
                stroke={borderColor}
                strokeWidth={borderStrokeWidth}
                opacity={opacity * 1.5}
              />
            ))}
        </g>
      </svg>

      {/* HTML overlay for editable titles — pinned to top of viewport */}
      {hasTitles && (
        <div
          style={{
            position: "absolute",
            top: 8,
            left: 0,
            width: "100%",
            height: 0,
            overflow: "visible",
            pointerEvents: "none",
            zIndex: 5,
          }}
        >
          {lanes.map((lane, i) => {
            const laneTitle = titles[i % titles.length];
            // Convert canvas-space lane position to screen-space
            const screenX = lane.x * zoom + vpX;
            const screenWidth = lane.width * zoom;

            return (
              <div
                key={`title-${i}`}
                style={{
                  position: "absolute",
                  left: screenX,
                  width: screenWidth,
                  top: 0,
                  display: "flex",
                  justifyContent: "center",
                  pointerEvents: "auto",
                }}
              >
                <LaneTitle
                  title={laneTitle}
                  index={i}
                  onTitleChange={onTitleChange}
                />
              </div>
            );
          })}
        </div>
      )}
    </>
  );
};

export const VerticalLanes = memo(VerticalLanesComponent);
