"use client";

import { memo } from "react";
import { NodeProps } from "@xyflow/react";
import { BaseNode } from "./BaseNode";
import Handles from "./Handles";
import { baseNodeSize } from "../config/settings";
import { getSubmapColor } from "../utils/submapUtils";
import { useSubmapCache } from "../CanvasProvider";
import { useSubmapActions } from "../hooks/useSubmapActions";
import { CollapseSubflow } from "../components/icons";
import { SubmapModel as Submap } from "../CanvasProvider";

type SubmapMarkerNodeData = {
  label: string;
  submapName: string;
  submapId: string;
  submapInstanceId: string;
  properties?: {
    hasFocus?: boolean;
    layoutCategory?: string;
  };
};

const SubmapStartNodeComponent = ({ id, data }: NodeProps) => {
  const { submapId, submapInstanceId, submapName, properties } = data as unknown as SubmapMarkerNodeData;
  const { getItem: getSubmap } = useSubmapCache();
  const { collapseSubmap } = useSubmapActions();
  const color = getSubmapColor(submapId, (getSubmap(submapId) as Submap | undefined)?.colorIndex);

  return (
    <BaseNode
      id={id}
      inFocus={properties?.hasFocus}
      options={{ toolbar: [], contextMenuItems: [], decorators: [] }}
    >
      <div className="flex items-center relative">
        <button
          type="button"
          className="absolute -top-5 right-0 hover:scale-125 transition-transform duration-200 cursor-pointer"
          title="Collapse Submap"
          onClick={(e) => {
            e.stopPropagation();
            collapseSubmap(submapId, submapInstanceId);
          }}
        >
          <CollapseSubflow width={16} color={color.labelColor} />
        </button>
        <div
          className="submap-card flex flex-col items-center justify-center rounded-xl border-2 shadow-lg"
          style={
            {
              width: baseNodeSize.width,
              height: baseNodeSize.height,
              "--submap-bg": color.bg,
              "--submap-border": color.border,
              "--submap-label": color.labelColor,
              "--submap-name": color.nameColor,
            } as React.CSSProperties
          }
        >
          <p className="submap-label text-sm font-medium">Start</p>
          <p className="submap-name text-xs truncate max-w-[130px]">{submapName}</p>
        </div>
        <Handles />
      </div>
    </BaseNode>
  );
};

const SubmapEndNodeComponent = ({ id, data }: NodeProps) => {
  const { submapId, submapName, properties } = data as unknown as SubmapMarkerNodeData;
  const { getItem: getSubmap } = useSubmapCache();
  const color = getSubmapColor(submapId, (getSubmap(submapId) as Submap | undefined)?.colorIndex);

  return (
    <BaseNode
      id={id}
      inFocus={properties?.hasFocus}
      options={{ toolbar: ["addNode", "addCondition", "addError", "addReference", "addSubflow"], contextMenuItems: [], decorators: [] }}
    >
      <div className="flex items-center">
        <div
          className="submap-card flex flex-col items-center justify-center rounded-xl border-2 shadow-lg"
          style={
            {
              width: baseNodeSize.width,
              height: baseNodeSize.height,
              "--submap-bg": color.bg,
              "--submap-border": color.border,
              "--submap-label": color.labelColor,
              "--submap-name": color.nameColor,
            } as React.CSSProperties
          }
        >
          <p className="submap-label text-sm font-medium">End</p>
          <p className="submap-name text-xs truncate max-w-[130px]">{submapName}</p>
        </div>
        <Handles />
      </div>
    </BaseNode>
  );
};

export const SubmapStartNode = memo(SubmapStartNodeComponent);
export const SubmapEndNode = memo(SubmapEndNodeComponent);
