"use client";

import { memo } from "react";
import { Icon } from "@iconify/react";
import Handles from "./Handles";
import { baseNodeSize } from "../config/settings";
import { useAddNodeHandler } from "../hooks/useAddNodeHandler";
import { createId } from "@paralleldrive/cuid2";

const StartNodeComponent = ({ id }: { id: string }) => {
  const onClick = useAddNodeHandler();

  return (
    <div
      className="flex items-center justify-center"
      style={{ height: baseNodeSize.height }}
    >
      <div className="flex gap-4 border-2 border-primary bg-orange-50 rounded-2xl items-center justify-center p-2 shadow-xl">
        <p className="text-sm pl-4 text-primary font-medium truncate w-full justify-center">
          Start
        </p>
        <div
          className="bg-primary rounded-full hover:cursor-pointer"
          onClick={() =>
            onClick({
              parentId: id,
              node: {
                id: createId(),
                width: baseNodeSize.width,
                height: baseNodeSize.height,
                type: "SimpleNode",
                position: { x: 0, y: 0 },
                zIndex: 1,
                data: {
                  properties: { layoutCategory: "hierarchy" },
                },
              },
            })
          }
        >
          <Icon
            icon="gg:arrow-right-o"
            className="text-white hover:scale-140 transition-all duration-200"
            width={20}
          />
        </div>
      </div>
      <Handles />
    </div>
  );
};

export const StartNode = memo(StartNodeComponent);
