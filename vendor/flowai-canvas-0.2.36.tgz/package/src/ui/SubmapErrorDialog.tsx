"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "../components/shadcn/dialog";
import { Button } from "../components/shadcn/button";
import { useSubmapHandler } from "../hooks/useSubmapHandler";

export const SubmapErrorDialog = () => {
  const { errorMessage, clearError } = useSubmapHandler();
  const open = !!errorMessage;

  return (
    <Dialog open={open} onOpenChange={(next) => !next && clearError()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Cannot create submap</DialogTitle>
          <DialogDescription>{errorMessage}</DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button onClick={clearError}>OK</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
