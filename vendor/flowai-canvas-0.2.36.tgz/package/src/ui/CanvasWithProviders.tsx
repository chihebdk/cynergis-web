"use client";

import { ReactFlowProvider } from "@xyflow/react";
import React from "react";
import { NodeMarker, ReferenceNodeMarker } from "../components/icons";

type CanvasWithProvidersProps = {
  children: React.ReactNode;
};

const CanvasWithProviders: React.FC<CanvasWithProvidersProps> = ({ children }) => {
  return (
    <ReactFlowProvider>
      <NodeMarker />
      <ReferenceNodeMarker/>
      {children}
    </ReactFlowProvider>
  );
};

export default CanvasWithProviders;
