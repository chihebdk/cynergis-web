"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "../components/shadcn/dialog";
import { Input } from "../components/shadcn/input";
import { Textarea } from "../components/shadcn/textarea";
import { Label } from "../components/shadcn/label";
import { Button } from "../components/shadcn/button";
import { useSubmapHandler } from "../hooks/useSubmapHandler";

export const SubmapNameDialog = () => {
  const { showNameDialog, confirmSubmap, cancelSubmap } = useSubmapHandler();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  const handleConfirm = () => {
    if (name.trim()) {
      confirmSubmap(name.trim(), description.trim() || undefined);
      setName("");
      setDescription("");
    }
  };

  const handleCancel = () => {
    cancelSubmap();
    setName("");
    setDescription("");
  };

  return (
    <Dialog open={showNameDialog} onOpenChange={(open) => !open && handleCancel()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Name your submap</DialogTitle>
          <DialogDescription>
            Enter a name for the submap grouping.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-3">
          <div className="grid gap-1.5">
            <Label htmlFor="submap-name">Name</Label>
            <Input
              id="submap-name"
              autoFocus
              placeholder="Submap name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleConfirm();
              }}
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="submap-description">Description (optional)</Label>
            <Textarea
              id="submap-description"
              placeholder="Submap description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
          <Button onClick={handleConfirm} disabled={name.trim().length < 3}>
            Create
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
