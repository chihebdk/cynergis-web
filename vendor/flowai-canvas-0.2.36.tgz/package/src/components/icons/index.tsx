import { Icon } from "@iconify/react";

export const Home = ({ ...props }) => {
  return <Icon icon="fluent:home-more-24-regular" {...props} />;
};

export const EventStorming = ({ ...props }) => {
  return <Icon icon="fluent-mdl2:automate-flow" {...props} />;
};

export const DomainStories = ({ ...props }) => {
  return <Icon icon="fluent-mdl2:storyboard" {...props} />;
};

export const VSM = ({ ...props }) => {
  return <Icon icon="cil:factory" {...props} />;
};

export const WardleyMap = ({ ...props }) => {
  return <Icon icon="streamline:text-flow-rows" {...props} />;
};

export const Strategy = ({ ...props }) => {
  return <Icon icon="gis:map-control" {...props} />;
};

export const Project = ({ ...props }) => {
  return <Icon icon="simple-line-icons:organization" {...props} />;
};

export const Integrations = ({ ...props }) => {
  return <Icon icon="gravity-ui:plug-connection" {...props} />;
};

export const Resources = ({ ...props }) => {
  return <Icon icon="grommet-icons:resources" {...props} />;
};

export const Documentation = ({ ...props }) => {
  return <Icon icon="oui:documentation" {...props} />;
};

export const Teams = ({ ...props }) => {
  return <Icon icon="fluent:people-team-28-regular" {...props} />;
};

export const Deployments = ({ ...props }) => {
  return <Icon icon="grommet-icons:deploy" {...props} />;
};

export const Aggregate = ({ ...props }) => {
  return <Icon icon="carbon:column-dependency" {...props} />;
};

export const Operations = ({ ...props }) => {
  return <Icon icon="carbon:cloud-monitoring" {...props} />;
};

export const Tools = ({ ...props }) => {
  return (
    <Icon icon="fluent-mdl2:customize-toolbar" strokeWidth={2} {...props} />
  );
};

export const Architecture = ({ ...props }) => {
  return <Icon icon="carbon:ibm-global-storage-architecture" {...props} />;
};

export const Comment = ({ ...props }) => {
  return <Icon icon="material-symbols-light:chat-rounded" {...props} />;
};

export const AddNode = ({ ...props }) => {
  return <Icon icon="tabler:hexagon-plus" width={20} height={20} {...props} />;
};

export const NodeMarker = ({ width = 14, height = 14, ...props }) => {
  return (
    <MarkerWrapper id="EventNode" width={width} height={height}>
      <Icon
        icon="tabler:hexagon"
        width={14}
        height={14}
        color="gray"
        {...props}
      />
    </MarkerWrapper>
  );
};

export const AddCondition = ({ ...props }) => {
  return <Icon icon="mynaui:plus-diamond" {...props} />;
};

export const ConditionNodeMarker = ({ width = 14, height = 14, ...props }) => {
  return (
    <MarkerWrapper id="ConditionNode" width={width} height={height}>
      <Icon
        icon="fluent:diamond-32-regular"
        width={width}
        height={height}
        color="gray"
        {...props}
      />
    </MarkerWrapper>
  );
};

export const AddError = ({ ...props }) => {
  return <Icon icon="tabler:hexagon-plus" {...props} />;
};

export const ErrorNodeMarker = ({ width = 14, height = 14, ...props }) => {
  return (
    <MarkerWrapper id="ErrorNode" width={width} height={height}>
      <Icon
        icon="tabler:hexagon"
        width={width}
        height={height}
        color="gray"
        {...props}
      />
    </MarkerWrapper>
  );
};

export const AddReference = ({ ...props }) => {
  return <Icon icon="carbon:network-3-reference" {...props} />;
};

export const ReferenceNodeMarker = ({ width = 14, height = 14, ...props }) => {
  return (
    <MarkerWrapper id="ReferenceNode" width={width} height={height}>
      <Icon
        icon="carbon:network-3-reference"
        width={width}
        height={height}
        color="gray"
        {...props}
      />
    </MarkerWrapper>
  );
};

export const AddSubflow = ({ ...props }) => {
  return <Icon icon="carbon:subflow" {...props} />;
};

export const SubflowNodeMarker = ({ width = 14, height = 14, ...props }) => {
  return (
    <MarkerWrapper id="SubflowNode" width={width} height={height}>
      <Icon
        icon="carbon:subflow"
        width={width}
        height={height}
        color="gray"
        {...props}
      />
    </MarkerWrapper>
  );
};

export const GoToOriginal = ({ ...props }) => {
  return <Icon icon="lets-icons:refund-back" {...props} />;
};

export const ExpandSubflow = ({ ...props }) => {
  return <Icon icon="ant-design:node-expand-outlined" {...props} />;
};

export const CollapseSubflow = ({ ...props }) => {
  return <Icon icon="ant-design:node-collapse-outlined" {...props} />;
};

export const Dot = ({ ...props }) => {
  return <Icon icon="icon-park-outline:dot" {...props} />;
};

export const Arrow = ({ ...props }) => {
  return <Icon icon="material-symbols:play-arrow-rounded" {...props} />;
};

export const Square = ({ ...props }) => {
  return <Icon icon="material-symbols:square-rounded" {...props} />;
};

export const UIBuilder = ({ ...props }) => {
  return <Icon icon="streamline:widget" {...props} />;
};

export const KnowledgeBase = ({ ...props }) => {
  return <Icon icon="carbon:ibm-knowledge-catalog-premium" {...props} />;
};

export const Add = ({ ...props }) => {
  return <Icon icon="si:add-square-line" {...props} />;
};

export const Open = ({ ...props }) => {
  return <Icon icon="ion:open-outline" {...props} />;
};

export const Dots = ({ ...props }) => {
  return <Icon icon="pepicons-pencil:dots-x" {...props} />;
};

export const Json = ({ ...props }) => {
  return <Icon icon="si:json-line" {...props} />;
};

const MarkerWrapper = ({
  id,
  children,
  width = 14,
  height = 14,
  ...props
}: {
  id: string;
  children: React.ReactNode;
  width?: number;
  height?: number;
}) => {
  return (
    <svg style={{ position: "absolute", width, height }}>
      <defs>
        <marker
          id={id}
          markerHeight={height}
          markerWidth={width}
          refX={width - 1}
          refY={height / 2}
          {...props}
        >
          <rect
            width={width}
            height={height}
            {...props}
            stroke="gray"
            strokeOpacity={0}
            strokeWidth={4}
            style={{
              fill: "white",
              //zIndex: 10,
            }}
          />

          <svg viewBox="1 0 14 14">{children}</svg>
        </marker>
      </defs>
    </svg>
  );
};
