import { Node, Edge, getIncomers, getOutgoers } from "@xyflow/react";

import {
  defaultNodeDecorators,
  defaultNodeContextMenuItems,
  defaultNodeToolbar,
} from "../config/settings";
import { WorkflowEdgeData } from "../types/EdgeTypes";

export function readOptions(options?: { [key: string]: any }) {
  if (!options) {
    options = {};
  }

  if (!options?.toolbar) {
    options.toolbar = defaultNodeToolbar;
  }

  if (!options?.contextMenuItems) {
    options.contextMenuItems = defaultNodeContextMenuItems;
  }

  if (!options?.decorators) {
    options.decorators = defaultNodeDecorators;
  }

  return options;
}

export function getParent(node: Node, nodes: Node[], edges: Edge[]) {
  if (!node || !nodes || !edges) {
    throw new Error(
      "One or more Parameter <node, nodes or edges> is undefined or null"
    );
  }

  const incomers = getIncomers(node, nodes, edges);
  if (incomers.length === 0) {
    return null;
  }
  if (incomers.length > 1) {
    throw new Error("Node has more than one parent");
  }

  return incomers[0];
}

export function getSiblings(node: Node, nodes: Node[], edges: Edge[]) {
  const parentNode = getParent(node, nodes, edges);
  if (!parentNode) {
    return null;
  }
  const outgoers = getOutgoers(parentNode, nodes, edges);

  return outgoers.filter((n) => n.id !== node.id);
}

export function addNode(
  parentId: string,
  node: Node,
  nodes: Node[],
  edges: Edge[]
) {
  const edge: Edge = {
    id: `${parentId}=>${node.id}`,
    source: parentId,
    target: node.id,
    markerEnd: "EventNode", //node.type,
    data: {
      properties: {
        isError: node.type === "ErrorNode",
      },
    },
  };

  //deselectAll(nodes);
  nodes.unshift(node);
  edges.push(edge);
}


export function insertNode(
  edge: Edge<WorkflowEdgeData>,
  node: Node,
  nodes: Node[],
  edges: Edge<WorkflowEdgeData>[]
) {

  console.log("insert node", nodes);

  const sourceEdge = {
    id: `${edge.source}->${node.id}`,
    source: edge.source,
    target: node.id,
    markerEnd: node.type,
    data: {
      properties: {
        isError: node.type === "ErrorNode",
      },
    },
  };

  const targetEdge = {
    id: `${node.id}->${edge.target}`,
    source: node.id,
    target: edge.target,
    markerEnd: edge.markerEnd,
    data: {
      properties: {
        isError: edge.data?.properties.isError,
      },
    },
  };

  const edgeIndex = edges.findIndex((e) => e.id === edge.id);
  edges.splice(edgeIndex, 1);
  edges.push(sourceEdge as Edge<WorkflowEdgeData>);
  edges.push(targetEdge as Edge<WorkflowEdgeData>);

  nodes.forEach((n) => {
    n.selected = false;
  });
  node.selected = true;

  const targetNodeIndex = nodes.findIndex((n) => n.id === edge.target);
  nodes.splice(targetNodeIndex, 0, node);
  //nodes.push(node);
  //nodes.slice(targetNodeIndex, nodes.length);

  console.log("insert nodes", nodes);
}

export function getDescendants(nodeId: string, nodes: Node[], edges: Edge[], visited: Set<string> = new Set()): Node[] {
  if (visited.has(nodeId)) return [];
  visited.add(nodeId);

  const directChildren = edges
    .filter((e) => e.source === nodeId)
    .map((e) => nodes.find((n) => n.id === e.target))
    .filter(Boolean) as Node[];

  return directChildren.reduce<Node[]>(
    (acc, child) => [...acc, child, ...getDescendants(child.id, nodes, edges, visited)],
    []
  );
}

export function getChainBetween(
  startId: string,
  endId: string,
  nodes: Node[],
  edges: Edge[]
): Node[] {
  // Get all descendants of start (including start itself)
  const allDescendants = getDescendants(startId, nodes, edges);
  const startNode = nodes.find((n) => n.id === startId);
  if (!startNode) return [];

  // Get descendants of end (excluding end itself) — these are beyond the chain
  const beyondEnd = getDescendants(endId, nodes, edges);
  const beyondIds = new Set(beyondEnd.map((n) => n.id));

  // Chain = start + descendants of start, minus descendants of end
  return [startNode, ...allDescendants.filter((n) => !beyondIds.has(n.id))];
}

export type SubmapEndEligibility = {
  eligible: boolean;
  isDescendant: boolean;
  reason?: string;
};

export function isEligibleSubmapEnd(
  nodeId: string,
  startNodeId: string,
  nodes: Node[],
  edges: Edge[]
): boolean {
  return getSubmapEndEligibility(nodeId, startNodeId, nodes, edges).eligible;
}

/**
 * Returns eligibility info for a node to be a submap end.
 * Checks: descendant of start, no siblings, no reference nodes in chain,
 * no chain nodes referenced from outside.
 * `nodeModels` is optional — when provided, reference checks are performed.
 */
export function getSubmapEndEligibility(
  nodeId: string,
  startNodeId: string,
  nodes: Node[],
  edges: Edge[],
  nodeModels?: { id: string; refNodeId?: string | null; type?: string; summary?: string; name?: string; [key: string]: any }[]
): SubmapEndEligibility {
  // Must be a descendant of start
  const descendants = getDescendants(startNodeId, nodes, edges);
  const isDescendant = descendants.some((n) => n.id === nodeId);
  if (!isDescendant) {
    return { eligible: false, isDescendant: false, reason: "Node is not a descendant of the start node" };
  }

  // Must have no siblings
  const node = nodes.find((n) => n.id === nodeId);
  if (!node) {
    return { eligible: false, isDescendant: true, reason: "Node not found" };
  }
  const siblings = getSiblings(node, nodes, edges);
  if (siblings && siblings.length > 0) {
    return { eligible: false, isDescendant: true, reason: "End node has siblings — all nodes between start and end must form a single chain" };
  }

  // Reference checks require node models
  if (nodeModels) {
    const chain = getChainBetween(startNodeId, nodeId, nodes, edges);
    const chainIds = new Set(chain.map((n) => n.id));

    // Chain must not contain a reference node
    const refInChain = chain.find((n) => {
      if (n.type === "ReferenceNode") return true;
      const model = nodeModels.find((m) => m.id === n.id);
      return model?.type === "ReferenceNode" || !!model?.refNodeId;
    });
    if (refInChain) {
      return { eligible: false, isDescendant: true, reason: "Chain contains a reference node — remove it before creating a submap" };
    }

    // No chain node may be referenced from outside
    const referencingNodes = nodeModels.filter(
      (m) => m.refNodeId && chainIds.has(m.refNodeId)
    );
    if (referencingNodes.length > 0) {
      const targetNames = Array.from(new Set(referencingNodes.map((r) => r.refNodeId!)))
        .map((tid) => {
          const m = nodeModels.find((n) => n.id === tid);
          return m?.summary || m?.name || tid;
        })
        .join(", ");
      return { eligible: false, isDescendant: true, reason: `Node(s) in the chain are referenced from outside (${targetNames}) — remove the reference(s) first` };
    }
  }

  return { eligible: true, isDescendant: true };
}

/**
 * Reorder `nodes` so that each ancestor of `targetId` appears before its siblings.
 * This causes `stratify` → `orgLayout` to place the target node on the focused path,
 * making it (and all its ancestors) visible.
 * Returns a new array (does not mutate the original).
 */
export function focusNodePath(targetId: string, nodes: Node[], edges: Edge[]): Node[] {
  // Walk from target up to root, collecting the path of node IDs
  const pathIds: string[] = [];
  let currentId: string | undefined = targetId;
  const visited = new Set<string>();
  while (currentId && !visited.has(currentId)) {
    visited.add(currentId);
    pathIds.push(currentId);
    const incomingEdge = edges.find((e) => e.target === currentId);
    currentId = incomingEdge?.source;
  }

  // For each node in the path, ensure it comes before its siblings in the array.
  // Siblings = nodes whose parent edge has the same source.
  const pathSet = new Set(pathIds);
  const reordered = [...nodes];

  for (const nodeId of pathIds) {
    const parentEdge = edges.find((e) => e.target === nodeId);
    if (!parentEdge) continue; // root node, no reordering needed

    const parentId = parentEdge.source;
    // Find all sibling IDs (children of the same parent)
    const siblingIds = edges
      .filter((e) => e.source === parentId)
      .map((e) => e.target);

    if (siblingIds.length <= 1) continue; // no siblings to reorder

    // Find the first sibling in the current array order
    const firstSiblingIdx = Math.min(
      ...siblingIds.map((sid) => reordered.findIndex((n) => n.id === sid)).filter((i) => i >= 0)
    );
    const nodeIdx = reordered.findIndex((n) => n.id === nodeId);

    if (nodeIdx > firstSiblingIdx) {
      // Move nodeId to the position of the first sibling
      const [node] = reordered.splice(nodeIdx, 1);
      reordered.splice(firstSiblingIdx, 0, node);
    }
  }

  return reordered;
}

export function swapNodes(nodes: Node[], node1: Node, node2: Node) {
  const index1 = nodes.findIndex((n) => n.id === node1.id);
  const index2 = nodes.findIndex((n) => n.id === node2.id);

  if (index1 === -1 || index2 === -1) {
    throw new Error("Node not found in nodes array");
  }

  const temp = nodes[index1];
  nodes[index1] = nodes[index2];
  nodes[index2] = temp;

  return nodes;
}
