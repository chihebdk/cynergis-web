import { Node, Edge } from "@xyflow/react";
import { SubmapModel as Submap } from "../CanvasProvider";
import { baseNodeSize, layoutConfig } from "../config/settings";
import { BaseNodeData, SubmapNodeData, SubmapMarkerNodeData, SubmapGroupNodeData } from "../types/NodeTypes";
import { getChainBetween } from "../utils";

// ─── Node ID helpers ──────────────────────────────────────────────

export function getSubmapNodeId(submapId: string, instanceId: string): string {
  return `submap-${submapId}-${instanceId}`;
}

export function getSubmapStartMarkerId(submapId: string, instanceId: string): string {
  return `submap-start-${submapId}-${instanceId}`;
}

export function getSubmapEndMarkerId(submapId: string, instanceId: string): string {
  return `submap-end-${submapId}-${instanceId}`;
}

export function getSubmapGroupNodeId(submapId: string, instanceId: string): string {
  return `submap-group-${submapId}-${instanceId}`;
}

/** Extract instanceId from any submap-derived node id.
 * Format: submap[-start|-end|-group]-{submapId}-{instanceId}
 * instanceId is always the last dash-separated token.
 */
export function extractSubmapInstanceId(nodeId: string): string | undefined {
  if (!nodeId.startsWith("submap-")) return undefined;
  const lastDash = nodeId.lastIndexOf("-");
  if (lastDash === -1) return undefined;
  return nodeId.slice(lastDash + 1);
}

// ─── Node builders ────────────────────────────────────────────────

export function buildSubmapNode(
  submapId: string,
  instanceId: string,
  name: string,
  position: { x: number; y: number }
): Node<SubmapNodeData> {
  return {
    id: getSubmapNodeId(submapId, instanceId),
    type: "SubmapNode",
    position,
    zIndex: 1,
    width: baseNodeSize.width,
    height: baseNodeSize.height,
    data: {
      submapId,
      submapInstanceId: instanceId,
      name,
      properties: { layoutCategory: "hierarchy", hasFocus: true },
    },
  };
}

export function buildSubmapStartMarker(
  submapId: string,
  instanceId: string,
  name: string,
  position: { x: number; y: number }
): Node<SubmapMarkerNodeData> {
  return {
    id: getSubmapStartMarkerId(submapId, instanceId),
    type: "SubmapStartNode",
    position,
    zIndex: 1,
    width: baseNodeSize.width,
    height: baseNodeSize.height,
    draggable: false,
    data: {
      label: `Start ${name}`,
      submapName: name,
      submapId,
      submapInstanceId: instanceId,
      properties: { layoutCategory: "hierarchy" },
    },
  };
}

export function buildSubmapEndMarker(
  submapId: string,
  instanceId: string,
  name: string,
  position: { x: number; y: number }
): Node<SubmapMarkerNodeData> {
  return {
    id: getSubmapEndMarkerId(submapId, instanceId),
    type: "SubmapEndNode",
    position,
    zIndex: 1,
    width: baseNodeSize.width,
    height: baseNodeSize.height,
    draggable: false,
    data: {
      label: `End ${name}`,
      submapName: name,
      submapId,
      submapInstanceId: instanceId,
      properties: { layoutCategory: "hierarchy" },
    },
  };
}

export function buildSubmapGroupNode(
  submapId: string,
  instanceId: string,
  name: string,
  memberNodeIds: string[]
): Node<SubmapGroupNodeData> {
  return {
    id: getSubmapGroupNodeId(submapId, instanceId),
    type: "SubmapGroupNode",
    position: layoutConfig.startNodePosition,
    data: {
      submapId,
      submapInstanceId: instanceId,
      name,
      memberNodeIds,
      properties: { layoutCategory: "hierarchy" },
    },
    draggable: false,
    selectable: false,
    connectable: false,
    style: { zIndex: -1 },
  };
}

// ─── Edge rewiring helpers ────────────────────────────────────────

/**
 * Build edges for a collapsed submap: parent→SubmapNode and SubmapNode→children.
 */
export function buildCollapsedEdges(
  submapId: string,
  instanceId: string,
  incomingToStart: Edge | undefined,
  outgoingFromEnd: Edge[]
): Edge[] {
  const submapNodeId = getSubmapNodeId(submapId, instanceId);
  const newEdges: Edge[] = [];

  if (incomingToStart) {
    newEdges.push({
      id: `${incomingToStart.source}=>${submapNodeId}`,
      source: incomingToStart.source,
      target: submapNodeId,
      markerEnd: "SubmapNode",
      data: { properties: { isError: false } },
    });
  }

  outgoingFromEnd.forEach((edge) => {
    newEdges.push({
      id: `${submapNodeId}=>${edge.target}`,
      source: submapNodeId,
      target: edge.target,
      markerEnd: edge.markerEnd,
      data: edge.data,
    });
  });

  return newEdges;
}

/**
 * Build edges for an expanded submap: parent→startMarker→startNode and endNode→endMarker→children.
 */
export function buildExpandedEdges(
  submap: Submap,
  instanceId: string,
  incomingEdge: Edge | undefined,
  outgoingEdges: Edge[]
): Edge[] {
  const startMarkerId = getSubmapStartMarkerId(submap.id!, instanceId);
  const endMarkerId = getSubmapEndMarkerId(submap.id!, instanceId);
  const newEdges: Edge[] = [];

  if (incomingEdge) {
    newEdges.push({
      id: `${incomingEdge.source}=>${startMarkerId}`,
      source: incomingEdge.source,
      target: startMarkerId,
      markerEnd: "SubmapStartNode",
      data: { properties: { isError: false } },
    });
    newEdges.push({
      id: `${startMarkerId}=>${submap.startNodeId}`,
      source: startMarkerId,
      target: submap.startNodeId,
      markerEnd: "EventNode",
      data: { properties: { isError: false } },
    });
  }

  newEdges.push({
    id: `${submap.endNodeId}=>${endMarkerId}`,
    source: submap.endNodeId,
    target: endMarkerId,
    markerEnd: "SubmapEndNode",
    data: { properties: { isError: false } },
  });

  outgoingEdges.forEach((edge) => {
    newEdges.push({
      id: `${endMarkerId}=>${edge.target}`,
      source: endMarkerId,
      target: edge.target,
      markerEnd: edge.markerEnd,
      data: edge.data,
    });
  });

  return newEdges;
}

/**
 * Collect all edge IDs that touch any node in a given set.
 */
export function getEdgesForNodes(edges: Edge[], nodeIds: Set<string>): Set<string> {
  return new Set(
    edges
      .filter((e) => nodeIds.has(e.source) || nodeIds.has(e.target))
      .map((e) => e.id)
  );
}

// ─── Submap color palette ─────────────────────────────────────────

export type SubmapColor = {
  bg: string;
  border: string;
  labelColor: string;
  nameColor: string;
  containerBg: string;
};

export const SUBMAP_COLORS: SubmapColor[] = [
  { bg: "#f0fdf4", border: "#86efac", labelColor: "#15803d", nameColor: "#4ade80", containerBg: "rgba(240,253,244,0.19)" },
  { bg: "#eff6ff", border: "#93c5fd", labelColor: "#1d4ed8", nameColor: "#60a5fa", containerBg: "rgba(239,246,255,0.19)" },
  { bg: "#fdf2f8", border: "#f9a8d4", labelColor: "#be185d", nameColor: "#f472b6", containerBg: "rgba(253,242,248,0.19)" },
  { bg: "#fffbeb", border: "#fcd34d", labelColor: "#b45309", nameColor: "#fbbf24", containerBg: "rgba(255,251,235,0.19)" },
  { bg: "#eef2ff", border: "#a5b4fc", labelColor: "#4338ca", nameColor: "#818cf8", containerBg: "rgba(238,242,255,0.19)" },
  { bg: "#ecfdf5", border: "#6ee7b7", labelColor: "#047857", nameColor: "#34d399", containerBg: "rgba(236,253,245,0.19)" },
  { bg: "#fff7ed", border: "#fdba74", labelColor: "#c2410c", nameColor: "#fb923c", containerBg: "rgba(255,247,237,0.19)" },
  { bg: "#f5f3ff", border: "#c4b5fd", labelColor: "#6d28d9", nameColor: "#a78bfa", containerBg: "rgba(245,243,255,0.19)" },
  { bg: "#ecfeff", border: "#67e8f9", labelColor: "#0e7490", nameColor: "#22d3ee", containerBg: "rgba(236,254,255,0.19)" },
  { bg: "#fef2f2", border: "#fca5a5", labelColor: "#b91c1c", nameColor: "#f87171", containerBg: "rgba(254,242,242,0.19)" },
];

export const SUBMAP_COLOR_COUNT = SUBMAP_COLORS.length;

/**
 * Pick a random color index that avoids the indices already in use.
 * Falls back to a fully random pick if all colors are taken.
 */
export function pickSubmapColorIndex(usedIndices: number[]): number {
  const used = new Set(usedIndices);
  const available = Array.from({ length: SUBMAP_COLOR_COUNT }, (_, i) => i).filter(
    (i) => !used.has(i)
  );
  const pool = available.length > 0 ? available : Array.from({ length: SUBMAP_COLOR_COUNT }, (_, i) => i);
  return pool[Math.floor(Math.random() * pool.length)];
}

/**
 * Resolve the color palette entry for a submap.
 * Uses the stored colorIndex if present; falls back to a hash of the id for legacy data.
 */
export function getSubmapColor(submapId: string, colorIndex?: number): SubmapColor {
  let idx = colorIndex;
  if (idx === undefined) {
    let hash = 0;
    for (let i = 0; i < submapId.length; i++) {
      hash = (hash * 31 + submapId.charCodeAt(i)) >>> 0;
    }
    idx = hash % SUBMAP_COLOR_COUNT;
  }
  return SUBMAP_COLORS[idx % SUBMAP_COLOR_COUNT];
}

// ─── Pure collapse computation ────────────────────────────────────

export type CollapseResult = {
  submapNode: Node<SubmapNodeData>;
  startMarkerId: string;
  nodesToRemove: Set<string>;
  collapsedEdges: Edge[];
  edgesToRemove: Set<string>;
};

/**
 * Compute everything needed to collapse a submap without touching React state.
 * Returns null if the submap or its markers can't be found.
 */
export function computeCollapseSubmap(
  submap: Submap,
  instanceId: string,
  nodes: Node[],
  edges: Edge[]
): CollapseResult | null {
  const submapId = submap.id!;
  const startMarkerId = getSubmapStartMarkerId(submapId, instanceId);
  const endMarkerId = getSubmapEndMarkerId(submapId, instanceId);
  const submapGroupNodeId = getSubmapGroupNodeId(submapId, instanceId);

  const chain = getChainBetween(submap.startNodeId, submap.endNodeId, nodes, edges);
  const nodesToRemove = new Set([
    ...chain.map((n) => n.id),
    startMarkerId,
    endMarkerId,
    submapGroupNodeId,
  ]);

  const startMarkerNode = nodes.find((n) => n.id === startMarkerId);
  const position = startMarkerNode?.position ?? layoutConfig.startNodePosition;

  const incomingToStartMarker = edges.find((e) => e.target === startMarkerId);
  const outgoingFromEndMarker = edges.filter((e) => e.source === endMarkerId);

  const collapsedEdges = buildCollapsedEdges(submapId, instanceId, incomingToStartMarker, outgoingFromEndMarker);
  const edgesToRemove = getEdgesForNodes(edges, nodesToRemove);
  const submapNode = buildSubmapNode(submapId, instanceId, submap.name ?? "", position);

  return { submapNode, startMarkerId, nodesToRemove, collapsedEdges, edgesToRemove };
}
