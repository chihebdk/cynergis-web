import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "../../components/shadcn/tooltip";

type AddButtonItemProps = {
  show: boolean;
  tooltip?: string;
  children: React.ReactNode;
  onclick: (e: React.MouseEvent) => void;
  className?: string;
};
export const ButtonItem = ({
  show,
  tooltip,
  children,
  onclick,
  className,
}: AddButtonItemProps) => {
  return (
    show &&
    (tooltip ? (
      <Tooltip delayDuration={800}>
        <TooltipTrigger asChild>
          <div
            className={`cursor-pointer hover:opacity-50 active:opacity-70 rounded-full items-center justify-center hover:scale-140 transition-all duration-200 ${className}`}
            onClick={onclick}
          >
            {children}
          </div>
        </TooltipTrigger>
        <TooltipContent side="right">{tooltip}</TooltipContent>
      </Tooltip>
    ) : (
      <div
        className={`cursor-pointer hover:opacity-50 active:opacity-70 rounded-full items-center justify-center hover:scale-140 transition-all duration-200 ${className}`}
        onClick={onclick}
      >
        {children}
      </div>
    ))
  );
};
