import {
  ContextMenuItem,
} from "../../components/shadcn/context-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "../../components/shadcn/tooltip";

type MenuItemProps = {
  name: string;
  shortcut?: string;
  show?: boolean;
  disabled?: boolean;
  disabledTooltip?: string;
  tooltip?: string;
  className?: string;
  onSelect?: () => void;
  children: React.ReactNode;
};

export const MenuItem = ({
  onSelect,
  children,
  className,
  tooltip,
  disabledTooltip,
  name,
  shortcut: _shortcut,
  show,
  disabled,
}: MenuItemProps) => {
  return (
    show && (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <ContextMenuItem
              title={name}
              onClick={(e) => {
                e.stopPropagation();
                if (!disabled) onSelect?.();
              }}
              className={disabled ? `opacity-50 pointer-events-none ${className ?? ""}` : className}
              disabled={disabled}
            >
              {children}
            </ContextMenuItem>
          </TooltipTrigger>
          <TooltipContent side="right">
            {disabled && disabledTooltip ? disabledTooltip : tooltip}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  );
};
