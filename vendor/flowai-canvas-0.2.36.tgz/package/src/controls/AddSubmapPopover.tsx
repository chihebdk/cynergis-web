"use client";

import { useState, useMemo } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "../components/shadcn/popover";
import { useReactFlow } from "@xyflow/react";
import { useSubmapCache } from "../CanvasProvider";
import { useNodeCache } from "../CanvasProvider";
import { SubmapModel as Submap } from "../CanvasProvider";
import { useAddSubmapHandler } from "../hooks/useAddSubmapHandler";
import { AddSubflow } from "../components/icons";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "../components/shadcn/tooltip";
import { SubmapNodeData, SubmapMarkerNodeData } from "../types/NodeTypes";

type AddSubmapPopoverProps = {
  parentId: string;
};

export const AddSubmapPopover = ({ parentId }: AddSubmapPopoverProps) => {
  const [open, setOpen] = useState(false);
  const { getItems } = useSubmapCache();
  const { getItem: getNodeModel } = useNodeCache();
  const { getEdges, getNode } = useReactFlow();
  const addSubmap = useAddSubmapHandler();

  const allSubmaps = getItems() as Submap[];

  const availableSubmaps = useMemo(() => {
    const excludedIds = new Set<string>();

    // Rule 1: A submap cannot add itself as a child.
    // Check if parent is a SubmapNode or SubmapMarkerNode
    const parentNode = getNode(parentId);
    const parentSubmapId =
      (parentNode?.data as SubmapNodeData)?.submapId ??
      (parentNode?.data as SubmapMarkerNodeData)?.submapId;
    if (parentSubmapId) excludedIds.add(parentSubmapId);

    // Also check if parent is a regular EventNode inside a submap
    const nodeModel = getNodeModel(parentId);
    const modelSubmapId = (nodeModel as any)?.submapId as string | undefined;
    if (modelSubmapId) excludedIds.add(modelSubmapId);

    // Rule 2: A submap cannot be added twice as a child of the same parent.
    const edges = getEdges();
    for (const edge of edges) {
      if (edge.source !== parentId) continue;
      const targetNode = getNode(edge.target);
      if (!targetNode) continue;
      const targetSubmapId = (targetNode.data as SubmapNodeData)?.submapId;
      if (targetSubmapId) excludedIds.add(targetSubmapId);
    }

    // Rule 3: Prevent circular references — a submap cannot be added if its
    // chain (or any nested submap's chain) contains a node belonging to an
    // ancestor submap of the parent. Walk up the parent's submap containment
    // to collect all ancestor submapIds.
    const ancestorSubmapIds = new Set<string>();
    if (modelSubmapId) {
      ancestorSubmapIds.add(modelSubmapId);
      // Walk up: find the submap whose id === modelSubmapId, check if its
      // startNode's parent belongs to another submap, and so on.
      let currentSubmapId: string | undefined = modelSubmapId;
      const visited = new Set<string>();
      while (currentSubmapId && !visited.has(currentSubmapId)) {
        visited.add(currentSubmapId);
        const sm = allSubmaps.find((s) => s.id === currentSubmapId);
        if (!sm) break;
        const startModel = getNodeModel(sm.startNodeId);
        const parentSubmap = (startModel as any)?.submapId as string | undefined;
        if (parentSubmap) {
          ancestorSubmapIds.add(parentSubmap);
          currentSubmapId = parentSubmap;
        } else {
          break;
        }
      }
    }
    // A candidate submap creates a cycle if any of its member nodes belongs
    // to one of the ancestor submaps.
    if (ancestorSubmapIds.size > 0) {
      for (const candidate of allSubmaps) {
        if (excludedIds.has(candidate.id)) continue;
        // Check if the candidate submap's chain references any ancestor submap
        // by checking extraParentNodeIds or if the candidate IS an ancestor.
        if (ancestorSubmapIds.has(candidate.id)) {
          excludedIds.add(candidate.id);
        }
      }
    }

    return allSubmaps.filter((s) => !excludedIds.has(s.id));
  }, [allSubmaps, parentId, getNode, getEdges, getNodeModel]);

  const handleSelect = (e: React.MouseEvent, submapId: string) => {
    e.stopPropagation();
    addSubmap(parentId, submapId);
    setOpen(false);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <Tooltip delayDuration={800}>
        <TooltipTrigger asChild>
          <PopoverTrigger asChild>
            <div
              className="cursor-pointer hover:opacity-50 active:opacity-70 rounded-full items-center justify-center hover:scale-140 transition-all duration-200"
              onClick={(e) => {
                e.stopPropagation();
                setOpen((v) => !v);
              }}
            >
              <AddSubflow width={19} color="#64748b" />
            </div>
          </PopoverTrigger>
        </TooltipTrigger>
        <TooltipContent side="right">Add Submap</TooltipContent>
      </Tooltip>
      <PopoverContent
        side="right"
        align="start"
        className="w-52 p-1"
        onOpenAutoFocus={(e) => e.preventDefault()}
      >
        {availableSubmaps.length === 0 ? (
          <p className="text-xs text-muted-foreground px-2 py-1">No submaps available</p>
        ) : (
          <ul className="flex flex-col gap-0.5">
            {availableSubmaps.map((submap) => (
              <li
                key={submap.id}
                className="cursor-pointer text-sm rounded px-2 py-1.5 hover:bg-accent truncate"
                onClick={(e) => handleSelect(e, submap.id)}
              >
                {submap.name ?? submap.id}
              </li>
            ))}
          </ul>
        )}
      </PopoverContent>
    </Popover>
  );
};
