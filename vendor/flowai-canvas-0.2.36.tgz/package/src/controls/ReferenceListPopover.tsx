"use client";

import { useState, useRef, useCallback, ReactNode } from "react";
import { useReactFlow } from "@xyflow/react";
import { useNodeCache } from "../CanvasProvider";
import { useFocusNode } from "../hooks/useFocusNode";
import {
  Dialog,
  DialogPortal,
  DialogOverlay,
} from "../components/shadcn/dialog";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { ReferenceNodePreview } from "./ReferenceNodePreview";
import { baseNodeSize } from "../config/settings";

type ReferenceListPopoverProps = {
  targetId: string;
  referenceNodes: any[];
  children: ReactNode;
};

export const ReferenceListPopover = ({
  targetId,
  referenceNodes,
  children,
}: ReferenceListPopoverProps) => {
  const [open, setOpen] = useState(false);
  const [panelPos, setPanelPos] = useState<{ top: number; left: number } | null>(null);
  const triggerRef = useRef<HTMLDivElement>(null);
  const { getViewport } = useReactFlow();
  const { getItem: getNodeModel } = useNodeCache();
  const focusNode = useFocusNode();

  const handleOpen = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    if (triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect();
      // Find the React Flow node container to get the node card's exact top.
      const rfNode = triggerRef.current.closest(".react-flow__node") as HTMLElement | null;
      const nodeTop = rfNode ? rfNode.getBoundingClientRect().top : rect.top;
      // nodeLeft = trigger.left + 28 (badge is at left-[-28px] relative to card)
      const nodeLeft = rect.left + 28;
      setPanelPos({ top: nodeTop, left: nodeLeft });
    }
    setOpen(true);
  }, []);

  const zoom = getViewport().zoom;
  const popupWidth = Math.round(baseNodeSize.width * zoom * 0.9) + 32;

  const handleSelect = useCallback(
    (parentId: string) => {
      setOpen(false);
      // Delay focus so the dialog close doesn't trigger a canvas click that deselects
      setTimeout(() => focusNode(parentId), 50);
    },
    [focusNode]
  );

  // For each reference node, look up its parent to show in the preview
  const previewNodes = referenceNodes.map((ref) => {
    const parent = getNodeModel(ref.parentId) as any;
    return {
      parentId: ref.parentId as string,
      displayNode: parent || ref,
    };
  });

  return (
    <>
      <div ref={triggerRef} onClick={handleOpen}>
        {children}
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogPortal>
          <DialogOverlay className="bg-transparent" />
          <DialogPrimitive.Content
            role="dialog"
            className="bg-stone-100 fixed z-50 border-0 rounded-lg shadow-2xl overflow-hidden p-0"
            style={{
              top: panelPos?.top ?? 0,
              left: (panelPos?.left ?? 0) - 30 - popupWidth,
              width: popupWidth,
            }}
            onPointerDownOutside={() => setOpen(false)}
            onEscapeKeyDown={() => setOpen(false)}
            onWheel={(e) => e.stopPropagation()}
          >
            <DialogPrimitive.Title className="sr-only">
              Reference nodes
            </DialogPrimitive.Title>
            {previewNodes.length === 0 ? (
              <p className="text-sm text-muted-foreground p-2">No references</p>
            ) : (
              <div
                className="overflow-y-auto overflow-x-hidden flex flex-col items-center gap-4 p-4"
                style={{ maxHeight: Math.round(baseNodeSize.height * zoom * 0.9) * 3 + 32, scrollbarWidth: "none" }}
              >
                {previewNodes.map(({ parentId, displayNode }) => (
                  <ReferenceNodePreview
                    key={parentId}
                    node={displayNode}
                    zoom={zoom}
                    onClick={() => handleSelect(parentId)}
                  />
                ))}
              </div>
            )}
          </DialogPrimitive.Content>
        </DialogPortal>
      </Dialog>
    </>
  );
};
