import { ContextMenuContent, ContextMenuLabel } from "../components/shadcn/context-menu";
import { MenuItem } from "./items/MenuItem";
import {
  Copy,
  Scissors as Cut,
  Clipboard as Paste,
  Trash2 as Delete,
  Link,
  BoxSelect,
  SquareCheck,
  Minimize2,
  Maximize2,
  Ungroup,
  CircleDot,
} from "lucide-react";
import { useCopyNodeHandler } from "../hooks/useCopyNodeHandler";
import { useCutNodeHandler } from "../hooks/useCutNodeHandler";
import { usePasteNodeHandler } from "../hooks/usePasteNodeHandler";
import { useDeleteNodeHandler } from "../hooks/useDeleteNodeHandler";
import { useDeleteNodeActions } from "../hooks/useDeleteNodeActions";
import { useSubmapHandler } from "../hooks/useSubmapHandler";
import { useEndNodeHandler } from "../hooks/useEndNodeHandler";
import { useSubmapActions } from "../hooks/useSubmapActions";
import { useNodeCache } from "../CanvasProvider";
import { useSubmapCache } from "../CanvasProvider";
import { useReactFlow } from "@xyflow/react";
import { getSubmapEndEligibility } from "../utils";
import { extractSubmapInstanceId, getSubmapNodeId } from "../utils/submapUtils";
import { SubmapModel as Submap } from "../CanvasProvider";

type NodeContextMenuProps = {
  id: string;
  items: string[];
};

export const NodeContextMenu = ({ id, items }: NodeContextMenuProps) => {
  const copyAction = useCopyNodeHandler(id, (_open) => void 0);
  const cutAction = useCutNodeHandler(id, (_open) => void 0);
  const { paste, hasCutNode } = usePasteNodeHandler();
  const deleteAction = useDeleteNodeHandler(id, (_open) => void 0);
  const { reattachChildren, isReattachMode, hasDeleteNode } = useDeleteNodeActions();
  const { isSubmapMode, startNodeId, startSubmap, endSubmap } = useSubmapHandler();
  const { collapseSubmap, expandSubmap, removeSubmap, ungroupSubmap } = useSubmapActions();
  const { getItem: getNodeModel, getItems: getNodeItems } = useNodeCache();
  const { getItems: getSubmaps } = useSubmapCache();
  const { getNodes, getEdges } = useReactFlow();

  const { markAsEndNode, unmarkAsEndNode } = useEndNodeHandler(id);
  const nodeModel = getNodeModel(id);
  const nodeSubmapId = (nodeModel as any)?.submapId as string | null | undefined;

  // Resolve isEndNode: for regular nodes check directly, for SubmapNodes check the submap's endNodeId
  let isEndNode = !!(nodeModel as any)?.isEndNode;
  if (!nodeModel) {
    const instanceId = extractSubmapInstanceId(id);
    if (instanceId) {
      const submap = (getSubmaps() as Submap[]).find(
        (s) => s.id && getSubmapNodeId(s.id, instanceId) === id
      );
      if (submap) {
        const endModel = getNodeModel(submap.endNodeId);
        isEndNode = !!(endModel as any)?.isEndNode;
      }
    }
  }

  const hasChildren = getEdges().some((e) => e.source === id);

  const allNodeModels = getNodeItems() as any[];
  const eligibility = isSubmapMode && startNodeId
    ? getSubmapEndEligibility(id, startNodeId, getNodes(), getEdges(), allNodeModels)
    : null;
  const isEligibleEnd = eligibility?.eligible ?? false;
  const isDescendant = eligibility?.isDescendant ?? false;
  const eligibilityReason = eligibility?.reason;

  return (
    <ContextMenuContent>
      <MenuItem
        name="Copy"
        tooltip="Copy Node"
        show={items?.includes("copyNode") && !isSubmapMode}
        onSelect={copyAction}
      >
        <Copy /> Copy
      </MenuItem>
      <MenuItem
        name="Cut"
        tooltip="Cut Node"
        show={items?.includes("cutNode") && !isSubmapMode}
        onSelect={cutAction}
      >
        <Cut /> Cut
      </MenuItem>

      <MenuItem
        name="Paste"
        tooltip="Paste Node"
        show={items?.includes("pasteNode") && hasCutNode && !isSubmapMode}
        onSelect={() => paste({ type: "node", targetNodeId: id })}
      >
        <Paste /> Paste
      </MenuItem>

      <MenuItem
        className="text-red-500"
        name="Delete"
        tooltip="Delete Node"
        show={items?.includes("deleteNode") && !hasDeleteNode && !isSubmapMode}
        onSelect={deleteAction}
      >
        <Delete color="red" /> Delete
      </MenuItem>

      <MenuItem
        name="Reattach here"
        tooltip="Reattach children to this node"
        show={isReattachMode && !isSubmapMode}
        onSelect={() => reattachChildren(id)}
      >
        <Link /> Reattach children here
      </MenuItem>

      <MenuItem
        name="Submap Start"
        tooltip="Mark as submap start node"
        show={items?.includes("submapStart") && !isSubmapMode && !hasCutNode && !hasDeleteNode}
        onSelect={() => startSubmap(id)}
      >
        <BoxSelect /> Submap Start
      </MenuItem>

      <MenuItem
        name="Submap End"
        tooltip="Mark as submap end node"
        show={items?.includes("submapEnd") && isSubmapMode && isDescendant}
        disabled={!isEligibleEnd}
        disabledTooltip={eligibilityReason}
        onSelect={() => endSubmap(id)}
      >
        <SquareCheck /> Submap End
      </MenuItem>
      {items?.includes("submapEnd") && isSubmapMode && isDescendant && !isEligibleEnd && eligibilityReason && (
        <ContextMenuLabel className="text-xs text-red-600 bg-red-50 dark:bg-red-950/30 dark:text-red-400 rounded px-2 py-1 mx-2 max-w-55 leading-tight">
          {eligibilityReason}
        </ContextMenuLabel>
      )}

      <MenuItem
        name="Collapse Submap"
        tooltip="Collapse submap into a single node"
        show={!!nodeSubmapId && !isSubmapMode}
        onSelect={() => {
          const node = getNodes().find((n) => n.id === id);
          const submapId = (node?.data as any)?.submapId as string | undefined;
          const instanceId = (node?.data as any)?.submapInstanceId as string | undefined;
          if (submapId && instanceId) collapseSubmap(submapId, instanceId);
        }}
      >
        <Minimize2 /> Collapse Submap
      </MenuItem>

      <MenuItem
        name="Expand Submap"
        tooltip="Expand collapsed submap"
        show={items?.includes("submapExpand")}
        onSelect={() => {
          const node = getNodes().find((n) => n.id === id);
          const submapId = (node?.data as any)?.submapId as string | undefined;
          const instanceId = (node?.data as any)?.submapInstanceId as string | undefined;
          if (submapId && instanceId) expandSubmap(submapId, instanceId);
        }}
      >
        <Maximize2 /> Expand Submap
      </MenuItem>

      <MenuItem
        name="Mark as End Node"
        tooltip="Mark this node as a path end"
        show={items?.includes("markEndNode") && !isEndNode && !hasChildren && !isSubmapMode && !hasCutNode && !hasDeleteNode}
        onSelect={markAsEndNode}
      >
        <CircleDot /> Mark as End Node
      </MenuItem>

      <MenuItem
        name="Unmark as End Node"
        tooltip="Remove end node marker"
        show={isEndNode && !isSubmapMode}
        onSelect={unmarkAsEndNode}
      >
        <CircleDot /> Unmark as End Node
      </MenuItem>

      <MenuItem
        name="Ungroup Submap"
        tooltip="Dissolve submap, keep nodes as regular"
        show={!!nodeSubmapId && !isSubmapMode}
        onSelect={() => {
          if (!nodeSubmapId) return;
          // Resolve instanceId: find the SubmapGroupNode whose memberNodeIds includes this node
          const allNodes = getNodes();
          const groupNode = allNodes.find(
            (n) => n.type === "SubmapGroupNode" &&
            (n.data as any)?.submapId === nodeSubmapId &&
            ((n.data as any)?.memberNodeIds as string[] ?? []).includes(id)
          );
          const instanceId = (groupNode?.data as any)?.submapInstanceId as string | undefined;
          if (instanceId) ungroupSubmap(nodeSubmapId, instanceId);
        }}
      >
        <Ungroup /> Ungroup Submap
      </MenuItem>
    </ContextMenuContent>
  );
};
