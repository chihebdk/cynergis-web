import { ButtonItem } from "./items";
import {
  AddNode,
  AddCondition,
  AddError,
  AddReference,
  AddSubflow,
  ExpandSubflow,
  CollapseSubflow,
} from "../components/icons";
import { createId } from "@paralleldrive/cuid2";
import { useReactFlow } from "@xyflow/react";
import { baseNodeSize } from "../config/settings";
import { useInsertNodeHandler } from "../hooks/useInsertNodeHandler";
import { usePasteNodeHandler } from "../hooks/usePasteNodeHandler";
import { Clipboard } from "lucide-react";

type EdgeToolbarProps = {
  id: string;
  toolbar: string[];
};

export const EdgeToolbar = ({ id, toolbar }: EdgeToolbarProps) => {
  const { getNode, getEdge } = useReactFlow();
  const insertNode = useInsertNodeHandler();
  const { paste, hasCutNode } = usePasteNodeHandler();

  return (
    <div
      data-edge-toolbar={id}
      className="grid grid-rows-5 grid-flow-col gap-2 bg-gray-50 rounded-lg p-1 pl-2 z-50"
      style={{ zIndex: 10 }}
    >
      <ButtonItem
        show={toolbar?.includes("addNode")}
        children={<AddNode width={18} color="#64748b" />}
        onclick={(e: React.MouseEvent) => {
          e.stopPropagation();
          insertNode({
            edgeId: id,
            node: {
              id: createId(),
              width: baseNodeSize.width,
              height: baseNodeSize.height,
              position: getNode(getEdge(id)?.source || "")?.position || {x: 0, y: 0},
              type: "EventNode",
              zIndex: 1,
              data: {
                properties: { layoutCategory: "hierarchy" },
              },
            },
          });
        }}
      />
      <ButtonItem
        show={toolbar?.includes("addCondition")}
        children={<AddCondition width={19} color="#64748b" />}
        onclick={() => {}}
      />
      <ButtonItem
        show={toolbar?.includes("addError")}
        children={<AddError width={19} color="red" />}
        onclick={() => {}}
      />
      <ButtonItem
        show={toolbar?.includes("addReference")}
        children={<AddReference width={19} color="#64748b" />}
        onclick={() => {}}
      />
      <ButtonItem
        show={toolbar?.includes("addSubflow")}
        children={<AddSubflow width={19} color="#64748b" />}
        onclick={() => {}}
      />
      <ButtonItem
        show={toolbar?.includes("expandSubflow")}
        children={<ExpandSubflow width={19} color="#64748b" />}
        onclick={() => {}}
      />
      <ButtonItem
        show={toolbar?.includes("collapseSubflow")}
        children={<CollapseSubflow width={19} color="#64748b" />}
        onclick={() => {}}
      />
      <ButtonItem
        show={hasCutNode}
        children={<Clipboard width={18} color="#64748b" />}
        onclick={(e: React.MouseEvent) => {
          e.stopPropagation();
          paste({ type: "edge", edgeId: id });
        }}
      />
    </div>
  );
};
