"use client";

import { useState, useMemo, useRef, useCallback } from "react";
import { useReactFlow } from "@xyflow/react";
import { useNodeCache } from "../CanvasProvider";
import { useSubmapCache } from "../CanvasProvider";
import { SubmapModel as Submap } from "../CanvasProvider";
import { extractSubmapInstanceId } from "../utils/submapUtils";
import { useAddReferenceNodeHandler } from "../hooks/useAddReferenceNodeHandler";
import { AddReference } from "../components/icons";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "../components/shadcn/tooltip";
import {
  Dialog,
  DialogPortal,
  DialogOverlay,
} from "../components/shadcn/dialog";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { ReferenceNodePreview } from "./ReferenceNodePreview";
import { baseNodeSize } from "../config/settings";

type AddReferencePopoverProps = {
  parentId: string;
};

export const AddReferencePopover = ({ parentId }: AddReferencePopoverProps) => {
  const [open, setOpen] = useState(false);
  const [panelPos, setPanelPos] = useState<{ top: number; left: number } | null>(null);
  const triggerRef = useRef<HTMLDivElement>(null);
  const { getItems, getItem: getNodeModel } = useNodeCache();
  const { getNode, getViewport } = useReactFlow();
  const { getItems: getSubmaps } = useSubmapCache();
  const addReference = useAddReferenceNodeHandler();

  const allNodes = getItems() as any[];

  const availableNodes = useMemo(() => {
    const parentNode = getNode(parentId);
    const parentSubmapId = (parentNode?.data as any)?.submapId as string | undefined;

    let dbParentId: string = parentId;
    if (parentNode?.type === "SubmapEndNode") {
      const instanceId = extractSubmapInstanceId(parentId);
      if (instanceId) {
        const matched = (getSubmaps() as Submap[]).find(
          (s) => s.id && `submap-end-${s.id}-${instanceId}` === parentId
        );
        if (matched) dbParentId = matched.endNodeId;
      }
    } else if (parentNode?.type === "SubmapStartNode") {
      const instanceId = extractSubmapInstanceId(parentId);
      if (instanceId) {
        const matched = (getSubmaps() as Submap[]).find(
          (s) => s.id && `submap-start-${s.id}-${instanceId}` === parentId
        );
        if (matched) dbParentId = matched.startNodeId;
      }
    } else if (parentNode?.type === "SubmapNode") {
      const submapId = (parentNode.data as any)?.submapId as string | undefined;
      if (submapId) {
        const matched = (getSubmaps() as Submap[]).find((s) => s.id === submapId);
        if (matched) dbParentId = matched.endNodeId;
      }
    }

    const alreadyReferencedTargetIds = new Set(
      allNodes
        .filter((n) => n.parentId === dbParentId && n.refNodeId)
        .map((n) => n.refNodeId as string)
    );

    const parentModel = getNodeModel(dbParentId) as any;
    const parentOwnSubmapId: string | undefined =
      parentNode?.type === "SubmapNode" ? undefined : parentModel?.submapId || undefined;

    return allNodes.filter((node) => {
      if (node.refNodeId) return false;
      if (node.id === parentId) return false;
      if (node.type === "ReferenceNode") return false;
      if (node.isEndNode) return false;
      if (parentSubmapId && node.id === parentSubmapId) return false;
      if (parentOwnSubmapId) {
        if (node.submapId !== parentOwnSubmapId) return false;
      } else {
        if (node.submapId) return false;
      }
      if (alreadyReferencedTargetIds.has(node.id)) return false;
      return true;
    });
  }, [allNodes, parentId, getNode, getSubmaps, getNodeModel]);

  const handleOpen = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    if (triggerRef.current) {
      const toolbar = triggerRef.current.closest('.grid') as HTMLElement | null;
      const rect = (toolbar ?? triggerRef.current).getBoundingClientRect();
      setPanelPos({ top: rect.top, left: rect.left });
    }
    setOpen(true);
  }, []);

  const zoom = getViewport().zoom;

  const handleSelect = useCallback((targetNodeId: string) => {
    addReference(parentId, targetNodeId);
    setOpen(false);
  }, [addReference, parentId]);

  return (
    <>
      <Tooltip delayDuration={800}>
        <TooltipTrigger asChild>
          <div
            ref={triggerRef}
            className="cursor-pointer hover:opacity-50 active:opacity-70 rounded-full items-center justify-center hover:scale-140 transition-all duration-200"
            onClick={handleOpen}
          >
            <AddReference width={19} color="#64748b" />
          </div>
        </TooltipTrigger>
        <TooltipContent side="right">Add Reference</TooltipContent>
      </Tooltip>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogPortal>
          <DialogOverlay className="bg-transparent" />
          <DialogPrimitive.Content
            role="dialog"
            className="bg-stone-100 fixed z-50 border-0 rounded-lg shadow-2xl p-0 overflow-hidden"
            style={{
              top: (panelPos?.top ?? 0) - 20,
              left: (panelPos?.left ?? 0) + 15,
              width: Math.round(baseNodeSize.width * zoom * 0.9) + 32,
            }}
            onPointerDownOutside={() => setOpen(false)}
            onEscapeKeyDown={() => setOpen(false)}
            onWheel={(e) => e.stopPropagation()}
          >
            <DialogPrimitive.Title className="sr-only">Select a node to reference</DialogPrimitive.Title>
            {availableNodes.length === 0 ? (
              <p className="text-sm text-muted-foreground p-2">No nodes available</p>
            ) : (
              <div
                className="overflow-y-auto overflow-x-hidden flex flex-col items-center gap-4 p-4"
                style={{ maxHeight: Math.round(baseNodeSize.height * zoom * 0.9) * 3 + 32, scrollbarWidth: "none" }}
              >
                {availableNodes.map((node) => (
                  <ReferenceNodePreview
                    key={node.id}
                    node={node}
                    zoom={zoom}
                    onClick={() => handleSelect(node.id)}
                  />
                ))}
              </div>
            )}
          </DialogPrimitive.Content>
        </DialogPortal>
      </Dialog>
    </>
  );
};
