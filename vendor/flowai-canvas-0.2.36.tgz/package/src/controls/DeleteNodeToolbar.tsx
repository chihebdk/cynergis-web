"use client";

import React from "react";
import { Button } from "../components/shadcn/button";
import { Trash2, Unlink, X } from "lucide-react";
import { useDeleteNodeActions } from "../hooks/useDeleteNodeActions";

type DeleteNodeToolbarProps = {
  id: string;
};

export const DeleteNodeToolbar: React.FC<DeleteNodeToolbarProps> = ({ id }) => {
  const {
    cancelDelete,
    confirmDelete,
    deleteAll,
    enterReattachMode,
    hasChildren,
    isReattachMode,
  } = useDeleteNodeActions();

  if (isReattachMode) {
    return (
      <div className="flex flex-col gap-1 bg-amber-50 border border-amber-300 rounded-lg p-2 shadow-lg z-50 text-xs">
        <span className="font-medium text-amber-800">
          Right-click a node to reattach children
        </span>
        <Button
          variant="ghost"
          size="sm"
          className="text-xs h-6"
          onClick={(e) => { e.stopPropagation(); cancelDelete(); }}
        >
          <X className="size-3" /> Cancel
        </Button>
      </div>
    );
  }

  if (!hasChildren) {
    return (
      <div className="flex flex-col gap-1 bg-red-50 border border-red-200 rounded-lg p-2 shadow-lg z-50">
        <span className="text-xs font-medium text-red-800">Delete this node?</span>
        <div className="flex gap-1">
          <Button
            variant="destructive"
            size="sm"
            className="text-xs h-6"
            onClick={(e) => { e.stopPropagation(); confirmDelete(); }}
          >
            <Trash2 className="size-3" /> Confirm
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-xs h-6"
            onClick={(e) => { e.stopPropagation(); cancelDelete(); }}
          >
            Cancel
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-1 bg-red-50 border border-red-200 rounded-lg p-2 shadow-lg z-50">
      <span className="text-xs font-medium text-red-800">
        Node has children. Choose an action:
      </span>
      <div className="flex gap-1">
        <Button
          variant="destructive"
          size="sm"
          className="text-xs h-6"
          onClick={(e) => { e.stopPropagation(); deleteAll(); }}
        >
          <Trash2 className="size-3" /> Delete All
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="text-xs h-6"
          onClick={(e) => { e.stopPropagation(); enterReattachMode(); }}
        >
          <Unlink className="size-3" /> Reattach
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="text-xs h-6"
          onClick={(e) => { e.stopPropagation(); cancelDelete(); }}
        >
          Cancel
        </Button>
      </div>
    </div>
  );
};
