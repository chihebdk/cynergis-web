import { Icon } from "@iconify/react";
import { useMoveToTopHandler } from "../hooks/useMoveToTopHandler";
import { memo } from "react";

const MoveToTopToolbar = ({ id }: { id: string }) => {
  const moveToTop = useMoveToTopHandler(id);

  return (
    <div className="grid grid-rows-3 grid-flow-col gap-1 bg-gray-50 rounded-lg p-1">
      <Icon
        icon="material-symbols-light:text-select-move-forward-word-outline-rounded"
        width={27}
        className="text-slate-500 -rotate-90 hover:cursor-pointer transition-all duration-200 hover:scale-130"
        strokeWidth="0.05%"
        onClick={(e) => {
          moveToTop();
          e.stopPropagation();
        }}
      />
    </div>
  );
};

export default memo(MoveToTopToolbar);
