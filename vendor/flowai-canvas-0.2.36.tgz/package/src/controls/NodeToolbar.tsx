import { ButtonItem } from "./items";
import { AddSubmapPopover } from "./AddSubmapPopover";
import { AddReferencePopover } from "./AddReferencePopover";
import {
  AddNode,
  AddCondition,
  AddError,
  ExpandSubflow,
  CollapseSubflow,
} from "../components/icons";
import { useAddNodeHandler } from "../hooks/useAddNodeHandler";
import { useSubmapActions } from "../hooks/useSubmapActions";
import { createId } from "@paralleldrive/cuid2";
import { useReactFlow } from "@xyflow/react";
import { baseNodeSize } from "../config/settings";
import { SubmapNodeData, SubmapMarkerNodeData } from "../types/NodeTypes";

type NodeToolbarProps = {
  id: string;
  toolbar: string[];
};

export const NodeToolbar = ({ id, toolbar }: NodeToolbarProps) => {
  const { getNode } = useReactFlow();
  const addNode = useAddNodeHandler();
  const { expandSubmap, collapseSubmap } = useSubmapActions();

  return (
    <div
      className="grid grid-rows-5 grid-flow-col gap-2 bg-gray-50 rounded-lg p-1 pl-2 z-50"
      style={{ zIndex: 10 }}
    >
      <ButtonItem
        tooltip="Add Node"
        show={toolbar?.includes("addNode")}
        children={<AddNode width={18} color="#64748b" />}
        onclick={(e: React.MouseEvent) => {
          e.stopPropagation();
          addNode({
            parentId: id,
            node: {
              id: createId(),
              width: baseNodeSize.width,
              height: baseNodeSize.height,
              position: getNode(id)?.position ?? { x: 0, y: 0 },
              type: "EventNode",
              zIndex: 1,
              data: {
                properties: { layoutCategory: "hierarchy" },
              },
            },
          });
        }}
      />
      <ButtonItem
        tooltip="Add Condition"
        show={toolbar?.includes("addCondition")}
        children={<AddCondition width={19} color="#64748b" />}
        onclick={() => {}}
      />
      <ButtonItem
        tooltip="Add Error"
        show={toolbar?.includes("addError")}
        children={<AddError width={19} color="red" />}
        onclick={() => {}}
      />
      {toolbar?.includes("addReference") && <AddReferencePopover parentId={id} />}
      {toolbar?.includes("addSubflow") && <AddSubmapPopover parentId={id} />}
      <ButtonItem
        tooltip="Expand Subflow"
        show={toolbar?.includes("expandSubflow")}
        children={<ExpandSubflow width={19} color="#64748b" />}
        onclick={() => {}}
      />
      <ButtonItem
        tooltip="Collapse Subflow"
        show={toolbar?.includes("collapseSubflow")}
        children={<CollapseSubflow width={19} color="#64748b" />}
        onclick={() => {}}
      />
      <ButtonItem
        tooltip="Expand Submap"
        show={toolbar?.includes("submapExpand")}
        children={<ExpandSubflow width={19} color="#d97706" />}
        onclick={(e: React.MouseEvent) => {
          e.stopPropagation();
          const data = getNode(id)?.data as SubmapNodeData | SubmapMarkerNodeData | undefined;
          const submapId = (data as SubmapNodeData)?.submapId ?? (data as SubmapMarkerNodeData)?.submapId;
          const instanceId = (data as SubmapNodeData)?.submapInstanceId ?? (data as SubmapMarkerNodeData)?.submapInstanceId;
          if (submapId && instanceId) expandSubmap(submapId, instanceId);
        }}
      />
      <ButtonItem
        tooltip="Collapse Submap"
        show={toolbar?.includes("submapCollapse")}
        children={<CollapseSubflow width={19} color="#d97706" />}
        onclick={(e: React.MouseEvent) => {
          e.stopPropagation();
          const data = getNode(id)?.data as SubmapNodeData | SubmapMarkerNodeData | undefined;
          const submapId = (data as SubmapNodeData)?.submapId ?? (data as SubmapMarkerNodeData)?.submapId;
          const instanceId = (data as SubmapNodeData)?.submapInstanceId ?? (data as SubmapMarkerNodeData)?.submapInstanceId;
          if (submapId && instanceId) collapseSubmap(submapId, instanceId);
        }}
      />
    </div>
  );
};
