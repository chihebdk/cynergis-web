import { create } from "zustand";

export type LayoutMode = "org" | "htree";

type LayoutState = {
  mode: LayoutMode;
  available: LayoutMode[];
  configured: boolean;
  setMode: (mode: LayoutMode) => void;
  toggle: () => void;
  configure: (available: LayoutMode[], defaultMode: LayoutMode) => void;
};

export const useLayoutStore = create<LayoutState>()((set, get) => ({
  mode: "org",
  available: ["org", "htree"],
  configured: false,
  setMode: (mode) => set({ mode }),
  toggle: () =>
    set((s) => {
      const idx = s.available.indexOf(s.mode);
      const next = s.available[(idx + 1) % s.available.length];
      return { mode: next };
    }),
  configure: (available, defaultMode) => {
    const current = get();
    const availableChanged =
      current.available.length !== available.length ||
      !current.available.every((v, i) => v === available[i]);
    // Apply the configured default on first setup (or when the available set
    // changes); after that, preserve the user's toggled mode across remounts.
    if (!current.configured || availableChanged) {
      set({ available, mode: defaultMode, configured: true });
    }
  },
}));
