import { create } from "zustand";
import React, { Fragment, ReactNode } from "react";

type State = {
  decorators: Record<
    string,
    { visible: boolean; component: () => React.JSX.Element }
  >;
};

type Action = {
  setDecorator: (decorator: string, visible: boolean) => void;
  getDecorators: (filter?: (decorator: string) => boolean) => ReactNode;
  register: (decorator: string, component: () => React.JSX.Element) => void;
  unregister: (decorator: string) => void;
};

export const useDecoratorsStore = create<State & Action>()((set, get) => ({
  decorators: {},
  setDecorator: (decorator: string, visible: boolean) => {
    set((state) => ({
      decorators: {
        ...state.decorators,
        [decorator]: { ...state.decorators[decorator], visible },
      },
    }));
  },
  getDecorators: (filter?: (decorator: string) => boolean) => (
    <>
      {Object.entries(get().decorators)
        .filter(([key, _value]) => {
          if (filter) {
            return filter(key);
          }
          return true;
        })
        .map(([_key, value], index) => {
          const Component = value.component;
          return (
            <Fragment key={index}>
              <Component />
          </Fragment>
        );
      })}
    </>
  ),

  register: (decorator: string, component: () => React.JSX.Element) => {
    set((state) => ({
      decorators: {
        ...state.decorators,
        [decorator]: { visible: false, component },
      },
    }));
  },

  unregister: (decorator: string) => {
    if (decorator in get().decorators) {
      set((state) => ({
        decorators: {
          ...Object.fromEntries(
            Object.entries(state.decorators).filter(
              ([key]) => key !== decorator
            )
          ),
        },
      }));
    }
  },
}));
