"use client";

import { createContext, useContext, ReactNode } from "react";
import type { Store } from "@flowai/state";
import type { CanvasConfig } from "./config/CanvasConfig";
import { defaultCanvasConfig, defaultNodeConfig, defaultEdgeConfig } from "./config/settings";
import type { NodeConfig, EdgeConfig } from "./config/CanvasConfig";

// ─── Generic model types ──────────────────────────────��──────
// These use [key: string]: any so any app-specific fields pass through.

export type NodeModel = {
  id: string;
  submapId?: string | null;
  parentId?: string | null;
  domainId?: string | null;
  isEndNode?: boolean;
  refNodeId?: string | null;
  type?: string;
  submapInstanceParentId?: string | null;
  [key: string]: any;
};

export type SubmapModel = {
  id: string;
  name?: string;
  startNodeId: string;
  endNodeId: string;
  collapsed?: boolean;
  colorIndex?: number;
  mapIds?: string[];
  extraParentNodeIds?: string[];
  [key: string]: any;
};

export type DomainModel = {
  id: string;
  name?: string;
  color?: string;
  [key: string]: any;
};

export type MapModel = {
  id: string;
  name?: string;
  [key: string]: any;
};

// ─── Cache store interface ───────────────────────────────────
// Matches the Store<T> shape from @flowai/state

export type CacheStore<T extends { id: string }> = Store<T>;

// ─── CRUD adapter for canvas ─────────────────────────────────

export type CanvasCrudAdapter = {
  find: (entity: string, filter?: Record<string, unknown>) => Promise<any[]>;
  save: (entity: string, data: Record<string, any>) => Promise<void>;
  remove: (entity: string, id: string) => Promise<void>;
  pushEmbedded: (entity: string, parentId: string, data: Record<string, any>, parentEmbeddedId?: string) => Promise<void>;
  updateEmbedded: (entity: string, parentId: string, data: Record<string, any>, parentEmbeddedId?: string) => Promise<void>;
  pullEmbedded: (entity: string, parentId: string, itemId: string, parentEmbeddedId?: string) => Promise<void>;
};

// ─── Ephemeral store interface ───────────────────────────────

export type EphemeralStoreInstance = {
  setItem: (key: string, value: unknown) => void;
  getItem: (key: string) => unknown;
  readOnce: (key: string) => unknown;
};

// ─── Header components ───────────────────────────────────────

export type HeaderComponents = {
  Header?: React.ComponentType<{ className?: string; children?: ReactNode }>;
  ProfileDropdown?: React.ComponentType;
};

// ─── Sidebar hook ────────────────────────────────────────────

export type SidebarControl = {
  setOpen: (open: boolean) => void;
};

// ─── Canvas services context ─────────────────────────────────

export type CanvasServices = {
  nodeCache: CacheStore<NodeModel>;
  submapCache: CacheStore<SubmapModel>;
  mapCache: CacheStore<MapModel>;
  domainCache?: CacheStore<DomainModel>;
  crudAdapter?: CanvasCrudAdapter;
  ephemeralStore: (key: string) => EphemeralStoreInstance;
  useSidebar?: () => SidebarControl;
  headerComponents?: HeaderComponents;
  nodeTypes?: Record<string, React.ComponentType<any>>;
  canvasConfig?: CanvasConfig;
};

const CanvasServicesContext = createContext<CanvasServices | null>(null);

export const useCanvasServices = (): CanvasServices => {
  const ctx = useContext(CanvasServicesContext);
  if (!ctx) {
    throw new Error("useCanvasServices must be used within a CanvasServicesProvider");
  }
  return ctx;
};

export const CanvasServicesProvider = ({
  value,
  children,
}: {
  value: CanvasServices;
  children: ReactNode;
}) => {
  return (
    <CanvasServicesContext.Provider value={value}>
      {children}
    </CanvasServicesContext.Provider>
  );
};

// ─── Convenience hooks ───────────────────────────────────────
// These replace the direct cache hook imports that canvas files used.

export const useNodeCache = () => useCanvasServices().nodeCache;
export const useSubmapCache = () => useCanvasServices().submapCache;
export const useEventMapCache = () => useCanvasServices().mapCache;
export const useDomainCache = () => useCanvasServices().domainCache!;
export const useCanvasEphemeralStore = (key: string) => useCanvasServices().ephemeralStore(key);
export const useCanvasSidebar = () => {
  const { useSidebar: sidebarHook } = useCanvasServices();
  if (!sidebarHook) return { setOpen: () => {} };
  return sidebarHook();
};
export const useCrudClient = () => useCanvasServices().crudAdapter!;
export const useNodeTypes = () => useCanvasServices().nodeTypes ?? {};
export const useCanvasConfig = (): CanvasConfig => {
  const ctx = useContext(CanvasServicesContext);
  return ctx?.canvasConfig ?? defaultCanvasConfig;
};
export const useNodeTypeConfig = (typeName: string): NodeConfig => {
  const config = useCanvasConfig();
  return config.nodeTypes?.[typeName] ?? config.node ?? defaultNodeConfig;
};
export const useEdgeTypeConfig = (typeName: string): EdgeConfig => {
  const config = useCanvasConfig();
  return config.edgeTypes?.[typeName] ?? config.edge ?? defaultEdgeConfig;
};
