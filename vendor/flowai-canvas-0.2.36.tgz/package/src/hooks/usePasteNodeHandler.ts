"use client";

import { useCallback } from "react";
import { useReactFlow, Edge } from "@xyflow/react";
import { useCanvasEphemeralStore as useEphemeralStore } from "../CanvasProvider";
import { useNodeCache } from "../CanvasProvider";
import { getDescendants } from "../utils";

type PasteTarget =
  | { type: "node"; targetNodeId: string }
  | { type: "edge"; edgeId: string };

export function usePasteNodeHandler() {
  const { getNodes, getEdges, setNodes, setEdges, getNode, getEdge } =
    useReactFlow();
  const cutStore = useEphemeralStore("cutNode");
  const { getItem: getNodeModel } = useNodeCache();

  const paste = useCallback(
    (target: PasteTarget) => {
      const cutNodeId = cutStore.getItem("id") as string | undefined;
      if (!cutNodeId) return;

      const cutNode = getNode(cutNodeId);
      if (!cutNode) return;

      const nodes = getNodes();
      const edges = getEdges();
      const descendantIds =
        (cutStore.getItem("descendantIds") as string[]) || [];
      const cutSubtreeIds = new Set(descendantIds);

      // Cannot paste a node into its own subtree
      if (target.type === "node" && cutSubtreeIds.has(target.targetNodeId)) {
        console.warn("Cannot paste a node into its own subtree");
        return;
      }

      // Remove the old edge from parent to the cut root node
      const oldParentEdge = edges.find((e) => e.target === cutNodeId);
      let newEdges = edges.filter((e) => e.id !== oldParentEdge?.id);

      if (target.type === "node") {
        // Paste as child of target node
        const newParentId = target.targetNodeId;

        const newEdge: Edge = {
          id: `${newParentId}=>${cutNodeId}`,
          source: newParentId,
          target: cutNodeId,
          markerEnd: "EventNode",
          data: {
            properties: {
              isError: cutNode.type === "ErrorNode",
            },
          },
        };
        newEdges.push(newEdge);

        // Update the node model's parentId and submapId
        const nodeModel = getNodeModel(cutNodeId);
        if (nodeModel) {
          (nodeModel as any).parentId = newParentId;
          const newSubmapId = getNodeModel(newParentId)?.submapId ?? null;
          (nodeModel as any).submapId = newSubmapId;
          descendantIds.forEach((descId) => {
            const descModel = getNodeModel(descId);
            if (descModel) (descModel as any).submapId = newSubmapId;
          });
        }
      } else {
        // Paste on edge (insert between source and target)
        const edge = getEdge(target.edgeId);
        if (!edge) return;

        // Remove the target edge
        newEdges = newEdges.filter((e) => e.id !== edge.id);

        // source -> cutNode
        newEdges.push({
          id: `${edge.source}=>${cutNodeId}`,
          source: edge.source,
          target: cutNodeId,
          markerEnd: "EventNode",
          data: {
            properties: { isError: cutNode.type === "ErrorNode" },
          },
        });

        // Find the leaf of the cut subtree's main chain (first child path)
        let leafId = cutNodeId;
        let leafChildren = edges.filter(
          (e) => e.source === leafId && cutSubtreeIds.has(e.target)
        );
        while (leafChildren.length > 0) {
          leafId = leafChildren[0].target;
          leafChildren = edges.filter(
            (e) => e.source === leafId && cutSubtreeIds.has(e.target)
          );
        }

        // leaf -> edge.target
        newEdges.push({
          id: `${leafId}=>${edge.target}`,
          source: leafId,
          target: edge.target,
          markerEnd: edge.markerEnd,
          data: edge.data,
        });

        // Update parentId and submapId of the cut root node
        const nodeModel = getNodeModel(cutNodeId);
        if (nodeModel) {
          (nodeModel as any).parentId = edge.source;
          const newSubmapId = getNodeModel(edge.source)?.submapId ?? null;
          (nodeModel as any).submapId = newSubmapId;
          descendantIds.forEach((descId) => {
            const descModel = getNodeModel(descId);
            if (descModel) (descModel as any).submapId = newSubmapId;
          });
        }

        // Update parentId of the edge's original target (now child of leaf)
        const targetModel = getNodeModel(edge.target);
        if (targetModel) {
          (targetModel as any).parentId = leafId;
        }
      }

      // Clear the isCut visual flag from all cut nodes
      setNodes((nds) =>
        nds.map((n) =>
          cutSubtreeIds.has(n.id)
            ? {
                ...n,
                data: {
                  ...(n.data as object),
                  properties: { ...((n.data as any).properties as object), isCut: false },
                },
              }
            : n
        )
      );

      // Apply the new edges
      setEdges(newEdges);

      // Clear the cut clipboard
      cutStore.setItem("id", undefined);
      cutStore.setItem("descendantIds", undefined);
    },
    [cutStore, getNode, getNodes, getEdges, setNodes, setEdges, getEdge, getNodeModel]
  );

  const hasCutNode = !!cutStore.getItem("id");

  return { paste, hasCutNode };
}
