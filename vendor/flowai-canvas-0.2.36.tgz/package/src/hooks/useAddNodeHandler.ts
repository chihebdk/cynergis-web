"use client";

import { useCallback } from "react";
import { Node, useReactFlow } from "@xyflow/react";

import { NodeModel, useNodeCache } from "../CanvasProvider";
import { useEventMapCache } from "../CanvasProvider";
import { useSubmapCache } from "../CanvasProvider";
import { SubmapModel as Submap } from "../CanvasProvider";
import { extractSubmapInstanceId, getSubmapGroupNodeId } from "../utils/submapUtils";
import { SubmapGroupNodeData, SubmapMarkerNodeData } from "../types/NodeTypes";
import { useSubmapActions } from "./useSubmapActions";

export function useAddNodeHandler() {
  const { setEdges, setNodes, getNodes, getEdges, getNode } = useReactFlow();

  const { selected: eventMap } = useEventMapCache();
  const { getItem: getNodeModel, addItem: addNodeModel } = useNodeCache();
  const { getItems: getSubmaps } = useSubmapCache();
  const { collapseSubmap } = useSubmapActions();

  const onClick = useCallback(
    async ({ parentId, node }: { parentId: string; node: Node }) => {
      // Auto-collapse expanded submaps when adding a node from outside the submap
      const parentCanvasNodePre = getNode(parentId);
      const isParentInsideSubmap =
        parentCanvasNodePre?.type === "SubmapStartNode" ||
        parentCanvasNodePre?.type === "SubmapEndNode" ||
        !!(getNodeModel(parentId) as any)?.submapId;

      if (!isParentInsideSubmap) {
        // Find all expanded submap start markers and collapse them
        const expandedStartMarkers = getNodes().filter((n) => n.type === "SubmapStartNode");
        for (const marker of expandedStartMarkers) {
          const data = marker.data as SubmapMarkerNodeData;
          if (data.submapId && data.submapInstanceId) {
            collapseSubmap(data.submapId, data.submapInstanceId);
          }
        }
      }

      const newEdge = {
        id: `${parentId}=>${node.id}`,
        source: parentId,
        target: node.id,
        type: "WorkflowEdge",
        markerEnd: "EventNode",
        data: { properties: { isError: node.type === "ErrorNode" } },
      };

      setNodes((nds) => [node, ...nds]);
      setEdges((eds) => [...eds, newEdge]);

      // Resolve the real EventNode parentId for DB storage.
      // Submap marker nodes are transient canvas IDs — use the underlying EventNode instead.
      const parentCanvasNode = getNode(parentId);
      let dbParentId: string = parentId;
      if (parentCanvasNode?.type === "SubmapEndNode") {
        const instanceId = extractSubmapInstanceId(parentId);
        if (instanceId) {
          const matchedSubmap = (getSubmaps() as Submap[]).find(
            (s) => s.id && `submap-end-${s.id}-${instanceId}` === parentId
          );
          if (matchedSubmap) {
            dbParentId = matchedSubmap.endNodeId;
          }
        }
      } else if (parentCanvasNode?.type === "SubmapStartNode") {
        const instanceId = extractSubmapInstanceId(parentId);
        if (instanceId) {
          const matchedSubmap = (getSubmaps() as Submap[]).find(
            (s) => s.id && `submap-start-${s.id}-${instanceId}` === parentId
          );
          if (matchedSubmap) {
            dbParentId = matchedSubmap.startNodeId;
          }
        }
      } else if (parentCanvasNode?.type === "SubmapNode") {
        // Collapsed SubmapNode — child is logically after the submap's end node
        const submapId = (parentCanvasNode.data as any)?.submapId as string | undefined;
        if (submapId) {
          const matchedSubmap = (getSubmaps() as Submap[]).find((s) => s.id === submapId);
          if (matchedSubmap) {
            dbParentId = matchedSubmap.endNodeId;
          }
        }
      }

      // Detect if parent is a reference SubmapNode instance.
      // A reference instance's incoming edge comes from a node listed in extraParentNodeIds.
      let submapInstanceParentId: string | null = null;
      if (parentCanvasNode?.type === "SubmapNode") {
        const pSubmapId = (parentCanvasNode.data as any)?.submapId as string | undefined;
        if (pSubmapId) {
          const pSubmap = (getSubmaps() as Submap[]).find((s) => s.id === pSubmapId);
          if (pSubmap) {
            // Find which node feeds into this SubmapNode on the canvas
            const incomingEdge = getEdges().find((e) => e.target === parentId);
            if (incomingEdge) {
              const sourceId = incomingEdge.source;
              const extraParents = pSubmap.extraParentNodeIds ?? [];
              // Check if the source node is an extra parent (reference host)
              const isRef = extraParents.some((entry) => {
                const pipeIdx = entry.indexOf("|");
                const epId = pipeIdx >= 0 ? entry.substring(0, pipeIdx) : entry;
                return epId === sourceId;
              });
              if (isRef) {
                submapInstanceParentId = incomingEdge.source;
              }
            }
          }
        }
      }

      const newNodeEntity = {
        id: node.id,
        name: node.type,
        summary: "",
        description: "",
        type: node.type ?? "defaultType",
        order: 0,
        isPivotal: false,
        parentId: dbParentId,
        eventMapId: eventMap?.id,
        domainId: getNodeModel(dbParentId)?.domainId ?? getNodeModel(parentId)?.domainId,
        // Nodes added after a submap marker or collapsed SubmapNode are outside the submap
        submapId: (parentCanvasNode?.type === "SubmapEndNode" || parentCanvasNode?.type === "SubmapStartNode" || parentCanvasNode?.type === "SubmapNode")
          ? null
          : getNodeModel(dbParentId)?.submapId ?? getNodeModel(parentId)?.submapId ?? null,
        submapInstanceParentId,
        refNodeId: null,
        trigger: null,
        commands: [],
        businessRules: [],
        readModels: [],
        writeModels: [],
        code: [],
        dependencies: [],
        hotspots: [],
        resourceIds: [],
      } as NodeModel;

      addNodeModel(newNodeEntity);

      // If the new node belongs to a submap, update the SubmapGroupNode's memberNodeIds
      // so the group box resizes to contain the new node.
      if (newNodeEntity.submapId) {
        setNodes((nds) =>
          nds.map((n) => {
            if (
              n.type === "SubmapGroupNode" &&
              (n.data as SubmapGroupNodeData).submapId === newNodeEntity.submapId &&
              (n.data as SubmapGroupNodeData).memberNodeIds?.includes(dbParentId)
            ) {
              return {
                ...n,
                data: {
                  ...n.data,
                  memberNodeIds: [...(n.data as SubmapGroupNodeData).memberNodeIds, node.id],
                },
              };
            }
            return n;
          })
        );
      }

      return () => {
        setNodes(getNodes().filter((n) => n.id !== node.id));
        setEdges(
          getEdges().filter((e) => e.source !== node.id && e.target !== node.id)
        );
      };
    },
    [getEdges, getNodes, getNode, setEdges, setNodes, eventMap?.id, getNodeModel, addNodeModel, getSubmaps, collapseSubmap]
  );

  return onClick;
}
