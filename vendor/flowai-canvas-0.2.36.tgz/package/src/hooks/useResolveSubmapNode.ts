import { Edge, Node, useReactFlow } from "@xyflow/react";

export type ResolvedNode = {
  /** The node to act on (either the original node or the collapsed SubmapNode) */
  node: Node;
  /** Node array after collapse (same as input if no collapse happened) */
  nodes: Node[];
  /** Edge IDs to remove (empty if no collapse happened) */
  edgesToRemove: Set<string>;
  /** Edges to add (empty if no collapse happened) */
  collapsedEdges: Edge[];
  /** Whether a collapse was performed */
  collapsed: boolean;
  /** Call this after setNodes/setEdges to mark the submap as collapsed */
  commitCollapse: () => void;
};

/**
 * Returns a resolver that, given a node, returns it along with the current node set.
 * Submap markers (SubmapStartNode/SubmapEndNode) are treated like regular nodes
 * to preserve the expanded state during MoveToTop and scroll rotation.
 *
 * Shared between useChildrenRotationScrollHandler and useMoveToTopHandler.
 */
export function useResolveSubmapNode() {
  const { getNodes } = useReactFlow();

  return function resolve(node: Node): ResolvedNode | null {
    const nodes = getNodes();

    // Treat submap markers like regular nodes — preserve the expanded state.
    // The SubmapStartNode sits in the tree as a child of the submap's parent,
    // so sibling resolution and swapping work without collapsing.
    return {
      node,
      nodes,
      edgesToRemove: new Set(),
      collapsedEdges: [],
      collapsed: false,
      commitCollapse: () => {},
    };
  };
}
