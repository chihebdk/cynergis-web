"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { Node, Edge } from "@xyflow/react";
import { useNodeCache, useSubmapCache, useEventMapCache, useCanvasConfig } from "../CanvasProvider";
import { baseNodeSize, layoutConfig } from "../config/settings";
import { buildSubmapNode, getSubmapNodeId } from "../utils/submapUtils";
import type { BaseNodeData } from "../types/NodeTypes";
import type { SubmapModel, NodeModel } from "../CanvasProvider";

type FlowGraphResult = {
  nodes: Node<BaseNodeData>[];
  edges: Edge[];
  viewport: { x: number; y: number; zoom: number };
} | null;

export function useBuildFlowGraph(): FlowGraphResult {
  const [initialValues, setInitialValues] = useState<FlowGraphResult>(null);

  const { selected: selectedMap } = useEventMapCache();
  const { initialized: nodesInitialized, getItems: getNodeModels } = useNodeCache();
  const { initialized: submapsInitialized, getItems: getSubmapModels } = useSubmapCache();
  const canvasConfig = useCanvasConfig();
  const hasInitRef = useRef(false);

  const init = useCallback(() => {
    if (!selectedMap || !nodesInitialized || !submapsInitialized) return;

    const nodeModels = getNodeModels() as (NodeModel & { summary?: string; isEndNode?: boolean })[];
    const allSubmapModels = getSubmapModels() as (SubmapModel & { id: string })[];
    const submapModels = allSubmapModels.filter(
      (s) => !Array.isArray(s.mapIds) || s.mapIds.includes(selectedMap.id)
    );

    const submapById = new Map(submapModels.map((s) => [s.id, s]));

    const submapMemberIds = new Set(
      nodeModels.filter((n) => n.submapId).map((n) => n.id)
    );

    const submapInstanceId = (submapId: string) => submapId;

    const nodes: Node<BaseNodeData>[] = nodeModels
      .filter((node) => !submapMemberIds.has(node.id) && node.id !== "start")
      .map((node) => ({
        id: node.id,
        type: node.type || "SimpleNode",
        position: layoutConfig.startNodePosition,
        zIndex: 1,
        width: baseNodeSize.width,
        height: baseNodeSize.height,
        data: {
          model: node,
          properties: { layoutCategory: "hierarchy" as const },
        },
      })) as Node<BaseNodeData>[];

    const nodeIdSet = new Set(nodes.map((n) => n.id));
    nodeIdSet.add("start");

    const extraParentEdges: Edge[] = [];

    for (const submap of submapModels) {
      const instanceId = submapInstanceId(submap.id);
      const isUngroupedHere = ((submap as any).ungroupedInMapIds ?? []).includes(selectedMap.id);
      if (!isUngroupedHere) {
        const submapNode = buildSubmapNode(submap.id, instanceId, submap.name ?? "", layoutConfig.startNodePosition);
        nodes.push(submapNode as Node<BaseNodeData>);
        nodeIdSet.add(submapNode.id);
      }

      const extraParents = submap.extraParentNodeIds ?? [];
      for (const entry of extraParents) {
        const pipeIdx = entry.indexOf("|");
        const extraParentId = pipeIdx >= 0 ? entry.substring(0, pipeIdx) : entry;
        if (!nodeIdSet.has(extraParentId)) continue;
        const refInstanceId = `${submap.id}-ref-${extraParentId}`;
        const refSubmapNode = buildSubmapNode(submap.id, refInstanceId, submap.name ?? "", layoutConfig.startNodePosition);
        nodes.push(refSubmapNode as Node<BaseNodeData>);
        nodeIdSet.add(refSubmapNode.id);
        extraParentEdges.push({
          id: `${extraParentId}=>${refSubmapNode.id}`,
          source: extraParentId,
          target: refSubmapNode.id,
          type: "WorkflowEdge",
          markerEnd: "SubmapNode",
          data: { properties: { isError: false } },
        } as Edge);
      }
    }

    const submapEndNodeIds = new Set(submapModels.map((s) => s.endNodeId));

    const edges: Edge[] = [];

    for (const node of nodeModels) {
      if (!node.parentId) continue;
      if (!nodeIdSet.has(node.parentId) && !submapEndNodeIds.has(node.parentId)) continue;
      if (submapMemberIds.has(node.id) && submapMemberIds.has(node.parentId)) continue;

      const nodeSubmap = node.submapId ? submapById.get(node.submapId) : undefined;

      if (nodeSubmap && node.id === nodeSubmap.startNodeId) {
        const submapNodeId = getSubmapNodeId(nodeSubmap.id, submapInstanceId(nodeSubmap.id));
        edges.push({
          id: `${node.parentId}=>${submapNodeId}`,
          source: node.parentId,
          target: submapNodeId,
          type: "WorkflowEdge",
          markerEnd: "SubmapNode",
          data: { properties: { isError: false } },
        } as Edge);
      } else if (!submapMemberIds.has(node.id)) {
        const parentSubmap = submapModels.find((s) => s.endNodeId === node.parentId);
        if (parentSubmap) {
          // If the node has submapInstanceParentId, connect to the reference instance
          const instanceParentId = (node as any).submapInstanceParentId as string | undefined;
          const resolvedInstanceId = instanceParentId
            ? `${parentSubmap.id}-ref-${instanceParentId}`
            : submapInstanceId(parentSubmap.id);
          const submapNodeId = getSubmapNodeId(parentSubmap.id, resolvedInstanceId);
          edges.push({
            id: `${submapNodeId}=>${node.id}`,
            source: submapNodeId,
            target: node.id,
            type: "WorkflowEdge",
            markerEnd: node.type === "ReferenceNode" ? "ReferenceNode" : "EventNode",
            data: { properties: { isError: false } },
          } as Edge);
        } else {
          edges.push({
            id: `${node.parentId}=>${node.id}`,
            source: node.parentId,
            target: node.id,
            type: "WorkflowEdge",
            markerEnd: node.type === "ReferenceNode" ? "ReferenceNode" : "EventNode",
            data: { properties: { isError: false } },
          } as Edge);
        }
      }
    }

    // Terminal nodes for end markers
    const showEndMarker = canvasConfig.nodeTypes?.["SimpleNode"]?.showEndMarker ?? true;
    if (showEndMarker) {
      nodeModels
        .filter((node) => node.isEndNode && !submapMemberIds.has(node.id))
        .forEach((node) => {
          const terminalId = `terminal-${node.id}`;
          nodes.push({
            id: terminalId,
            type: "TerminalNode",
            parentId: node.id,
            position: { x: baseNodeSize.width + 80, y: 0 },
            width: baseNodeSize.width,
            height: baseNodeSize.height,
            zIndex: -1,
            data: {},
          } as Node<BaseNodeData>);
          edges.push({
            id: `${node.id}->${terminalId}`,
            source: node.id,
            target: terminalId,
            type: "TerminalEdge",
            data: {},
          } as Edge);
        });

      for (const submap of submapModels) {
        const endNodeModel = nodeModels.find((n) => n.id === submap.endNodeId);
        if (endNodeModel?.isEndNode) {
          const submapNodeId = getSubmapNodeId(submap.id, submapInstanceId(submap.id));
          const terminalId = `terminal-${submapNodeId}`;
          nodes.push({
            id: terminalId,
            type: "TerminalNode",
            parentId: submapNodeId,
            position: { x: baseNodeSize.width + 80, y: 0 },
            width: baseNodeSize.width,
            height: baseNodeSize.height,
            zIndex: -1,
            data: {},
          } as Node<BaseNodeData>);
          edges.push({
            id: `${submapNodeId}->${terminalId}`,
            source: submapNodeId,
            target: terminalId,
            type: "TerminalEdge",
            data: {},
          } as Edge);
        }
      }
    }

    const startNode: Node<BaseNodeData> = {
      id: "start",
      type: "StartNode",
      draggable: false,
      position: layoutConfig.startNodePosition,
      zIndex: 1,
      width: baseNodeSize.width,
      height: baseNodeSize.height,
      data: { properties: { layoutCategory: "hierarchy" } },
    } as Node<BaseNodeData>;

    setInitialValues({
      nodes: [startNode, ...nodes],
      edges: [...edges, ...extraParentEdges],
      viewport: { x: 0, y: 0, zoom: 1 },
    });
  }, [selectedMap, nodesInitialized, submapsInitialized, getNodeModels, getSubmapModels, canvasConfig]);

  useEffect(() => {
    if (!selectedMap || !nodesInitialized || !submapsInitialized) return;
    if (hasInitRef.current) return;
    hasInitRef.current = true;
    init();
  }, [selectedMap, nodesInitialized, submapsInitialized, init]);

  return initialValues;
}
