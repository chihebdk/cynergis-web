"use client";

import { useCallback } from "react";
import { useReactFlow } from "@xyflow/react";
import { getSiblings } from "../utils";
import { BaseNodeData } from "../types/NodeTypes";
import { Node } from "@xyflow/react";

export function useNodeDragActionsHandler() {
  const { getIntersectingNodes, getEdges, getNodes, setNodes, getNode } =
    useReactFlow();

  const onDragStart = useCallback((node: Node<BaseNodeData>) => {
    node.data.properties.dragging = true;
  }, []);

  const onDragStop = useCallback((node: Node<BaseNodeData>) => {
    node.data.properties.dragging = false;
    const nodes = getNodes();
    const siblings = getSiblings(node, nodes, getEdges());
    if (siblings && siblings.length > 0) {
      const intersections = getIntersectingNodes(node)
        .filter((n) => !n.hidden)
        .filter(
          (n) =>
            (n as Node<BaseNodeData>).data.properties.layoutCategory ===
            "hierarchy"
        );
      if (intersections && intersections.length === 2) {
        const upperNode = siblings.find((n) => n.id === intersections[0].id);
        if (upperNode) {
          const lowerNode = siblings.find((n) => n.id === intersections[1].id);
          if (lowerNode) {
            setNodes((nodes) => {
              const newNodes = nodes.filter((n) => n.id !== node.id);
              const lowerIndex = newNodes.findIndex(
                (n) => n.id === lowerNode.id
              );
              newNodes.splice(lowerIndex, 0, node);
              return newNodes;
            });
          }
        }
      } else {
        const lastNode = siblings.at(-1);
        if (!lastNode) {
          return;
        }
        const boundaryLeft =
          lastNode.position.x - (lastNode.measured?.width || 0) / 2;
        const boundaryRight =
          lastNode.position.x + ((lastNode.measured?.width || 0) * 3) / 2;
        const boundaryTop =
          lastNode.position.y + (lastNode.measured?.height || 0);
        if (
          node.position.x > boundaryLeft &&
          node.position.x < boundaryRight &&
          node.position.y > boundaryTop
        ) {
          setNodes((nodes) => {
            const newNodes = nodes.filter((n) => n.id !== node.id);
            newNodes.push(node);
            return newNodes;
          });
        }
      }
    }
  }, []);

  return { onDragStart, onDragStop };
}
