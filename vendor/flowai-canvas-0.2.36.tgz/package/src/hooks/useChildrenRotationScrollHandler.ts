import { useCallback } from "react";
import { NodeProps, useReactFlow, Node } from "@xyflow/react";
import { getSiblings } from "../utils";
import { BaseNodeData } from "../types/NodeTypes";
import { useResolveSubmapNode } from "./useResolveSubmapNode";

export function useChildrenRotationScrollHandler() {
  const { getNodes, getEdges, getNode, setNodes, setEdges } = useReactFlow();
  const resolveSubmapNode = useResolveSubmapNode();

  const onWheel = useCallback(
    (id: NodeProps["id"], deltaY: number) => {
      if (deltaY === 0) return;

      const node = getNode(id) as Node<BaseNodeData>;
      if (!node) {
        throw Error("Node not found, cannot rotate children");
      }

      if (!(node.data as any).properties?.hasFocus) return;

      const resolved = resolveSubmapNode(node);
      if (!resolved) return;

      const { node: activeNode, nodes: baseNodes, edgesToRemove, collapsedEdges, collapsed, commitCollapse } = resolved;

      // Compute edge set to use for sibling resolution
      const edgesForSiblings = collapsed
        ? [...getEdges().filter((e) => !edgesToRemove.has(e.id)), ...collapsedEdges]
        : getEdges();

      const siblings = getSiblings(activeNode, baseNodes, edgesForSiblings);
      if (!siblings || siblings.length === 0) return;

      const newNodes = [...baseNodes];

      if (deltaY < 0) {
        const nodeIndex = newNodes.findIndex((n) => n.id === activeNode.id);
        newNodes.splice(nodeIndex, 1);
        newNodes.push(activeNode);
      } else {
        const lastSibling = siblings.at(-1);
        if (lastSibling) {
          const lastIndex = newNodes.findIndex((n) => n.id === lastSibling.id);
          newNodes.splice(lastIndex, 1);
          newNodes.unshift(lastSibling);
        }
      }

      setNodes(newNodes);

      if (collapsed) {
        setEdges((eds) => [
          ...eds.filter((e) => !edgesToRemove.has(e.id)),
          ...collapsedEdges,
        ]);
        commitCollapse();
      }
    },
    [getEdges, getNode, getNodes, setEdges, setNodes, resolveSubmapNode]
  );

  return onWheel;
}
