"use client";

import { useCallback } from "react";
import {
  Node,
  NodeProps,
  getOutgoers,
  useReactFlow,
} from "@xyflow/react";
import { v4 as uuid } from "uuid";
//import { useDispatch } from "@cynergis/shared/lib/Store";
import { useCanvasEphemeralStore as useEphemeralStore, useNodeCache, NodeModel } from "../CanvasProvider";

export function useCopyNodeHandler(
  id: NodeProps["id"],
  setOpen: (open: boolean) => void
) {
  const { setEdges, setNodes, getNodes, getEdges, getNode } = useReactFlow();
  const {
    getItem: getNodeModel,
    addItem: addNodeModel,
    getItems: _getItems,
  } = useNodeCache();

  const store = useEphemeralStore("copyNode");

  const onClick = useCallback(() => {
    setOpen(false);

    const node: Node<any> | undefined = getNode(id);
    if (!node) {
      throw new Error("Node not found, cannot append new node");
    }

    const copyNode = {
      id: uuid(),
      width: node.width || 0,
      height: node.height || 0,
      position: { x: node.position.x, y: node.position.y },
      type: "CopyNode",
      data: node.data,
    };

    const nodeModel = getNodeModel(id);
    if (nodeModel) {
      addNodeModel({
        id: copyNode.id,
        parentId: nodeModel.parentId,
        type: nodeModel.type,
        name: nodeModel.name,
        domainId: nodeModel.domainId,
        submapId: nodeModel.submapId ?? null,
        isPivotal: nodeModel.isPivotal,
        order: nodeModel.order,
        summary: nodeModel.summary,
        description: nodeModel.description,
        eventMapId: nodeModel.eventMapId,
        refNodeId: nodeModel.refNodeId,
        trigger: null,
        commands: [],
        businessRules: [],
        readModels: [],
        writeModels: [],
        code: [],
        dependencies: [],
        hotspots: [],
        resourceIds: [],
      } as NodeModel, true);
    }

    setNodes((nodes) => nodes.concat([copyNode]));

    const outgoers = getOutgoers(node, getNodes(), getEdges());
    if (outgoers.length > 1) {
      outgoers.shift();

      const copyChildNodes = outgoers.map((outgoer) => {
        const nodeModel = getNodeModel(outgoer.id);
        const copyId = uuid();
        if (nodeModel) {
          addNodeModel({
            id: copyId,
            parentId: nodeModel.parentId,
            type: nodeModel.type,
            name: nodeModel.name,
            domainId: nodeModel.domainId,
            submapId: nodeModel.submapId ?? null,
            summary: nodeModel.summary,
            description: nodeModel.description,
            eventMapId: nodeModel.eventMapId,
            refNodeId: nodeModel.refNodeId,
          } as NodeModel, true);
        }

        return {
          id: copyId,
          width: outgoer.width || 0,
          height: outgoer.height || 0,
          position: { x: outgoer.position.x, y: outgoer.position.y },
          type: "CopyNode",
          data: {
            ...outgoer.data,
            offset: {
              x: outgoer.position.x - node.position.x,
              y: outgoer.position.y - node.position.y,
            },
          },
        };
      });

      const copyEdges = copyChildNodes.map((copyChildNode) => {
        return {
          id: `${copyNode.id}=>${copyChildNode.id}`,
          source: copyNode.id,
          target: copyChildNode.id,
          type: "CopyEdge",
        };
      });

      setNodes((nodes) => nodes.concat(copyChildNodes));
      setEdges((edges) => edges.concat(copyEdges));
    }

    store.setItem("id", id);
  }, [getEdges, getNode, getNodes, id, setEdges, setNodes]);

  return onClick;
}
