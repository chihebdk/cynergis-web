import { useCallback } from "react";
import { NodeProps, useReactFlow } from "@xyflow/react";
import { getSiblings } from "../utils";
import { useResolveSubmapNode } from "./useResolveSubmapNode";

export function useMoveToTopHandler(id: NodeProps["id"]) {
  const { getNode, getEdges, setNodes, setEdges } = useReactFlow();
  const resolveSubmapNode = useResolveSubmapNode();

  const onClick = useCallback(() => {
    const node = getNode(id);
    if (!node) {
      throw Error("Node not found, cannot expand flow");
    }

    const resolved = resolveSubmapNode(node);
    if (!resolved) return;

    const { node: activeNode, nodes, edgesToRemove, collapsedEdges, collapsed, commitCollapse } = resolved;

    const edgesForSiblings = collapsed
      ? [...getEdges().filter((e) => !edgesToRemove.has(e.id)), ...collapsedEdges]
      : getEdges();

    const siblings = getSiblings(activeNode, nodes, edgesForSiblings);
    if (!siblings) return;

    const focused = siblings[0];
    const expandedIndex = nodes.findIndex((n) => n.id === focused.id);
    const nodeIndex = nodes.findIndex((n) => n.id === activeNode.id);

    nodes[nodeIndex] = focused;
    nodes[expandedIndex] = activeNode;

    nodes.forEach((n) => { n.selected = false; });
    activeNode.selected = true;

    setNodes([...nodes]);

    if (collapsed) {
      setEdges((eds) => [
        ...eds.filter((e) => !edgesToRemove.has(e.id)),
        ...collapsedEdges,
      ]);
      commitCollapse();
    }
  }, [getEdges, getNode, id, resolveSubmapNode, setEdges, setNodes]);

  return onClick;
}
