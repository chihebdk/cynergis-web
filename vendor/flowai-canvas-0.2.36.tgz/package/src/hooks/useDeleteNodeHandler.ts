"use client";

import { useCallback } from "react";
import { NodeProps, useReactFlow } from "@xyflow/react";
import { useCanvasEphemeralStore as useEphemeralStore } from "../CanvasProvider";
import { getDescendants } from "../utils";

export function useDeleteNodeHandler(
  id: NodeProps["id"],
  setOpen: (open: boolean) => void
) {
  const { getNodes, getEdges } = useReactFlow();
  const deleteStore = useEphemeralStore("deleteNode");

  const onClick = useCallback(() => {
    setOpen(false);

    const nodes = getNodes();
    const edges = getEdges();

    // Collect node + all descendants
    const descendants = getDescendants(id, nodes, edges);
    const allIds = [id, ...descendants.map((n) => n.id)];

    // Determine direct children
    const directChildIds = edges
      .filter((e) => e.source === id)
      .map((e) => e.target);

    // Store state in ephemeral store (BaseNode reads from here for visuals)
    deleteStore.setItem("id", id);
    deleteStore.setItem("descendantIds", allIds);
    deleteStore.setItem("childrenIds", directChildIds);
    deleteStore.setItem("mode", "confirm");
  }, [id, setOpen, getNodes, getEdges, deleteStore]);

  return onClick;
}
