import { useCallback } from "react";
import { useReactFlow, Node } from "@xyflow/react";
import { focusNodePath } from "../utils";
import { baseNodeSize } from "../config/settings";
import { useNodeCache } from "../CanvasProvider";
import { useDomainCache } from "../CanvasProvider";
import useSize from "./useWindowSize";

/**
 * Returns a function that focuses the map on a given node:
 * 1. Reorders the nodes array so the target's ancestors are first children
 *    at each level → orgLayout places it on the focused (visible) path.
 * 2. Marks the node as selected (React Flow + Zustand cache).
 * 3. After layout settles, slides the viewport horizontally so the node
 *    is centered on the x-axis. No vertical movement.
 */
export function useFocusNode() {
  const { getNodes, getEdges, setNodes, getNode, getViewport, setViewport } =
    useReactFlow();
  const { setSelected: setSelectedNode, getItem: getNodeModel } =
    useNodeCache();
  const { setSelected: setSelectedDomain } = useDomainCache();
  const [screenWidth] = useSize();

  const focusNode = useCallback(
    (targetId: string) => {
      const nodes = getNodes();
      const edges = getEdges();

      // 1. Reorder so target's path becomes the focused branch
      const reordered = focusNodePath(targetId, nodes, edges);
      const updated = reordered.map((n: Node) => ({
        ...n,
        selected: n.id === targetId,
      }));
      setNodes(updated);

      // 3. Mark as selected in Zustand stores
      setSelectedNode(targetId);
      const model = getNodeModel(targetId);
      if (model?.domainId) {
        setSelectedDomain(model.domainId);
      }

      // 2. After layout animation (200ms) + buffer, slide viewport horizontally
      setTimeout(() => {
        const targetNode = getNode(targetId);
        if (!targetNode) return;

        const viewport = getViewport();
        const nodeCenter =
          targetNode.position.x + (targetNode.width ?? baseNodeSize.width) / 2;

        // x offset that places the node center at the screen center
        const newX = screenWidth / 2 / viewport.zoom - nodeCenter;

        setViewport(
          { x: newX, y: viewport.y, zoom: viewport.zoom },
          { duration: 300 }
        );
      }, 300);
    },
    [
      getNodes,
      getEdges,
      setNodes,
      getNode,
      getViewport,
      setViewport,
      setSelectedNode,
      getNodeModel,
      setSelectedDomain,
      screenWidth,
    ]
  );

  return focusNode;
}
