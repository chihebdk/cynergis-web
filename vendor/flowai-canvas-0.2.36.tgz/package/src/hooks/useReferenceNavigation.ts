"use client";

import { useCallback, useMemo } from "react";
import { useNodeCache, useCanvasEphemeralStore } from "../CanvasProvider";
import { useFocusNode } from "./useFocusNode";

const REF_NAV_KEY = "refNavigation";

/**
 * Hook for the **origin node** side of reference navigation.
 *
 * Returns:
 * - `referenceNodes`  — all nodes whose `refNodeId === id` (i.e., references pointing here)
 * - `referenceCount`  — number of reference nodes pointing here
 * - `showBackButton`  — true when the user navigated to this node from a reference node
 * - `goBackToRef`     — click handler to return to the reference node
 */
export function useReferenceOriginNavigation(id: string) {
  const { getItems } = useNodeCache();
  const refNavStore = useCanvasEphemeralStore(REF_NAV_KEY);
  const focusNode = useFocusNode();

  const allNodes = getItems();
  const referenceNodes = useMemo(
    () => (allNodes as any[]).filter((n: any) => n.refNodeId === id && n.type === "ReferenceNode"),
    [allNodes, id]
  );
  const referenceCount = referenceNodes.length;

  const navTargetId = refNavStore.getItem("targetNodeId") as string | undefined;
  const navRefNodeId = refNavStore.getItem("refNodeId") as string | undefined;
  const showBackButton = navTargetId === id && !!navRefNodeId;

  const goBackToRef = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation();
      if (!navRefNodeId) return;
      focusNode(navRefNodeId);
      refNavStore.setItem("targetNodeId", undefined);
      refNavStore.setItem("refNodeId", undefined);
    },
    [navRefNodeId, focusNode, refNavStore]
  );

  return { referenceNodes, referenceCount, showBackButton, goBackToRef };
}

/**
 * Hook for the **reference node** side of reference navigation.
 *
 * Returns:
 * - `targetId`     — the `refNodeId` that this reference node points to
 * - `goToOriginal` — click handler to navigate to the origin node and store back-nav state
 */
export function useReferenceNodeNavigation(id: string) {
  const { getItem } = useNodeCache();
  const refNavStore = useCanvasEphemeralStore(REF_NAV_KEY);
  const focusNode = useFocusNode();

  const refRow = getItem(id) as any;
  const targetId = refRow?.refNodeId as string | undefined;

  const goToOriginal = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation();
      if (!targetId) return;
      focusNode(targetId);
      // Delay so the nav state isn't cleared by the canvas click handler
      setTimeout(() => {
        refNavStore.setItem("targetNodeId", targetId);
        refNavStore.setItem("refNodeId", id);
      }, 0);
    },
    [targetId, focusNode, refNavStore, id]
  );

  return { targetId, goToOriginal };
}
