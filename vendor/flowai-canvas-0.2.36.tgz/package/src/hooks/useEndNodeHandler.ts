import { useCallback } from "react";
import { useReactFlow } from "@xyflow/react";
import { useNodeCache } from "../CanvasProvider";
import { useSubmapCache } from "../CanvasProvider";
import { SubmapModel as Submap } from "../CanvasProvider";
import { baseNodeSize } from "../config/settings";
import { extractSubmapInstanceId, getSubmapNodeId } from "../utils/submapUtils";

export function useEndNodeHandler(id: string) {
  const { getNodes, setNodes, getEdges, setEdges, getNode } = useReactFlow();
  const { getItem: getNodeModel } = useNodeCache();
  const { getItems: getSubmaps } = useSubmapCache();

  /**
   * Resolve the real EventNode id to mark as isEndNode.
   * For regular nodes, returns `id` directly.
   * For a collapsed SubmapNode, returns the submap's endNodeId.
   */
  const resolveEndNodeId = useCallback((): string | null => {
    // Check if this is a regular node
    if (getNodeModel(id)) return id;

    // Check if this is a collapsed SubmapNode
    const instanceId = extractSubmapInstanceId(id);
    if (instanceId) {
      const submaps = getSubmaps() as Submap[];
      const submap = submaps.find(
        (s) => s.id && getSubmapNodeId(s.id, instanceId) === id
      );
      if (submap) return submap.endNodeId;
    }
    return null;
  }, [id, getNodeModel, getSubmaps]);

  const markAsEndNode = useCallback(() => {
    const realNodeId = resolveEndNodeId();
    if (!realNodeId) return;

    const nodeModel = getNodeModel(realNodeId);
    if (!nodeModel) return;

    nodeModel.isEndNode = true;

    // Attach the terminal node/edge to the visible node (could be SubmapNode or regular node)
    const parentNode = getNode(id);
    const terminalId = `terminal-${id}`;

    const terminalNode = {
      id: terminalId,
      type: "TerminalNode",
      parentId: id,
      position: { x: (parentNode?.width || baseNodeSize.width) + 80, y: 0 },
      width: baseNodeSize.width,
      height: baseNodeSize.height,
      zIndex: -1,
      data: {},
    };

    const terminalEdge = {
      id: `${id}->${terminalId}`,
      source: id,
      target: terminalId,
      type: "TerminalEdge",
      data: {},
    };

    setNodes((nds) => [...nds, terminalNode]);
    setEdges((eds) => [...eds, terminalEdge]);
  }, [id, resolveEndNodeId, getNodeModel, getNode, setNodes, setEdges]);

  const unmarkAsEndNode = useCallback(() => {
    const realNodeId = resolveEndNodeId();
    if (!realNodeId) return;

    const nodeModel = getNodeModel(realNodeId);
    if (!nodeModel) return;

    nodeModel.isEndNode = false;

    const terminalId = `terminal-${id}`;
    setNodes((nds) => nds.filter((n) => n.id !== terminalId));
    setEdges((eds) => eds.filter((e) => e.id !== `${id}->${terminalId}`));
  }, [id, resolveEndNodeId, getNodeModel, setNodes, setEdges]);

  return { markAsEndNode, unmarkAsEndNode };
}
