import * as decorators from "../decorators";
import { useEffect } from "react";
import { useDecoratorsStore } from "../stores/useDecoratorsStore";
import React from "react";

export const useDecorator = (filter?: (decorator: string) => boolean) => {
  const store = useDecoratorsStore();

  useEffect(() => {
    Object.entries(decorators).forEach(([key, Component]) => {
      store.register(key, Component as () => React.JSX.Element);
    });
  }, []);

  return store.getDecorators(filter);
};
