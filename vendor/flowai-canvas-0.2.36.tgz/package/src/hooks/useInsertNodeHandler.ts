import { useCallback } from "react";
import { useReactFlow, Edge, Node } from "@xyflow/react";
import { WorkflowEdgeData } from "../types/EdgeTypes";
import { useEventMapCache, useNodeCache, useSubmapCache, useCrudClient, NodeModel, SubmapModel as Submap } from "../CanvasProvider";
import { extractSubmapInstanceId, getSubmapEndMarkerId, getSubmapNodeId, getSubmapStartMarkerId } from "../utils/submapUtils";
import { SubmapGroupNodeData } from "../types/NodeTypes";

export function useInsertNodeHandler() {
  const { setEdges, setNodes, getEdge, getNodes, getEdges } =
    useReactFlow();

  const {
    getItem: getNodeModel,
    addItem: addNodeModel,
  } = useNodeCache();

  const { selected: eventMap } = useEventMapCache();
  const { getItems: getSubmaps } = useSubmapCache();
  const { updateEmbedded } = useCrudClient();

  const onClick = useCallback(
    ({ edgeId, node }: { edgeId: string; node: Node }) => {
      const edge = getEdge(edgeId) as Edge<WorkflowEdgeData>;

      if (!edge) {
        return;
      }

      const sourceEdge: Edge = {
        id: `${edge.source}->${node.id}`,
        source: edge.source,
        target: node.id,
        type: "WorkflowEdge",
        markerEnd: node.type,
        data: { properties: { isError: node.type === "ErrorNode" } },
      };

      const targetEdge: Edge = {
        id: `${node.id}->${edge.target}`,
        source: node.id,
        target: edge.target,
        type: "WorkflowEdge",
        markerEnd: edge.markerEnd,
        data: { properties: { isError: edge.data?.properties.isError } },
      };

      setNodes((nds) => {
        const targetIndex = nds.findIndex((n) => n.id === edge.target);
        const deselected = nds.map((n) => ({ ...n, selected: false }));
        const newNode = { ...node, selected: true };
        if (targetIndex >= 0) {
          return [
            ...deselected.slice(0, targetIndex),
            newNode,
            ...deselected.slice(targetIndex),
          ];
        }
        return [...deselected, newNode];
      });

      setEdges((eds) => [
        ...eds.filter((e) => e.id !== edge.id),
        sourceEdge,
        targetEdge,
      ]);

      // Resolve real EventNode IDs for marker sources/targets
      const sourceInstanceId = extractSubmapInstanceId(edge.source);
      let dbSourceId = edge.source;
      if (sourceInstanceId) {
        const submaps = getSubmaps() as Submap[];
        const fromEnd = submaps.find((s) => s.id && getSubmapEndMarkerId(s.id, sourceInstanceId) === edge.source);
        if (fromEnd) {
          dbSourceId = fromEnd.endNodeId;
        } else {
          const fromStart = submaps.find((s) => s.id && getSubmapStartMarkerId(s.id, sourceInstanceId) === edge.source);
          if (fromStart) dbSourceId = fromStart.startNodeId;
        }
      }
      // Collapsed SubmapNode — resolve via canvas node type + submapId data
      if (dbSourceId === edge.source && edge.source.startsWith("submap-")) {
        const sourceCanvasNode = getNodes().find((n) => n.id === edge.source);
        if (sourceCanvasNode?.type === "SubmapNode") {
          const submapId = (sourceCanvasNode.data as any)?.submapId as string | undefined;
          if (submapId) {
            const matchedSubmap = (getSubmaps() as Submap[]).find((s) => s.id === submapId);
            if (matchedSubmap) dbSourceId = matchedSubmap.endNodeId;
          }
        }
      }

      const newNodeEntity = {
        id: node.id,
        name: node.type,
        summary: "",
        description: "",
        type: node.type ?? "defaultType",
        order: 0,
        isPivotal: false,
        parentId: dbSourceId,
        eventMapId: eventMap?.id,
        domainId: getNodeModel(dbSourceId)?.domainId,
        submapId: getNodeModel(dbSourceId)?.submapId ?? null,
        refNodeId: null,
        trigger: null,
        commands: [],
        businessRules: [],
        readModels: [],
        writeModels: [],
        code: [],
        dependencies: [],
        hotspots: [],
        resourceIds: [],
      } as NodeModel;

      addNodeModel(newNodeEntity);

      // If the new node belongs to a submap, update the SubmapGroupNode's memberNodeIds
      // so the group box resizes to contain the new node.
      if (newNodeEntity.submapId) {
        setNodes((nds) =>
          nds.map((n) => {
            if (
              n.type === "SubmapGroupNode" &&
              (n.data as SubmapGroupNodeData).submapId === newNodeEntity.submapId &&
              (n.data as SubmapGroupNodeData).memberNodeIds?.includes(dbSourceId)
            ) {
              return {
                ...n,
                data: {
                  ...n.data,
                  memberNodeIds: [...(n.data as SubmapGroupNodeData).memberNodeIds, node.id],
                },
              };
            }
            return n;
          })
        );
      }

      // Update the target node's parentId to newNode so the chain is correct on refresh
      const targetModel = getNodeModel(edge.target) as NodeModel | undefined;
      if (targetModel) {
        targetModel.parentId = node.id;
        // Flush immediately so the change survives a quick reload
        if (eventMap?.id) {
          updateEmbedded("eventNode", eventMap.id, { ...(targetModel as any).record, parentId: node.id });
        }
      }

      // If inserting before a submap marker or collapsed SubmapNode, update the submap model
      const instanceId = extractSubmapInstanceId(edge.target);
      if (instanceId) {
        const submaps = getSubmaps() as Submap[];
        // Before a submap end marker → update endNodeId
        const endSubmap = submaps.find(
          (s) => s.id && getSubmapEndMarkerId(s.id, instanceId) === edge.target
        );
        if (endSubmap) {
          (endSubmap as any).endNodeId = node.id;
        }
        // Before a collapsed SubmapNode → update startNodeId's parentId
        let collapsedSubmap = submaps.find(
          (s) => s.id && getSubmapNodeId(s.id, instanceId) === edge.target
        );
        // Also check via canvas node type for reference SubmapNodes whose IDs
        // don't match the simple getSubmapNodeId pattern (e.g. submap-X-X-ref-Y)
        if (!collapsedSubmap) {
          const targetCanvasNode = getNodes().find((n) => n.id === edge.target);
          if (targetCanvasNode?.type === "SubmapNode") {
            const targetSubmapId = (targetCanvasNode.data as any)?.submapId as string | undefined;
            if (targetSubmapId) {
              collapsedSubmap = submaps.find((s) => s.id === targetSubmapId);
            }
          }
        }
        if (collapsedSubmap) {
          // Check if this is a reference SubmapNode (has extraParentNodeIds entry
          // for the resolved source). For references, update extraParentNodeIds
          // instead of modifying the original chain's startNode parentId.
          const extraParents = collapsedSubmap.extraParentNodeIds ?? [];
          // Entries may be "nodeId" or "nodeId|viaSubmapId" — match by nodeId part
          const isReference = extraParents.some((entry: string) => {
            const nodeId = entry.indexOf("|") >= 0 ? entry.substring(0, entry.indexOf("|")) : entry;
            return nodeId === dbSourceId;
          });
          if (isReference) {
            // Replace the old parent with the new node in extraParentNodeIds
            (collapsedSubmap as any).extraParentNodeIds = extraParents.map(
              (entry: string) => {
                const pipeIdx = entry.indexOf("|");
                const nodeId = pipeIdx >= 0 ? entry.substring(0, pipeIdx) : entry;
                if (nodeId === dbSourceId) {
                  return pipeIdx >= 0 ? `${node.id}${entry.substring(pipeIdx)}` : node.id;
                }
                return entry;
              }
            );
          } else {
            const startModel = getNodeModel(collapsedSubmap.startNodeId) as NodeModel | undefined;
            if (startModel) {
              startModel.parentId = node.id;
              // Flush immediately so the change survives a quick reload
              if (eventMap?.id) {
                updateEmbedded("eventNode", eventMap.id, { ...(startModel as any).record, parentId: node.id });
              }
            }
          }
        }
        // Before an expanded submap start marker → update startNodeId's parentId
        const expandedSubmap = submaps.find(
          (s) => s.id && getSubmapStartMarkerId(s.id, instanceId) === edge.target
        );
        if (expandedSubmap) {
          const startModel = getNodeModel(expandedSubmap.startNodeId) as NodeModel | undefined;
          if (startModel) {
            startModel.parentId = node.id;
            // Flush immediately so the change survives a quick reload
            if (eventMap?.id) {
              updateEmbedded("eventNode", eventMap.id, { ...(startModel as any).record, parentId: node.id });
            }
          }
        }
      }

      return () => {
        setNodes(getNodes().filter((n) => n.id !== node.id));
        setEdges(
          getEdges().filter((e) => e.source !== node.id && e.target !== node.id)
        );
      };
    },
    [setEdges, setNodes, getEdge, getNodes, getEdges, getNodeModel, addNodeModel, getSubmaps, eventMap?.id, updateEmbedded]
  );

  return onClick;
}
