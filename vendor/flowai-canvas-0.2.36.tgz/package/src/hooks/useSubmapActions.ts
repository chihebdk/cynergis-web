"use client";

import { useCallback } from "react";
import { useReactFlow, Node } from "@xyflow/react";
import { useSubmapCache } from "../CanvasProvider";
import { useNodeCache } from "../CanvasProvider";
import { useEventMapCache } from "../CanvasProvider";
import { getChainBetween } from "../utils";
import { baseNodeSize } from "../config/settings";
import {
  buildSubmapStartMarker,
  buildSubmapEndMarker,
  buildSubmapGroupNode,
  buildSubmapNode,
  buildCollapsedEdges,
  buildExpandedEdges,
  getSubmapNodeId,
  getSubmapStartMarkerId,
  getSubmapEndMarkerId,
  getSubmapGroupNodeId,
  getEdgesForNodes,
  computeCollapseSubmap,
} from "../utils/submapUtils";
import { NodeModel as EventNode, SubmapModel as Submap } from "../CanvasProvider";
import { useCrudClient } from "../CanvasProvider";
import { createId } from "@paralleldrive/cuid2";

export function useSubmapActions() {
  const { getNodes, getEdges, setNodes, setEdges } = useReactFlow();
  const { getItem: getSubmap, getItems: getAllSubmaps, deleteItem: deleteSubmap } = useSubmapCache();
  const { getItem: getNodeModel, getItems: getAllNodeModels, addItem: addNodeModel } = useNodeCache();
  const { selected: selectedEventMap } = useEventMapCache();
  const crudAdapter = useCrudClient();

  function getNodeModelsForSubmap(submapId: string): EventNode[] {
    return (getAllNodeModels() as EventNode[]).filter((n) => n.submapId === submapId);
  }

  const collapseSubmap = useCallback(
    (submapId: string, instanceId: string) => {
      const submap = getSubmap(submapId) as Submap | undefined;
      if (!submap) return;

      const result = computeCollapseSubmap(submap, instanceId, getNodes(), getEdges());
      if (!result) return;

      const { submapNode, startMarkerId, nodesToRemove, collapsedEdges, edgesToRemove } = result;

      // Also remove terminal nodes/edges whose parent is being collapsed away
      const terminalNodeIdsToRemove = new Set(
        [...nodesToRemove].map((nid) => `terminal-${nid}`)
      );

      // If the submap's endNodeId is marked as an end node, add a terminal on the collapsed SubmapNode
      const endNodeModel = getNodeModel(submap.endNodeId) as EventNode | undefined;
      const submapNodeId = submapNode.id;
      const addTerminalOnSubmap = !!(endNodeModel as any)?.isEndNode;
      const terminalOnSubmap = addTerminalOnSubmap ? {
        node: {
          id: `terminal-${submapNodeId}`,
          type: "TerminalNode" as const,
          parentId: submapNodeId,
          position: { x: (submapNode.width || baseNodeSize.width) + 80, y: 0 },
          zIndex: -1,
          width: baseNodeSize.width,
          height: baseNodeSize.height,
          data: {},
        },
        edge: {
          id: `${submapNodeId}->${`terminal-${submapNodeId}`}`,
          source: submapNodeId,
          target: `terminal-${submapNodeId}`,
          type: "TerminalEdge" as const,
          data: {},
        },
      } : null;

      setNodes((nds) => {
        const startMarkerIndex = nds.findIndex((n) => n.id === startMarkerId);
        const filtered = nds.filter((n) => !nodesToRemove.has(n.id) && !terminalNodeIdsToRemove.has(n.id));
        const insertAt = startMarkerIndex >= 0
          ? Math.min(startMarkerIndex, filtered.length)
          : filtered.length;
        return [
          ...filtered.slice(0, insertAt),
          submapNode,
          ...filtered.slice(insertAt),
          ...(terminalOnSubmap ? [terminalOnSubmap.node] : []),
        ];
      });
      setEdges((eds) => [
        ...eds.filter((e) => !edgesToRemove.has(e.id) && !terminalNodeIdsToRemove.has(e.target)),
        ...collapsedEdges,
        ...(terminalOnSubmap ? [terminalOnSubmap.edge] : []),
      ]);
    },
    [getNodes, getEdges, setNodes, setEdges, getSubmap]
  );

  const expandSubmap = useCallback(
    (submapId: string, instanceId: string) => {
      const submap = getSubmap(submapId) as Submap | undefined;
      if (!submap) return;

      const nodes = getNodes();
      const edges = getEdges();

      const submapNodeId = getSubmapNodeId(submapId, instanceId);
      const submapNode = nodes.find((n) => n.id === submapNodeId);
      if (!submapNode) return;

      const position = submapNode.position;

      // Gather ALL node models in the chain (including those in nested submaps)
      const allModels = getAllNodeModels() as EventNode[];
      const allModelsById = new Map(allModels.map((m) => [m.id, m]));

      // Identify which submapIds are nested within this submap.
      // A submap N is nested if both N.startNodeId and N.endNodeId have submapId === N.id
      // AND there exists a parentId path from N.startNodeId up to a node with submapId === submapId.
      const allSubmaps = getAllSubmaps() as Submap[];
      const nestedSubmapIds = new Set<string>();
      for (const s of allSubmaps) {
        if (s.id === submapId) continue;
        const startModel = allModelsById.get(s.startNodeId);
        if (!startModel || startModel.submapId !== s.id) continue;
        // Walk up from startModel via parentId to see if we reach a node belonging to this submap
        let ancestor = startModel.parentId ? allModelsById.get(startModel.parentId) : undefined;
        while (ancestor) {
          if (ancestor.submapId === submapId) {
            nestedSubmapIds.add(s.id!);
            break;
          }
          ancestor = ancestor.parentId ? allModelsById.get(ancestor.parentId) : undefined;
        }
      }

      // Walk from startNodeId collecting descendants via parentId, stopping at endNodeId.
      // Only follow children whose submapId matches this submap or a confirmed nested submap.
      const chainModels: EventNode[] = [];
      const chainVisited = new Set<string>();
      function collectChain(nodeId: string) {
        if (chainVisited.has(nodeId)) return;
        chainVisited.add(nodeId);
        const model = allModelsById.get(nodeId);
        if (!model) return;
        chainModels.push(model);
        // Don't descend past the endNodeId — its children are outside this submap
        if (nodeId === submap!.endNodeId) return;
        // Find children: nodes whose parentId === nodeId
        for (const m of allModels) {
          if (m.parentId === nodeId && chainVisited.has(m.id) === false) {
            // Only follow if the child belongs to this submap or a nested submap
            if (m.submapId === submapId || nestedSubmapIds.has(m.submapId!)) {
              collectChain(m.id);
            }
          }
        }
      }
      collectChain(submap.startNodeId);

      // Identify nested submaps: submaps whose start+end nodes are within our chain
      const chainIds = new Set(chainModels.map((m) => m.id));
      const nestedSubmaps = allSubmaps.filter(
        (s) => s.id !== submapId && chainIds.has(s.startNodeId) && chainIds.has(s.endNodeId)
      );

      // Collect IDs of nodes that belong to nested submaps (will be replaced by collapsed SubmapNodes)
      const nestedNodeIds = new Set<string>();
      for (const ns of nestedSubmaps) {
        // Walk chain from ns.startNodeId to ns.endNodeId
        const nsChain: string[] = [];
        const nsVisited = new Set<string>();
        function collectNsChain(nodeId: string) {
          if (nsVisited.has(nodeId)) return;
          nsVisited.add(nodeId);
          nsChain.push(nodeId);
          if (nodeId === ns.endNodeId) return; // don't go beyond end
          for (const m of allModels) {
            if (m.parentId === nodeId && !nsVisited.has(m.id) && chainIds.has(m.id) && m.submapId === ns.id) {
              collectNsChain(m.id);
            }
          }
        }
        collectNsChain(ns.startNodeId);
        nsChain.forEach((id) => nestedNodeIds.add(id));
      }

      // Direct members: chain nodes NOT inside a nested submap
      const directModels = chainModels.filter((m) => !nestedNodeIds.has(m.id));

      // Build the focused path: walk from endNodeId up to startNodeId via parentId
      const focusedIds = new Set<string>();
      let cur: string | undefined | null = submap.endNodeId;
      while (cur) {
        focusedIds.add(cur);
        if (cur === submap.startNodeId) break;
        const model = allModelsById.get(cur);
        cur = model?.parentId;
      }

      // Group direct nodes by parentId, then reorder so focused child comes first
      const byParent = new Map<string, EventNode[]>();
      for (const m of directModels) {
        const pid = m.parentId ?? "__root__";
        if (!byParent.has(pid)) byParent.set(pid, []);
        byParent.get(pid)!.push(m);
      }
      for (const [, siblings] of byParent) {
        siblings.sort((a, b) => {
          const aFocused = focusedIds.has(a.id) ? 0 : 1;
          const bFocused = focusedIds.has(b.id) ? 0 : 1;
          return aFocused - bFocused;
        });
      }

      // Flatten in depth-first order (focused child first) to preserve array ordering
      const orderedModels: EventNode[] = [];
      const visited = new Set<string>();
      function dfs(nodeId: string) {
        const model = directModels.find((m) => m.id === nodeId);
        if (!model || visited.has(nodeId)) return;
        visited.add(nodeId);
        orderedModels.push(model);
        const children = byParent.get(nodeId) || [];
        for (const child of children) dfs(child.id);
      }
      dfs(submap.startNodeId);
      // Add any remaining direct nodes not reachable from startNodeId
      for (const m of directModels) {
        if (!visited.has(m.id)) orderedModels.push(m);
      }

      const memberNodes: Node[] = orderedModels.map((model) => ({
        id: model.id,
        type: model.type,
        position,
        zIndex: 1,
        width: baseNodeSize.width,
        height: baseNodeSize.height,
        data: {
          model,
          properties: { layoutCategory: "hierarchy" },
        },
      }));

      // Build collapsed SubmapNodes for nested submaps
      const nestedSubmapNodes: Node[] = [];
      const nestedSubmapEdges: any[] = [];
      for (const ns of nestedSubmaps) {
        const nsInstanceId = ns.id!;
        const nsNode = buildSubmapNode(ns.id!, nsInstanceId, ns.name ?? "", position);
        nestedSubmapNodes.push(nsNode);

        // Find the parent of the nested submap's start node (edge into the nested submap)
        const nsStartModel = allModelsById.get(ns.startNodeId);
        if (nsStartModel?.parentId) {
          // If the parent is a direct member or the parent submap's start, wire to it
          const parentIsDirectMember = directModels.some((m) => m.id === nsStartModel.parentId);
          if (parentIsDirectMember) {
            nestedSubmapEdges.push({
              id: `${nsStartModel.parentId}->${nsNode.id}`,
              source: nsStartModel.parentId,
              target: nsNode.id,
              markerEnd: "SubmapNode",
              data: { properties: { isError: false } },
            });
          }
        }

        // Find direct members whose parentId is ANY node inside the nested submap
        // (not just the end node — a direct member's parent could be a middle node of the nested submap)
        const nsNodeIds = new Set<string>();
        const nsVisited2 = new Set<string>();
        function collectNsIds(nodeId: string) {
          if (nsVisited2.has(nodeId)) return;
          nsVisited2.add(nodeId);
          nsNodeIds.add(nodeId);
          if (nodeId === ns.endNodeId) return;
          for (const m of allModels) {
            if (m.parentId === nodeId && !nsVisited2.has(m.id) && chainIds.has(m.id) && m.submapId === ns.id) {
              collectNsIds(m.id);
            }
          }
        }
        collectNsIds(ns.startNodeId);

        for (const m of directModels) {
          if (m.parentId && nsNodeIds.has(m.parentId)) {
            nestedSubmapEdges.push({
              id: `${nsNode.id}->${m.id}`,
              source: nsNode.id,
              target: m.id,
              markerEnd: m.type,
              data: { properties: { isError: m.type === "ErrorNode" } },
            });
          }
        }
      }

      // Restore internal edges from parentId (only between direct members)
      const directMemberIds = new Set(directModels.map((m) => m.id));
      const memberEdges = directModels
        .filter((model) => model.parentId && directMemberIds.has(model.parentId))
        .map((model) => ({
          id: `${model.parentId}->${model.id}`,
          source: model.parentId!,
          target: model.id,
          markerEnd: model.type,
          data: { properties: { isError: model.type === "ErrorNode" } },
        }));

      const allMemberIds = new Set([...directMemberIds, ...nestedNodeIds]);

      const incomingEdge = edges.find((e) => e.target === submapNodeId);
      const outgoingEdges = edges.filter((e) => e.source === submapNodeId);

      const markerNodes = [
        buildSubmapStartMarker(submapId, instanceId, submap.name ?? "", position),
        buildSubmapEndMarker(submapId, instanceId, submap.name ?? "", position),
      ];

      const newEdges = buildExpandedEdges(submap, instanceId, incomingEdge, outgoingEdges);

      const submapNodeIds = new Set([submapNodeId]);
      const submapEdgeIds = getEdgesForNodes(edges, submapNodeIds);

      // Restore terminal nodes/edges for direct member nodes marked as end nodes
      const restoredTerminalNodes: Node[] = [];
      const restoredTerminalEdges: any[] = [];
      const endMarkerId = getSubmapEndMarkerId(submapId, instanceId);
      for (const model of directModels) {
        if ((model as any).isEndNode) {
          // For the submap's endNodeId, attach terminal to the SubmapEndNode marker
          const parentNodeId = model.id === submap.endNodeId ? endMarkerId : model.id;
          const terminalId = `terminal-${parentNodeId}`;
          restoredTerminalNodes.push({
            id: terminalId,
            type: "TerminalNode",
            parentId: parentNodeId,
            position: { x: baseNodeSize.width + 80, y: 0 },
            zIndex: -1,
            width: baseNodeSize.width,
            height: baseNodeSize.height,
            data: {},
          });
          restoredTerminalEdges.push({
            id: `${parentNodeId}->${terminalId}`,
            source: parentNodeId,
            target: terminalId,
            type: "TerminalEdge",
            data: {},
          });
        }
      }

      // Check if any nested submap's endNodeId has isEndNode — add terminal on the nested SubmapNode
      for (const ns of nestedSubmaps) {
        const nsEndModel = allModelsById.get(ns.endNodeId);
        if ((nsEndModel as any)?.isEndNode) {
          const nsNodeId = getSubmapNodeId(ns.id!, ns.id!);
          const terminalId = `terminal-${nsNodeId}`;
          restoredTerminalNodes.push({
            id: terminalId,
            type: "TerminalNode",
            parentId: nsNodeId,
            position: { x: baseNodeSize.width + 80, y: 0 },
            zIndex: -1,
            width: baseNodeSize.width,
            height: baseNodeSize.height,
            data: {},
          });
          restoredTerminalEdges.push({
            id: `${nsNodeId}->${terminalId}`,
            source: nsNodeId,
            target: terminalId,
            type: "TerminalEdge",
            data: {},
          });
        }
      }

      // Also remove the terminal node/edge attached to the collapsed SubmapNode (if any)
      const terminalOnSubmapId = `terminal-${submapNodeId}`;

      const allVisibleMemberNodes = [...memberNodes, ...nestedSubmapNodes];

      setNodes((nds) => {
        const submapNodeIndex = nds.findIndex((n) => n.id === submapNodeId);
        const filtered = nds.filter((n) => n.id !== submapNodeId && n.id !== terminalOnSubmapId).map((n) => ({ ...n, selected: false }));
        const insertAt = submapNodeIndex >= 0
          ? Math.min(submapNodeIndex, filtered.length)
          : filtered.length;
        return [
          ...filtered.slice(0, insertAt),
          markerNodes[0],
          ...allVisibleMemberNodes,
          { ...markerNodes[1], selected: true },
          ...filtered.slice(insertAt),
          buildSubmapGroupNode(submapId, instanceId, submap.name ?? "", allVisibleMemberNodes.map((n) => n.id)),
          ...restoredTerminalNodes,
        ];
      });
      setEdges((eds) => [
        // Remove submap-node edges, terminal-on-submap edge, AND any edges between all member nodes (including nested)
        ...eds.filter((e) => !submapEdgeIds.has(e.id) && e.target !== terminalOnSubmapId && !(allMemberIds.has(e.source) && allMemberIds.has(e.target))),
        ...memberEdges,
        ...nestedSubmapEdges,
        ...newEdges,
        ...restoredTerminalEdges,
      ]);
    },
    [getNodes, getEdges, setNodes, setEdges, getSubmap, getNodeModel, getAllSubmaps, getAllNodeModels]
  );

  const removeSubmap = useCallback(
    (submapId: string, instanceId: string) => {
      const submap = getSubmap(submapId) as Submap | undefined;
      if (!submap) return;

      const nodes = getNodes();
      const edges = getEdges();

      const startMarkerId = getSubmapStartMarkerId(submapId, instanceId);
      const endMarkerId = getSubmapEndMarkerId(submapId, instanceId);
      const submapGroupNodeId = getSubmapGroupNodeId(submapId, instanceId);
      const submapNodeId = getSubmapNodeId(submapId, instanceId);

      // Check whether this instance is collapsed or expanded
      const isCollapsed = nodes.some((n) => n.id === submapNodeId);

      if (isCollapsed) {
        // Just remove the collapsed node and its edges
        const nodeIds = new Set([submapNodeId]);
        const edgesToRemove = getEdgesForNodes(edges, nodeIds);
        setNodes((nds) => nds.filter((n) => n.id !== submapNodeId));
        setEdges((eds) => eds.filter((e) => !edgesToRemove.has(e.id)));
        return;
      }

      // Expanded — wire around the markers and remove them
      const incomingToStartMarker = edges.find((e) => e.target === startMarkerId);
      const outgoingFromStartMarker = edges.find((e) => e.source === startMarkerId);
      const incomingToEndMarker = edges.find((e) => e.target === endMarkerId);
      const outgoingFromEndMarker = edges.filter((e) => e.source === endMarkerId);

      const markerIds = new Set([startMarkerId, endMarkerId]);
      const edgesToRemove = getEdgesForNodes(edges, markerIds);

      const restoredEdges: any[] = [];

      if (incomingToStartMarker && outgoingFromStartMarker) {
        restoredEdges.push({
          id: `${incomingToStartMarker.source}=>${outgoingFromStartMarker.target}`,
          source: incomingToStartMarker.source,
          target: outgoingFromStartMarker.target,
          markerEnd: outgoingFromStartMarker.markerEnd,
          data: outgoingFromStartMarker.data,
        });
      }

      if (incomingToEndMarker) {
        outgoingFromEndMarker.forEach((edge) => {
          restoredEdges.push({
            id: `${incomingToEndMarker.source}=>${edge.target}`,
            source: incomingToEndMarker.source,
            target: edge.target,
            markerEnd: edge.markerEnd,
            data: edge.data,
          });
        });
      }

      setNodes((nds) =>
        nds.filter(
          (n) => n.id !== startMarkerId && n.id !== endMarkerId && n.id !== submapGroupNodeId
        )
      );
      setEdges((eds) => [
        ...eds.filter((e) => !edgesToRemove.has(e.id)),
        ...restoredEdges,
      ]);

      // Only delete from cache/DB when this is the last instance on canvas
      const remainingInstances = nodes.filter(
        (n) =>
          (n.type === "SubmapNode" || n.type === "SubmapStartNode") &&
          (n.data as any)?.submapId === submapId &&
          n.id !== submapNodeId &&
          n.id !== startMarkerId
      );

      if (remainingInstances.length === 0) {
        // Remove current map from the submap's mapIds
        const currentMapId = selectedEventMap?.id;
        if (currentMapId) {
          const currentMapIds: string[] = (submap as any).mapIds ?? [];
          const updatedMapIds = currentMapIds.filter((id: string) => id !== currentMapId);
          (submap as any).mapIds = updatedMapIds;

          // If other maps still reference this submap, don't delete it or its member nodes
          if (updatedMapIds.length > 0) return;
        }

        // No maps reference this submap — clear submapId on member nodes and delete
        const chain = getChainBetween(submap.startNodeId, submap.endNodeId, nodes, edges);
        chain.forEach((node) => {
          const nodeModel = getNodeModel(node.id) as EventNode | undefined;
          if (nodeModel) {
            (nodeModel as any).submapId = null;
          }
        });

        if ((submap as any).delete) {
          (submap as any).delete();
        } else {
          deleteSubmap(submapId);
        }
      }
    },
    [getSubmap, setNodes, setEdges, getNodes, getEdges, getNodeModel, deleteSubmap, selectedEventMap]
  );

  const ungroupSubmap = useCallback(
    (submapId: string, instanceId: string) => {
      const submap = getSubmap(submapId) as Submap | undefined;
      if (!submap) return;

      const nodes = getNodes();
      const edges = getEdges();

      const startMarkerId = getSubmapStartMarkerId(submapId, instanceId);
      const endMarkerId = getSubmapEndMarkerId(submapId, instanceId);
      const submapGroupNodeId = getSubmapGroupNodeId(submapId, instanceId);

      // Collect member node IDs: all canvas nodes that belong to this submap
      const memberNodeIds = new Set<string>();
      for (const n of nodes) {
        if (n.type === "SubmapStartNode" || n.type === "SubmapEndNode" || n.type === "SubmapGroupNode") continue;
        const model = getNodeModel(n.id) as EventNode | undefined;
        if (model?.submapId === submapId) memberNodeIds.add(n.id);
      }

      // Deep copy: create new independent nodes with fresh IDs
      const oldToNewId = new Map<string, string>();
      for (const oldId of memberNodeIds) {
        oldToNewId.set(oldId, createId());
      }

      // Create cloned node models and persist them via cache
      for (const oldId of memberNodeIds) {
        const original = getNodeModel(oldId) as EventNode | undefined;
        if (!original) continue;
        const newId = oldToNewId.get(oldId)!;
        const rawOriginal = (original as any).record || original;
        const cloned = {
          ...JSON.parse(JSON.stringify(rawOriginal)),
          id: newId,
          submapId: null,
          // Clear timestamps so proxy.init() treats this as a new item
          createdAt: undefined,
          updatedAt: undefined,
          parentId: rawOriginal.parentId && oldToNewId.has(rawOriginal.parentId)
            ? oldToNewId.get(rawOriginal.parentId)!
            : rawOriginal.parentId,
        };
        addNodeModel(cloned);
      }

      // Build new canvas nodes from the cloned models
      const clonedCanvasNodes: Node[] = [];
      for (const oldId of memberNodeIds) {
        const originalCanvas = nodes.find((n) => n.id === oldId);
        if (!originalCanvas) continue;
        const newId = oldToNewId.get(oldId)!;
        const clonedModel = getNodeModel(newId);
        clonedCanvasNodes.push({
          ...originalCanvas,
          id: newId,
          data: {
            ...originalCanvas.data,
            model: clonedModel ?? originalCanvas.data.model,
          },
        });
      }

      // Build edges between cloned members (remap from old IDs to new IDs)
      const clonedMemberEdges: any[] = [];
      for (const edge of edges) {
        if (memberNodeIds.has(edge.source) && memberNodeIds.has(edge.target)) {
          const newSource = oldToNewId.get(edge.source)!;
          const newTarget = oldToNewId.get(edge.target)!;
          clonedMemberEdges.push({
            ...edge,
            id: `${newSource}=>${newTarget}`,
            source: newSource,
            target: newTarget,
          });
        }
      }

      // Rewire boundary edges: parent → startMarker → first member becomes parent → clonedFirstMember
      const incomingToStartMarker = edges.find((e) => e.target === startMarkerId);
      const outgoingFromStartMarker = edges.find((e) => e.source === startMarkerId);
      const allSubmapRelatedEdges = edges.filter(e => e.source.includes(submapId) || e.target.includes(submapId));
      console.log("[ungroupSubmap] submapId:", submapId.substring(0,8), "instanceId:", instanceId.substring(0,8), "startMarkerId:", startMarkerId, "incomingFromSrc:", incomingToStartMarker?.source.substring(0,8), "allSubmapEdges:", JSON.stringify(allSubmapRelatedEdges.map(e => ({ id: e.id.substring(0,30), src: e.source.substring(0,12), tgt: e.target.substring(0,30) }))));
      const allSubmapNodes2 = nodes.filter(n => (n.data as any)?.submapId === submapId || n.id.includes(submapId));
      console.log("[ungroupSubmap] submapNodes:", JSON.stringify(allSubmapNodes2.map(n => ({ id: n.id, type: n.type, hidden: n.hidden }))));
      const incomingToEndMarker = edges.find((e) => e.target === endMarkerId);
      const outgoingFromEndMarker = edges.filter((e) => e.source === endMarkerId);

      const restoredEdges: any[] = [];
      if (incomingToStartMarker && outgoingFromStartMarker) {
        const newTarget = oldToNewId.get(outgoingFromStartMarker.target) ?? outgoingFromStartMarker.target;
        restoredEdges.push({
          id: `${incomingToStartMarker.source}=>${newTarget}`,
          source: incomingToStartMarker.source,
          target: newTarget,
          markerEnd: outgoingFromStartMarker.markerEnd,
          data: outgoingFromStartMarker.data,
        });
      }
      if (incomingToEndMarker) {
        const newSource = oldToNewId.get(incomingToEndMarker.source) ?? incomingToEndMarker.source;
        outgoingFromEndMarker.forEach((edge) => {
          restoredEdges.push({
            id: `${newSource}=>${edge.target}`,
            source: newSource,
            target: edge.target,
            markerEnd: edge.markerEnd,
            data: edge.data,
          });
        });
      }

      // Update parentId for the first cloned node: its parent should be the parent feeding into startMarker
      if (incomingToStartMarker && outgoingFromStartMarker) {
        const firstClonedId = oldToNewId.get(outgoingFromStartMarker.target);
        if (firstClonedId) {
          const firstClonedModel = getNodeModel(firstClonedId) as any;
          if (firstClonedModel) {
            firstClonedModel.parentId = incomingToStartMarker.source;
          }
        }
      }

      // Handle terminal node re-attachment: if terminal was on endMarker, move to cloned endNode
      const terminalOnEndMarkerId = `terminal-${endMarkerId}`;
      const clonedEndNodeId = oldToNewId.get(submap.endNodeId);
      const terminalOnClonedEndId = clonedEndNodeId ? `terminal-${clonedEndNodeId}` : null;
      const hasTerminalOnEndMarker = nodes.some((n) => n.id === terminalOnEndMarkerId);

      // Collect all infrastructure IDs to remove
      const markerIds = new Set([startMarkerId, endMarkerId]);
      const infraEdgesToRemove = getEdgesForNodes(edges, markerIds);
      // Also remove edges involving original member nodes (they're being replaced by clones)
      const memberEdgesToRemove = new Set<string>();
      for (const edge of edges) {
        if (memberNodeIds.has(edge.source) || memberNodeIds.has(edge.target)) {
          memberEdgesToRemove.add(edge.id);
        }
      }

      setNodes((nds) => {
        let result = nds.filter(
          (n) => n.id !== startMarkerId && n.id !== endMarkerId && n.id !== submapGroupNodeId &&
                 !memberNodeIds.has(n.id) && n.id !== terminalOnEndMarkerId
        );
        // Add cloned canvas nodes
        result = [...result, ...clonedCanvasNodes];
        // Add terminal for cloned end node if needed
        if (hasTerminalOnEndMarker && terminalOnClonedEndId && clonedEndNodeId) {
          result.push({
            id: terminalOnClonedEndId,
            type: "TerminalNode",
            parentId: clonedEndNodeId,
            position: { x: baseNodeSize.width + 80, y: 0 },
            zIndex: -1,
            width: baseNodeSize.width,
            height: baseNodeSize.height,
            data: {},
          });
        }
        return result;
      });

      setEdges((eds) => {
        let result = eds.filter(
          (e) => !infraEdgesToRemove.has(e.id) && !memberEdgesToRemove.has(e.id) &&
                 e.target !== terminalOnEndMarkerId && e.source !== terminalOnEndMarkerId
        );
        result = [...result, ...clonedMemberEdges, ...restoredEdges];
        // Add terminal edge for cloned end node
        if (hasTerminalOnEndMarker && terminalOnClonedEndId && clonedEndNodeId) {
          result.push({
            id: `${clonedEndNodeId}->${terminalOnClonedEndId}`,
            source: clonedEndNodeId,
            target: terminalOnClonedEndId,
            type: "TerminalEdge",
            data: {},
          });
        }
        return result;
      });

      // Determine if this is the primary instance or a reference instance.
      // A reference's parent is one of the extraParentNodeIds.
      const extraParentIds = new Set(
        ((submap as any).extraParentNodeIds ?? []).map((entry: string) => {
          const pipeIdx = entry.indexOf("|");
          return pipeIdx >= 0 ? entry.substring(0, pipeIdx) : entry;
        })
      );
      const parentOfUngrouped = incomingToStartMarker?.source;
      const isReferenceInstance = parentOfUngrouped ? extraParentIds.has(parentOfUngrouped) : false;

      const currentMapId = selectedEventMap?.id;

      if (isReferenceInstance && parentOfUngrouped) {
        // This is a reference instance being ungrouped.
        // Remove it from extraParentNodeIds so reload doesn't recreate it.
        const currentExtraParents: string[] = (submap as any).extraParentNodeIds ?? [];
        const newExtraParents = currentExtraParents.filter((entry: string) => {
          const pipeIdx = entry.indexOf("|");
          const entryParentId = pipeIdx >= 0 ? entry.substring(0, pipeIdx) : entry;
          return entryParentId !== parentOfUngrouped;
        });
        (submap as any).extraParentNodeIds = newExtraParents;
        if (crudAdapter) {
          const record = (submap as any).record ?? submap;
          crudAdapter.save("submap", { ...record, extraParentNodeIds: newExtraParents });
        }
      } else {
        // This is the primary instance being ungrouped.
        // Check if there are remaining reference instances on the canvas.
        const remainingSubmapInstances = nodes.filter(
          (n) =>
            (n.type === "SubmapNode" || n.type === "SubmapStartNode") &&
            (n.data as any)?.submapId === submapId &&
            n.id !== getSubmapNodeId(submapId, instanceId) &&
            n.id !== startMarkerId
        );
        if (remainingSubmapInstances.length > 0) {
          // References still exist: mark the primary as ungrouped in this map.
          // On reload, MapCanvas will skip creating the primary SubmapNode but still
          // create reference instances. The original member nodes retain their submapId
          // so the reference can still be expanded.
          if (currentMapId) {
            const ungroupedIn: string[] = (submap as any).ungroupedInMapIds ?? [];
            if (!ungroupedIn.includes(currentMapId)) {
              const newUngroupedIn = [...ungroupedIn, currentMapId];
              (submap as any).ungroupedInMapIds = newUngroupedIn;
              if (crudAdapter) {
                const record = (submap as any).record ?? submap;
                crudAdapter.save("submap", { ...record, ungroupedInMapIds: newUngroupedIn });
              }
            }
          }
        } else {
          // No references — remove this map from mapIds entirely.
          if (currentMapId) {
            const currentMapIds: string[] = (submap as any).mapIds ?? [];
            const updatedMapIds = currentMapIds.filter((id: string) => id !== currentMapId);
            (submap as any).mapIds = updatedMapIds;
          }
        }
      }
    },
    [getSubmap, getNodes, getEdges, setNodes, setEdges, getNodeModel, getAllNodeModels, addNodeModel, deleteSubmap, selectedEventMap, crudAdapter]
  );

  return { collapseSubmap, expandSubmap, removeSubmap, ungroupSubmap };
}
