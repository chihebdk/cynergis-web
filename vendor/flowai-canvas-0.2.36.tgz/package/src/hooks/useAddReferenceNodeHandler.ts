"use client";

import { useCallback } from "react";
import { useReactFlow } from "@xyflow/react";
import { createId } from "@paralleldrive/cuid2";

import { NodeModel, useNodeCache } from "../CanvasProvider";
import { useEventMapCache } from "../CanvasProvider";
import { useSubmapCache } from "../CanvasProvider";
import { SubmapModel as Submap } from "../CanvasProvider";
import { extractSubmapInstanceId } from "../utils/submapUtils";
import { baseNodeSize } from "../config/settings";

/**
 * Adds a "reference node" to the canvas that points to an existing EventNode
 * in the current map. The reference is persisted as a lightweight EventNode
 * row with `type: "ReferenceNode"` and `refNodeId` set to the target.
 *
 * Reference nodes are leaves: they cannot have children and cannot belong to
 * a submap. They render as a compact card displaying the target node's label.
 */
export function useAddReferenceNodeHandler() {
  const { setEdges, setNodes, getNode } = useReactFlow();
  const { selected: eventMap } = useEventMapCache();
  const { getItem: getNodeModel, addItem: addNodeModel, getItems: getNodeItems } = useNodeCache();
  const { getItems: getSubmaps } = useSubmapCache();

  const addReference = useCallback(
    (parentId: string, targetNodeId: string) => {
      if (!eventMap?.id) return;

      // Resolve the real DB parent ID.
      // When the parent is a collapsed SubmapNode or an expanded submap marker,
      // use the underlying EventNode (startNodeId/endNodeId).
      let dbParentId: string = parentId;
      const parentCanvasNode = getNode(parentId);
      if (parentCanvasNode?.type === "SubmapEndNode") {
        const instanceId = extractSubmapInstanceId(parentId);
        if (instanceId) {
          const matchedSubmap = (getSubmaps() as Submap[]).find(
            (s) => s.id && `submap-end-${s.id}-${instanceId}` === parentId
          );
          if (matchedSubmap) dbParentId = matchedSubmap.endNodeId;
        }
      } else if (parentCanvasNode?.type === "SubmapStartNode") {
        const instanceId = extractSubmapInstanceId(parentId);
        if (instanceId) {
          const matchedSubmap = (getSubmaps() as Submap[]).find(
            (s) => s.id && `submap-start-${s.id}-${instanceId}` === parentId
          );
          if (matchedSubmap) dbParentId = matchedSubmap.startNodeId;
        }
      } else if (parentCanvasNode?.type === "SubmapNode") {
        const submapId = (parentCanvasNode.data as any)?.submapId as string | undefined;
        if (submapId) {
          const matchedSubmap = (getSubmaps() as Submap[]).find((s) => s.id === submapId);
          if (matchedSubmap) dbParentId = matchedSubmap.endNodeId;
        }
      }

      // Rule: a node cannot have the same target referenced twice as a child
      const allNodeModels = getNodeItems() as NodeModel[];
      const duplicate = allNodeModels.some(
        (n) => n.parentId === dbParentId && (n as any).refNodeId === targetNodeId
      );
      if (duplicate) {
        console.warn(
          "Cannot add reference: the same target is already referenced as a child of this node"
        );
        return;
      }

      // Rule: a node inside a submap can only reference nodes in the same submap
      // (and a node outside any submap cannot reference a node inside a submap)
      const parentModel = getNodeModel(dbParentId) as any;
      const targetModel = getNodeModel(targetNodeId) as any;
      const parentOwnSubmapId: string | null =
        parentCanvasNode?.type === "SubmapNode" ? null : parentModel?.submapId || null;
      const targetSubmapId: string | null = targetModel?.submapId || null;
      if (parentOwnSubmapId) {
        if (targetSubmapId !== parentOwnSubmapId) {
          console.warn(
            "Cannot add reference: a node inside a submap can only reference nodes in the same submap"
          );
          return;
        }
      } else if (targetSubmapId) {
        console.warn(
          "Cannot add reference: cannot reference a node that is inside a submap"
        );
        return;
      }

      const referenceId = createId();
      const parentPosition = parentCanvasNode?.position ?? { x: 0, y: 0 };
      const targetCanvasType = targetModel?.type ?? "ReferenceNode";

      const referenceCanvasNode = {
        id: referenceId,
        type: targetCanvasType,
        position: parentPosition,
        zIndex: 1,
        width: baseNodeSize.width,
        height: baseNodeSize.height,
        data: {
          properties: { layoutCategory: "hierarchy" },
        },
      };

      const newEdge = {
        id: `${parentId}=>${referenceId}`,
        source: parentId,
        target: referenceId,
        markerEnd: "ReferenceNode",
        data: { properties: { isError: false } },
      };

      setNodes((nds) => [referenceCanvasNode as any, ...nds]);
      setEdges((eds) => [...eds, newEdge]);

      // Persist as a lightweight EventNode row with refNodeId set.
      // name/summary must be ≥ 3 chars to pass proxy validation (see validators.ts);
      // they are placeholders — the ReferenceNode renders using the target node's label.
      const newNodeEntity = {
        id: referenceId,
        name: "Reference",
        summary: "Reference",
        description: "",
        type: "ReferenceNode",
        order: 0,
        isPivotal: false,
        parentId: dbParentId,
        eventMapId: eventMap.id,
        domainId: null,
        // References never belong to a submap
        submapId: null,
        refNodeId: targetNodeId,
        trigger: null,
        commands: [],
        businessRules: [],
        readModels: [],
        writeModels: [],
        code: [],
        dependencies: [],
        hotspots: [],
        resourceIds: [],
      } as unknown as NodeModel;

      addNodeModel(newNodeEntity);
    },
    [eventMap?.id, getNode, getSubmaps, getNodeModel, getNodeItems, addNodeModel, setNodes, setEdges]
  );

  return addReference;
}
