"use client";

import { useCallback } from "react";
import { useReactFlow, Edge } from "@xyflow/react";
import { useCanvasEphemeralStore as useEphemeralStore } from "../CanvasProvider";
import { useNodeCache } from "../CanvasProvider";
import { useSubmapCache, SubmapModel as Submap } from "../CanvasProvider";
import { useEventMapCache } from "../CanvasProvider";
import { extractSubmapInstanceId, getSubmapNodeId, getSubmapStartMarkerId, getSubmapEndMarkerId } from "../utils/submapUtils";

function clearDeleteStore(deleteStore: ReturnType<typeof useEphemeralStore>) {
  deleteStore.setItem("id", undefined);
  deleteStore.setItem("descendantIds", undefined);
  deleteStore.setItem("childrenIds", undefined);
  deleteStore.setItem("mode", undefined);
}

export function useDeleteNodeActions() {
  const { getEdges, setNodes, setEdges, getNode } = useReactFlow();
  const deleteStore = useEphemeralStore("deleteNode");
  const { getItem: getNodeModel, getItems: getNodeModels } = useNodeCache();
  const { getItems: getSubmaps } = useSubmapCache();
  const { selected: selectedEventMap } = useEventMapCache();

  /**
   * Remove the current map from any submaps whose canvas instances / members
   * are being deleted. The submap definition itself is preserved so it remains
   * available as a library asset in the Submaps dashboard.
   */
  const cleanupOrphanedSubmaps = useCallback(
    (deletedIds: Set<string>) => {
      const currentMapId = selectedEventMap?.id;
      if (!currentMapId) return;
      const submaps = getSubmaps() as Submap[];
      for (const submap of submaps) {
        const isOrphaned =
          deletedIds.has(submap.startNodeId) ||
          deletedIds.has(submap.endNodeId) ||
          [...deletedIds].some((id) => id.startsWith(`submap-${submap.id}-`));
        if (!isOrphaned) continue;
        const mapIds = (submap as any).mapIds ?? [];
        if (mapIds.includes(currentMapId)) {
          (submap as any).mapIds = mapIds.filter((id: string) => id !== currentMapId);
        }
      }
    },
    [getSubmaps, selectedEventMap]
  );

  /**
   * Remove deleted node IDs from all submaps' extraParentNodeIds
   * so dangling references don't persist after deletion.
   */
  const cleanupExtraParentNodeIds = useCallback(
    (deletedIds: Set<string>) => {
      const submaps = getSubmaps() as Submap[];
      for (const submap of submaps) {
        const extra = submap.extraParentNodeIds;
        if (!extra || extra.length === 0) continue;
        // Entries may be "nodeId" or "nodeId|viaSubmapId" — extract nodeId for comparison
        const cleaned = extra.filter((entry: string) => {
          const nodeId = entry.indexOf("|") >= 0 ? entry.substring(0, entry.indexOf("|")) : entry;
          return !deletedIds.has(nodeId);
        });
        if (cleaned.length !== extra.length) {
          (submap as any).extraParentNodeIds = cleaned;
        }
      }
    },
    [getSubmaps]
  );

  /**
   * Cascade-delete reference nodes whose refNodeId points to any deleted node.
   * Reference nodes are EventNode rows with type: "ReferenceNode" and refNodeId set.
   */
  const cleanupReferenceNodes = useCallback(
    (deletedIds: Set<string>) => {
      const allNodes = getNodeModels() as any[];
      const cascaded = new Set<string>();
      for (const node of allNodes) {
        if (
          node.refNodeId &&
          deletedIds.has(node.refNodeId) &&
          !deletedIds.has(node.id)
        ) {
          cascaded.add(node.id);
        }
      }
      if (cascaded.size > 0) {
        setNodes((nds) => nds.filter((n) => !cascaded.has(n.id)));
        setEdges((eds) =>
          eds.filter((e) => !cascaded.has(e.source) && !cascaded.has(e.target))
        );
        for (const id of cascaded) {
          const model = getNodeModel(id);
          if (model) (model as any).delete();
        }
      }
    },
    [getNodeModels, getNodeModel, setNodes, setEdges]
  );

  const cancelDelete = useCallback(() => {
    const deleteNodeId = deleteStore.getItem("id") as string | undefined;
    if (!deleteNodeId) return;
    clearDeleteStore(deleteStore);
  }, [deleteStore]);

  const confirmDelete = useCallback(() => {
    const deleteNodeId = deleteStore.getItem("id") as string | undefined;
    if (!deleteNodeId) return;

    const edges = getEdges();

    // Find submaps that will be orphaned by this deletion
    const submaps = getSubmaps() as Submap[];
    const orphanedSubmapIds = new Set<string>();
    for (const submap of submaps) {
      if (
        submap.startNodeId === deleteNodeId ||
        submap.endNodeId === deleteNodeId ||
        deleteNodeId.startsWith(`submap-${submap.id}-`)
      ) {
        orphanedSubmapIds.add(submap.id!);
      }
    }

    const terminalId = `terminal-${deleteNodeId}`;

    // Remove node, its terminal node, and any associated submap canvas elements from canvas
    setNodes((nds) =>
      nds.filter((n) => {
        if (n.id === deleteNodeId || n.id === terminalId) return false;
        if (
          orphanedSubmapIds.size > 0 &&
          (n.type === "SubmapNode" || n.type === "SubmapStartNode" ||
           n.type === "SubmapEndNode" || n.type === "SubmapGroupNode") &&
          orphanedSubmapIds.has((n.data as any)?.submapId)
        ) {
          return false;
        }
        return true;
      })
    );
    setEdges(edges.filter((e) => e.source !== deleteNodeId && e.target !== deleteNodeId));

    // Delete orphaned submaps from cache/DB
    cleanupOrphanedSubmaps(new Set([deleteNodeId]));

    // Clean up extraParentNodeIds referencing the deleted node
    cleanupExtraParentNodeIds(new Set([deleteNodeId]));

    // Cascade-delete any reference nodes pointing to the deleted node
    cleanupReferenceNodes(new Set([deleteNodeId]));

    // Remove from database
    const nodeModel = getNodeModel(deleteNodeId);
    if (nodeModel) {
      (nodeModel as any).delete();
    }

    clearDeleteStore(deleteStore);
  }, [deleteStore, getEdges, setNodes, setEdges, getNodeModel, cleanupOrphanedSubmaps, cleanupExtraParentNodeIds, cleanupReferenceNodes, getSubmaps]);

  const deleteAll = useCallback(() => {
    const descendantIds = (deleteStore.getItem("descendantIds") as string[]) || [];
    if (descendantIds.length === 0) return;

    const allIds = new Set(descendantIds);
    const edges = getEdges();

    // Find submaps that will be orphaned by this deletion
    const submaps = getSubmaps() as Submap[];
    const orphanedSubmapIds = new Set<string>();
    for (const submap of submaps) {
      const isOrphaned =
        allIds.has(submap.startNodeId) ||
        allIds.has(submap.endNodeId) ||
        [...allIds].some((id) => id.startsWith(`submap-${submap.id}-`));
      if (isOrphaned) {
        orphanedSubmapIds.add(submap.id!);
      }
    }

    // Remove all marked nodes, orphaned submap canvas elements, and their edges
    setNodes((nds) =>
      nds.filter((n) => {
        if (allIds.has(n.id)) return false;
        // Also remove SubmapNode/markers/groups for orphaned submaps
        if (
          orphanedSubmapIds.size > 0 &&
          (n.type === "SubmapNode" || n.type === "SubmapStartNode" ||
           n.type === "SubmapEndNode" || n.type === "SubmapGroupNode") &&
          orphanedSubmapIds.has((n.data as any)?.submapId)
        ) {
          return false;
        }
        return true;
      })
    );
    setEdges(edges.filter((e) => !allIds.has(e.source) && !allIds.has(e.target)));

    // Delete hidden member nodes of orphaned submaps from DB
    // (collapsed submaps hide their member nodes from the canvas)
    if (orphanedSubmapIds.size > 0) {
      const allNodeModels = getNodeModels() as any[];
      for (const model of allNodeModels) {
        if (model.submapId && orphanedSubmapIds.has(model.submapId) && !allIds.has(model.id)) {
          allIds.add(model.id);
          if ((model as any).delete) {
            (model as any).delete();
          }
        }
      }
    }

    // Delete orphaned submaps from cache/DB
    cleanupOrphanedSubmaps(allIds);

    // Clean up extraParentNodeIds referencing any of the deleted nodes
    cleanupExtraParentNodeIds(allIds);

    // Cascade-delete any reference nodes pointing to the deleted nodes
    cleanupReferenceNodes(allIds);

    // Remove each visible node from database
    descendantIds.forEach((nodeId) => {
      const nodeModel = getNodeModel(nodeId);
      if (nodeModel) {
        (nodeModel as any).delete();
      }
    });

    clearDeleteStore(deleteStore);
  }, [deleteStore, getEdges, setNodes, setEdges, getNodeModel, getNodeModels, getSubmaps, cleanupOrphanedSubmaps, cleanupExtraParentNodeIds, cleanupReferenceNodes]);

  const enterReattachMode = useCallback(() => {
    deleteStore.setItem("mode", "reattach");
  }, [deleteStore]);

  const reattachChildren = useCallback(
    (targetNodeId: string) => {
      const deleteNodeId = deleteStore.getItem("id") as string | undefined;
      const childrenIds = (deleteStore.getItem("childrenIds") as string[]) || [];
      if (!deleteNodeId) return;

      // Validate: target cannot be in the deletion subtree
      const descendantIds = new Set(
        (deleteStore.getItem("descendantIds") as string[]) || []
      );
      if (descendantIds.has(targetNodeId)) {
        console.warn("Cannot reattach children to a node within the deletion subtree");
        return;
      }

      const edges = getEdges();

      // Resolve the real DB node ID for the reattach target.
      // If the target is a collapsed SubmapNode, children are logically after
      // the submap's endNode — use endNodeId for DB persistence.
      let dbTargetId = targetNodeId;
      const targetCanvasNode = getNode(targetNodeId);
      if (targetCanvasNode?.type === "SubmapNode") {
        const targetSubmapId = (targetCanvasNode.data as any)?.submapId as string | undefined;
        if (targetSubmapId) {
          const submaps = getSubmaps() as Submap[];
          const targetSubmap = submaps.find((s) => s.id === targetSubmapId);
          if (targetSubmap) {
            dbTargetId = targetSubmap.endNodeId;
          }
        }
      } else if (targetCanvasNode?.type === "SubmapEndNode") {
        const instanceId = extractSubmapInstanceId(targetNodeId);
        if (instanceId) {
          const submaps = getSubmaps() as Submap[];
          const targetSubmap = submaps.find(
            (s) => s.id && getSubmapEndMarkerId(s.id, instanceId) === targetNodeId
          );
          if (targetSubmap) {
            dbTargetId = targetSubmap.endNodeId;
          }
        }
      } else if (targetCanvasNode?.type === "SubmapStartNode") {
        const instanceId = extractSubmapInstanceId(targetNodeId);
        if (instanceId) {
          const submaps = getSubmaps() as Submap[];
          const targetSubmap = submaps.find(
            (s) => s.id && getSubmapStartMarkerId(s.id, instanceId) === targetNodeId
          );
          if (targetSubmap) {
            dbTargetId = targetSubmap.startNodeId;
          }
        }
      }

      // Remove all edges connected to the delete-root node
      let newEdges = edges.filter(
        (e) => e.target !== deleteNodeId && e.source !== deleteNodeId
      );

      // Create new edges: targetNode → each direct child
      childrenIds.forEach((childId) => {
        const childNode = getNode(childId);
        const newEdge: Edge = {
          id: `${targetNodeId}=>${childId}`,
          source: targetNodeId,
          target: childId,
          markerEnd: "EventNode",
          data: {
            properties: {
              isError: childNode?.type === "ErrorNode",
            },
          },
        };
        newEdges.push(newEdge);

        // Update child's parentId and submapId in node model
        const childModel = getNodeModel(childId);
        if (childModel) {
          (childModel as any).parentId = dbTargetId;
          (childModel as any).submapId = getNodeModel(dbTargetId)?.submapId ?? null;
        } else {
          // Child might be a collapsed SubmapNode or expanded submap marker
          // — update the submap's startNode parentId and extraParentNodeIds.
          const instanceId = extractSubmapInstanceId(childId);
          if (instanceId) {
            const submaps = getSubmaps() as Submap[];
            // Check collapsed SubmapNode
            let submap = submaps.find(
              (s) => s.id && getSubmapNodeId(s.id, instanceId) === childId
            );
            // Also check via canvas node type for reference SubmapNodes
            if (!submap) {
              const childNode = getNode(childId);
              if (childNode?.type === "SubmapNode") {
                const childSubmapId = (childNode.data as any)?.submapId as string | undefined;
                if (childSubmapId) {
                  submap = submaps.find((s) => s.id === childSubmapId);
                }
              }
            }
            // Check expanded submap start marker
            if (!submap) {
              submap = submaps.find(
                (s) => s.id && getSubmapStartMarkerId(s.id, instanceId) === childId
              );
            }
            // Check expanded submap end marker
            if (!submap) {
              submap = submaps.find(
                (s) => s.id && getSubmapEndMarkerId(s.id, instanceId) === childId
              );
            }
            if (submap) {
              const startModel = getNodeModel(submap.startNodeId);
              if (startModel) {
                (startModel as any).parentId = dbTargetId;
              }
              // Update extraParentNodeIds: replace deleted node with target
              // Entries may be "nodeId" or "nodeId|viaSubmapId"
              const extra = submap.extraParentNodeIds;
              if (extra && deleteNodeId) {
                const hasDeleted = extra.some((entry: string) => {
                  const nodeId = entry.indexOf("|") >= 0 ? entry.substring(0, entry.indexOf("|")) : entry;
                  return nodeId === deleteNodeId;
                });
                if (hasDeleted) {
                  (submap as any).extraParentNodeIds = extra
                    .map((entry: string) => {
                      const pipeIdx = entry.indexOf("|");
                      const nodeId = pipeIdx >= 0 ? entry.substring(0, pipeIdx) : entry;
                      if (nodeId === deleteNodeId) {
                        return pipeIdx >= 0 ? `${dbTargetId}${entry.substring(pipeIdx)}` : dbTargetId;
                      }
                      return entry;
                    });
                }
              }
            }
          }
        }
      });

      // Remove delete-root and its terminal node from canvas
      const terminalId = `terminal-${deleteNodeId}`;
      setNodes((nds) => nds.filter((n) => n.id !== deleteNodeId && n.id !== terminalId));
      setEdges(newEdges);

      // Delete from database
      const nodeModel = getNodeModel(deleteNodeId);
      if (nodeModel) {
        (nodeModel as any).delete();
      }

      clearDeleteStore(deleteStore);
    },
    [deleteStore, getEdges, setNodes, setEdges, getNode, getNodeModel, getSubmaps]
  );

  const hasDeleteNode = !!deleteStore.getItem("id");
  const deleteMode = deleteStore.getItem("mode") as string | undefined;
  const isReattachMode = deleteMode === "reattach";
  const childrenIds = (deleteStore.getItem("childrenIds") as string[]) || [];
  const hasChildren = childrenIds.length > 0;

  return {
    cancelDelete,
    confirmDelete,
    deleteAll,
    enterReattachMode,
    reattachChildren,
    hasDeleteNode,
    isReattachMode,
    hasChildren,
  };
}
