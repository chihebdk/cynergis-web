"use client";

import { useCallback } from "react";
import { useReactFlow } from "@xyflow/react";
import { useCanvasEphemeralStore as useEphemeralStore } from "../CanvasProvider";
import { useSubmapCache } from "../CanvasProvider";
import { useNodeCache } from "../CanvasProvider";
import { useEventMapCache } from "../CanvasProvider";
import { getChainBetween, getSubmapEndEligibility } from "../utils";
import { layoutConfig } from "../config/settings";
import {
  buildSubmapNode,
  buildCollapsedEdges,
  pickSubmapColorIndex,
} from "../utils/submapUtils";
import { createId } from "@paralleldrive/cuid2";
import { NodeModel as EventNode, SubmapModel as Submap } from "../CanvasProvider";

export function useSubmapHandler() {
  const { getNodes, getEdges, setNodes, setEdges } = useReactFlow();
  const submapStore = useEphemeralStore("submapMode");
  const { addItem: addSubmap, getItems: getSubmaps } = useSubmapCache();
  const { getItem: getNodeModel, getItems: getNodeItems } = useNodeCache();
  const { selected: selectedEventMap } = useEventMapCache();

  const isSubmapMode = !!submapStore.getItem("startNodeId");
  const startNodeId = submapStore.getItem("startNodeId") as string | undefined;
  const showNameDialog = !!submapStore.getItem("showNameDialog");
  const errorMessage = submapStore.getItem("errorMessage") as string | undefined;

  const startSubmap = useCallback(
    (id: string) => {
      submapStore.setItem("startNodeId", id);
      submapStore.setItem("endNodeId", undefined);
      submapStore.setItem("showNameDialog", false);
    },
    [submapStore]
  );

  const endSubmap = useCallback(
    (id: string) => {
      const startId = submapStore.getItem("startNodeId") as string | undefined;
      if (!startId) return;

      const nodes = getNodes();
      const edges = getEdges();
      const allModels = getNodeItems() as EventNode[];

      // Full eligibility check (including references) as safety guard.
      // The context menu already disables ineligible nodes, but this protects
      // against programmatic calls.
      const result = getSubmapEndEligibility(id, startId, nodes, edges, allModels);
      if (!result.eligible) {
        console.warn("Node is not eligible as submap end:", result.reason);
        return;
      }

      submapStore.setItem("endNodeId", id);
      submapStore.setItem("showNameDialog", true);
    },
    [submapStore, getNodes, getEdges, getNodeItems]
  );

  const confirmSubmap = useCallback(
    (name: string, description?: string) => {
      const startId = submapStore.getItem("startNodeId") as string;
      const endId = submapStore.getItem("endNodeId") as string;
      if (!startId || !endId) return;

      const nodes = getNodes();
      const edges = getEdges();

      const chain = getChainBetween(startId, endId, nodes, edges);
      if (chain.length === 0) {
        console.error("Cannot create submap: chain is empty");
        return;
      }

      // Create submap entity (starts collapsed)
      const submapId = createId();
      const instanceId = createId();
      const usedColorIndices = (getSubmaps() as Submap[]).map((s) => s.colorIndex).filter((c): c is number => c !== undefined);
      const colorIndex = pickSubmapColorIndex(usedColorIndices);
      const currentMapId = selectedEventMap?.id;
      const submapData: Submap = {
        id: submapId,
        name,
        summary: name,
        description: description || "",
        startNodeId: startId,
        endNodeId: endId,
        collapsed: true,
        colorIndex,
        mapIds: currentMapId ? [currentMapId] : [],
      };
      addSubmap(submapData as any);

      // Assign submapId to all chain nodes via proxy
      chain.forEach((node) => {
        const nodeModel = getNodeModel(node.id) as EventNode | undefined;
        if (nodeModel) {
          (nodeModel as any).submapId = submapId;
        }
      });

      const chainIds = new Set(chain.map((n) => n.id));
      const startNodePos = nodes.find((n) => n.id === startId)?.position ?? layoutConfig.startNodePosition;

      const incomingToStart = edges.find((e) => e.target === startId);
      const outgoingFromEnd = edges.filter((e) => e.source === endId);

      const newEdges = buildCollapsedEdges(submapId, instanceId, incomingToStart, outgoingFromEnd);

      // Collect all edges to remove: incoming/outgoing of chain endpoints + internal
      const internalEdgeIds = new Set(
        edges
          .filter((e) => chainIds.has(e.source) && chainIds.has(e.target))
          .map((e) => e.id)
      );
      const edgesToRemove = new Set([
        ...(incomingToStart ? [incomingToStart.id] : []),
        ...outgoingFromEnd.map((e) => e.id),
        ...internalEdgeIds,
      ]);

      setNodes((nds) => [
        buildSubmapNode(submapId, instanceId, name, startNodePos),
        ...nds.filter((n) => !chainIds.has(n.id)),
      ]);
      setEdges((eds) => [
        ...eds.filter((e) => !edgesToRemove.has(e.id)),
        ...newEdges,
      ]);

      // Clear ephemeral store
      submapStore.setItem("startNodeId", undefined);
      submapStore.setItem("endNodeId", undefined);
      submapStore.setItem("showNameDialog", false);
    },
    [submapStore, getNodes, getEdges, addSubmap, getNodeModel, setNodes, setEdges]
  );

  const cancelSubmap = useCallback(() => {
    submapStore.setItem("startNodeId", undefined);
    submapStore.setItem("endNodeId", undefined);
    submapStore.setItem("showNameDialog", false);
  }, [submapStore]);

  const clearError = useCallback(() => {
    submapStore.setItem("errorMessage", undefined);
  }, [submapStore]);

  return {
    isSubmapMode,
    startNodeId,
    showNameDialog,
    errorMessage,
    startSubmap,
    endSubmap,
    confirmSubmap,
    cancelSubmap,
    clearError,
  };
}
