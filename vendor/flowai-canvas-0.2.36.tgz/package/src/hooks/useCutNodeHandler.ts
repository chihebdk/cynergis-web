"use client";

import { useCallback } from "react";
import { NodeProps, useReactFlow } from "@xyflow/react";
import { useCanvasEphemeralStore as useEphemeralStore } from "../CanvasProvider";
import { getDescendants } from "../utils";

export function useCutNodeHandler(
  id: NodeProps["id"],
  setOpen: (open: boolean) => void
) {
  const { getNodes, getEdges, setNodes } = useReactFlow();
  const cutStore = useEphemeralStore("cutNode");

  const onClick = useCallback(() => {
    setOpen(false);

    const nodes = getNodes();
    const edges = getEdges();

    // Clear any previous cut state
    const previousCutId = cutStore.getItem("id") as string | undefined;
    if (previousCutId) {
      const prevDescendants = getDescendants(previousCutId, nodes, edges);
      const prevCutIds = new Set([previousCutId, ...prevDescendants.map((n) => n.id)]);
      setNodes((nds) =>
        nds.map((n) =>
          prevCutIds.has(n.id)
            ? { ...n, data: { ...(n.data as object), properties: { ...((n.data as any).properties as object), isCut: false } } }
            : n
        )
      );
    }

    // Collect the cut node + all descendants
    const descendants = getDescendants(id, nodes, edges);
    const cutNodeIds = new Set([id, ...descendants.map((n) => n.id)]);

    // Mark cut nodes with isCut flag
    setNodes((nds) =>
      nds.map((n) =>
        cutNodeIds.has(n.id)
          ? { ...n, data: { ...(n.data as object), properties: { ...((n.data as any).properties as object), isCut: true } } }
          : n
      )
    );

    // Store cut root ID and all descendant IDs
    cutStore.setItem("id", id);
    cutStore.setItem("descendantIds", Array.from(cutNodeIds));
  }, [id, getNodes, getEdges, setNodes, cutStore]);

  return onClick;
}
