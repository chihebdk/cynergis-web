"use client";

import React, { useEffect } from "react";
import { PropertiesResizablePanel } from "./PropertiesResizablePanel";
import { Card, CardContent, CardHeader } from "../components/shadcn/card";
import { PropertiesNav } from "./PropertiesNav";
import { useTabStore } from "./useTabStore";
import { useNodeCache } from "../CanvasProvider";
import { PropertiesTabConfig } from "./types";

type PropertiesPanelProps = {
  tabs: Record<string, PropertiesTabConfig>;
  tabComponents: Record<string, React.ComponentType>;
  defaultTab?: string;
};

export const PropertiesPanel: React.FC<PropertiesPanelProps> = ({
  tabs,
  tabComponents,
  defaultTab,
}) => {
  const { selected } = useNodeCache();
  const { tab, setTab } = useTabStore();

  // Set default tab on mount or when tabs change
  const firstTabKey = defaultTab || Object.keys(tabs)[0] || "";
  useEffect(() => {
    if (!tab || !tabs[tab]) {
      setTab(firstTabKey);
    }
  }, [firstTabKey, tab, tabs, setTab]);

  if (!selected) return null;

  const ActiveTabComponent = tab ? tabComponents[tab] : undefined;

  return (
    <PropertiesResizablePanel>
      <Card className="h-full w-full border-0 gap-0 p-2 m-0 shadow-none overflow-auto">
        <CardHeader className="p-2">
          <PropertiesNav tabs={tabs} />
        </CardHeader>
        <CardContent className="flex flex-col m-0 gap-0 p-0 h-full w-full">
          <div className="p-4 my-2 ml-4 mr-4 border rounded-lg bg-primary-foreground h-full overflow-auto">
            {ActiveTabComponent && (
              <div data-testid={`properties-tab-content-${tab}`}>
                <ActiveTabComponent />
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </PropertiesResizablePanel>
  );
};
