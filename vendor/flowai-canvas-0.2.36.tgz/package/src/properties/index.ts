export { PropertiesPanel } from "./PropertiesPanel";
export { PropertiesNav } from "./PropertiesNav";
export { PropertiesResizablePanel } from "./PropertiesResizablePanel";
export { useTabStore } from "./useTabStore";
export type { PropertiesTabConfig } from "./types";
