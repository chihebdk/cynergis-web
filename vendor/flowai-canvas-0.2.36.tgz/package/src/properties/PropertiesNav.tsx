"use client";

import React from "react";
import { Icon } from "@iconify/react";
import { PropertiesTabConfig } from "./types";
import { useTabStore } from "./useTabStore";
import { Button } from "../components/shadcn/button";
import { cn } from "../lib/utils";

type PropertiesNavProps = {
  tabs: Record<string, PropertiesTabConfig>;
};

export const PropertiesNav: React.FC<PropertiesNavProps> = ({ tabs }) => {
  const { tab, setTab } = useTabStore();

  return (
    <nav className="flex flex-1 items-center gap-1" data-testid="properties-nav">
      {Object.values(tabs).map((item) => (
        <div className="grid rounded-none" key={item.tab}>
          <Button
            variant="ghost"
            className={cn(
              "hover:cursor-pointer p-1 px-2 text-xs h-8",
              item.tab === tab ? item.selectedCls : item.className
            )}
            onClick={() => setTab(item.tab)}
            data-testid={`properties-tab-${item.tab}`}
          >
            {item.icon && (
              <Icon icon={item.icon} width={item.iconSize || 18} />
            )}
            <span className="text-xs">{item.title}</span>
          </Button>
        </div>
      ))}
    </nav>
  );
};
