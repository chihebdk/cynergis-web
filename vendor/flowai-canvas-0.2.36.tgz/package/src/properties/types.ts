export type PropertiesTabConfig = {
  title: string;
  icon?: string;
  iconSize?: number;
  tab: string;
  className?: string;
  selectedCls?: string;
};
