"use client";

import React from "react";
import { useNodeCache } from "../../CanvasProvider";

export const DetailsTab: React.FC = () => {
  const { selected } = useNodeCache();
  if (!selected) return null;

  return (
    <div className="flex flex-col gap-4">
      <div>
        <label className="text-sm font-medium text-muted-foreground">Node ID</label>
        <p className="text-sm">{selected.id}</p>
      </div>
      <div>
        <label className="text-sm font-medium text-muted-foreground">Summary</label>
        <p className="text-sm">{(selected as any).summary || "—"}</p>
      </div>
      <div>
        <label className="text-sm font-medium text-muted-foreground">Type</label>
        <p className="text-sm">{(selected as any).type || "SimpleNode"}</p>
      </div>
    </div>
  );
};
