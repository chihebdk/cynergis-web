import type { PropertiesTabConfig } from "../types";
import { DetailsTab } from "./DetailsTab";
import { NotesTab } from "./NotesTab";

export { DetailsTab } from "./DetailsTab";
export { NotesTab } from "./NotesTab";

export const builtinPropertyTabs: Record<string, PropertiesTabConfig> = {
  DetailsTab: {
    title: "Details",
    icon: "mdi:information-outline",
    tab: "DetailsTab",
    className: "text-slate-500",
    selectedCls: "text-blue-600 bg-blue-50",
  },
  NotesTab: {
    title: "Notes",
    icon: "mdi:note-text-outline",
    tab: "NotesTab",
    className: "text-slate-500",
    selectedCls: "text-amber-600 bg-amber-50",
  },
};

export const builtinTabComponents: Record<string, React.ComponentType> = {
  DetailsTab,
  NotesTab,
};
