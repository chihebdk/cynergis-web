"use client";

import React from "react";

export const NotesTab: React.FC = () => {
  return (
    <div className="flex flex-col gap-2">
      <p className="text-sm text-muted-foreground">Notes for this node will appear here.</p>
    </div>
  );
};
