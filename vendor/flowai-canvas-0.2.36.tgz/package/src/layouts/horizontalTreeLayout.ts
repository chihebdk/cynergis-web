export function horizontalTreeLayout(
  root: any,
  edges: any,
  width: any,
  height: any,
  viewport: any,
  _changed: any
) {
  const newNodes = root.descendants().map((d: any) => {
    d.data.hidden = false;
    d.data.data.properties = {
      hasFocus: undefined,
    };
    return {
      ...d.data,
      position: { x: d.y, y: d.x },
    };
  });
  const newEdges = edges.map((edge: any) => {
    const sourceNode = newNodes.find((node: any) => node.id === edge.source);
    const targetNode = newNodes.find((node: any) => node.id === edge.target);
    if (sourceNode && targetNode) {
      edge.type = "WorkflowEdge";
      edge.data.properties.hasFocus = true;
      edge.zIndex = edge.data.properties.isError ? 1 : 2;
    }
    return edge;
  });

  const { x, y } = viewport;
  const selectedNode = newNodes.find((node: any) => node.selected);

  const heightCenter = Math.floor(height / 2);

  const newViewport = {
    x: x,
    y: heightCenter - (selectedNode?.position.y || 0) - 200,
    zoom: 1.0,
    duration: 300,
  };

  return { newNodes, newEdges, newViewport };
}
