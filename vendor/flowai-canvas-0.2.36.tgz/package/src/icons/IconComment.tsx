import React from "react";
import type { SVGProps } from "react";

export default function IconComment(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={25}
      height={25}
      viewBox="0 0 24 24"
      {...props}
    >
      <g>
        <path
          fill="#dc2626"
          d="M20 2H4c-1.103 0-2 .897-2 2v18l4-4h14c1.103 0 2-.897 2-2V4c0-1.103-.897-2-2-2"
        ></path>

        <line x1="6" y1="7" x2="18" y2="7" stroke="white" strokeWidth="1" />
        <line x1="6" y1="10" x2="18" y2="10" stroke="white" strokeWidth="1" />
        <line x1="6" y1="13" x2="15" y2="13" stroke="white" strokeWidth="1" />
      </g>
    </svg>
  );
}
