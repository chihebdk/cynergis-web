import React from "react";
import type { SVGProps } from "react";

export default function ArcticonsWorkflowy(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      viewBox="0 0 48 48"
      {...props}
    >
      <circle
        cx={10.693}
        cy={11.106}
        r={5.194}
        fill="none"
        stroke="black"
        
        strokeLinecap="round"
        strokeLinejoin="round"
      ></circle>
      <path
        fill="none"
        stroke="black"
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M15.241 8.507h24.37c3.032 0 3.386 5.745.334 5.745H14.972"
      ></path>
      <circle
        cx={11.127}
        cy={36.894}
        r={5.194}
        fill="none"
        stroke="black"
        strokeLinecap="round"
        strokeLinejoin="round"
      ></circle>
      <path
        fill="none"
        stroke="black"
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M15.675 34.294h24.37c3.031 0 3.385 5.745.333 5.745H15.405"
      ></path>
      <circle
        cx={20.355}
        cy={24.306}
        r={4.985}
        fill="none"
        stroke="black"
        strokeLinecap="round"
        strokeLinejoin="round"
      ></circle>
      <path
        fill="none"
        stroke="black"
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M24.61 21.28h15.562c3.025 0 3.037 6.092 0 6.092h-15.56"
      ></path>
    </svg>
  );
}
