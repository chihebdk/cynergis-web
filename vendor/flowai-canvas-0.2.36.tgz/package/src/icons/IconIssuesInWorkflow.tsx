import React from "react";
import type { SVGProps } from "react";

export default function IssuesInWWorkflow(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={17}
      height={17}
      viewBox="0 0 72 72"
      {...props}
    >
      <path
        fill="#f87171"
        d="M59.035 60h-46.07a.97.97 0 0 1-.965-.965v-46.07a.97.97 0 0 1 .965-.965h46.07a.97.97 0 0 1 .965.965v46.07a.97.97 0 0 1-.965.965"
      ></path>
    </svg>
  );
}
