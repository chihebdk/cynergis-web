import React from "react";
import type { SVGProps } from "react";

export default function IconReferenceTarget(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={30}
      height={30}
      viewBox="0 0 24 24"
      {...props}
    >
      <g fill="grey" transform="rotate(90, 10, 15)">
        <path
          fill="none"
          stroke="grey"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={1}
          d="M12 21V3m3 3l-3-3l-3 3m0 15h6"
        ></path>
      </g>
    </svg>
  );
}
