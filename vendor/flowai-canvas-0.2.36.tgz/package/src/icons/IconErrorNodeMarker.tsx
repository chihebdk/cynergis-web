import React from "react";
import type { SVGProps } from "react";

export default function IconErrorNode(_props: SVGProps<SVGSVGElement>) {
  return (
    <svg style={{ position: "absolute", left: 0, backgroundColor: "white" }}>
      <defs>
        <marker
          id="ErrorNode"
          viewBox="0 0 40 60"
          markerHeight={36}
          markerWidth={36}
          refX={21}
          refY={13}
        >
          <g fill="white" stroke="red" strokeWidth="0.05%">
           
              <path
                stroke="red"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
                d="M15.5 12H12m0 0H8.5m3.5 0V8.5m0 3.5v3.5m8.5.3V8.2a1.91 1.91 0 0 0-.944-1.645l-6.612-3.8a1.88 1.88 0 0 0-1.888 0l-6.612 3.8A1.895 1.895 0 0 0 3.5 8.2v7.602a1.91 1.91 0 0 0 .944 1.644l6.612 3.8a1.88 1.88 0 0 0 1.888 0l6.612-3.8A1.895 1.895 0 0 0 20.5 15.8"
              />
       
          </g>
        </marker>
      </defs>
    </svg>
  );
}
