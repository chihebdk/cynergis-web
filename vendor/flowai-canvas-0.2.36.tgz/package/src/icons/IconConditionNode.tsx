import React from "react";
import type { SVGProps } from "react";

export default function IconConditionNode(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={20}
      height={20}
      viewBox="0 0 48 48"
      {...props}
    >
      <g fill="white" stroke="#6b7280" strokeWidth={2.2}>
        <path
          strokeLinejoin="round"
          d="M22.8 4.201L4.413 22.586a2 2 0 0 0 0 2.828L22.8 43.8a2 2 0 0 0 2.829 0l18.384-18.385a2 2 0 0 0 0-2.828L25.628 4.2a2 2 0 0 0-2.829 0Z"
        ></path>
        <path
          strokeLinecap="round"
          d="M24.043 15.534v16.944m-8.472-8.472h16.944"
        ></path>
      </g>
    </svg>
  );
}
