import React from "react";
import type { SVGProps } from "react";

export default function IconEndNode(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={20}
      height={25}
      viewBox="0 0 24 24"
      {...props}
    >
      <path
        fill="#6b7280"
        strokeWidth="0"
        d="M12 17.5q-.425 0-.712-.288T11 16.5V13H3q-.425 0-.712-.288T2 12t.288-.712T3 11h8V7.5q0-.425.288-.712T12 6.5h9q.425 0 .713.288T22 7.5v9q0 .425-.288.713T21 17.5z"
      ></path>
    </svg>
  );
}
