import React from "react";
import type { SVGProps } from "react";

export default function IconReferenceNode(_props: SVGProps<SVGSVGElement>) {
  return (
    <svg style={{ position: "absolute", left: 0, backgroundColor: "white" }}>
      <defs>
        <marker
          id="ReferenceNode"
          viewBox="0 0 32 32"
          markerHeight={30}
          markerWidth={30}
          refX={32}
          refY={16}
        >
          <g fill="#6b7280" stroke="#6b7280" strokeWidth={0.05}>
          <circle cx="18" cy="12" r="18" fill="white" stroke="white"/>
          
            <path d="M4 20v2h4.586L2 28.586L3.414 30L10 23.414V28h2v-8zm24-8h-6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2m-6-8v6h6V4z"></path>
            <path d="M24 26h-8v-2h8v-7H8a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h10v2H8v7h16a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2"></path>
          </g>
        </marker>
      </defs>
    </svg>
  );
}
