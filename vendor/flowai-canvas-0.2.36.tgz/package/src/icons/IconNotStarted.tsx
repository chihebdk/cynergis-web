import React from "react";
import type { SVGProps } from "react";

export default function IconNotStarted(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={18}
      height={18}
      viewBox="0 0 24 24"
      {...props}
    >
      <circle cx={12} cy={12} r={9} fill="#9ca3af"></circle>
    </svg>
  );
}
