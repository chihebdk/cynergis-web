import React from "react";
import type { SVGProps } from "react";

export default function IconConditionNode(_props: SVGProps<SVGSVGElement>) {
  return (
    <svg style={{ position: "absolute", left: 0 }}>
      <defs>
        <marker
          id="ConditionNode"
          viewBox="0 0 40 60"
          markerHeight={18}
          markerWidth={18}
          refX={45}
          refY={24}
        >
          <g fill="white" stroke="#6b7280" strokeWidth={2.5}>
            <path
              strokeLinejoin="round"
              d="M22.8 4.201L4.413 22.586a2 2 0 0 0 0 2.828L22.8 43.8a2 2 0 0 0 2.829 0l18.384-18.385a2 2 0 0 0 0-2.828L25.628 4.2a2 2 0 0 0-2.829 0Z"
            ></path>
            <path
              strokeLinecap="round"
              d="m18.043 29.987l12-11.962m-11.99-.009l11.98 11.98"
            ></path>
          </g>
        </marker>
      </defs>
    </svg>
  );
}
