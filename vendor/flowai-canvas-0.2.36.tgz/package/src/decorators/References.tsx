import React from "react";
import { cn } from "../lib/utils";
import { useDecoratorsStore } from "../stores/useDecoratorsStore";

export const References = () => {
  const decoratorStore = useDecoratorsStore();

  const references = decoratorStore.decorators["References"];

  return (
    references.visible && (
      <div
        onContextMenu={(e) => {
          e.preventDefault();
          e.stopPropagation();
          return false;
        }}
        className={cn(
          "grid  place-content-center absolute top-[10px] left-[-25px] z-10 overflow-visible"
          //refNodes?.length ? "visible" : "hidden"
        )}
      >
        <div className="flex flex-col gap-0 justify-items-center text-gray">
          <div className="z-20 rounded-none bg-transparent border-b-1 border-gray-400  min-w-6 w-6 h-5  text-xs">
            {2}
          </div>
        </div>
      </div>
    )
  );
};
