import React from "react";
import { cn } from "../lib/utils";
import { Comment } from "../components/icons";
import { useDecoratorsStore } from "../stores/useDecoratorsStore";

export const Comments = () => {
  const decoratorStore = useDecoratorsStore();

  const comments = decoratorStore.decorators["Comments"];

  return (
    comments.visible && (
      <div
        onContextMenu={(e) => {
          e.preventDefault();
          e.stopPropagation();
          return false;
        }}
        className={cn("hover:cursor-pointer hover:z-50",
          "absolute z-50 overflow-visible  bottom-[-12px] right-[-12px]"
        )}
      >
        <Comment color="#f10165" width={25} height={25} />
      </div>
    )
  );
};
