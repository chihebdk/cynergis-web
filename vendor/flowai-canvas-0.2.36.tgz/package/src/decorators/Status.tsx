import React from "react";
import { cn } from "../lib/utils";
import { useDecoratorsStore } from "../stores/useDecoratorsStore";
import {
  TooltipProvider,
  Tooltip,
  TooltipTrigger,
  TooltipContent,
  TooltipArrow,
} from "@radix-ui/react-tooltip";
import { Card, CardContent, CardHeader } from "../components/shadcn/card";
import { Dot, Square, Arrow } from "../components/icons";

export const Status: React.FC = () => {
  const decoratorStore = useDecoratorsStore();

  const status = decoratorStore.decorators["Status"];

  return (
    status.visible && (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div
              onContextMenu={(e) => {
                e.preventDefault();
                e.stopPropagation();
                return false;
              }}
              className={cn(
                "hover:cursor-pointer hover:z-50",
                "flex flex-row  absolute top-[-28px] left-1 z-10 overflow-visible gap-1"
              )}
            >
              <div className="z-20 flex items-center justify-center">
                <Dot width={30} color="#5ba301" />
              </div>

              <div className="z-20 flex items-center justify-center -ml-1">
                <Arrow width={27} color="#ffbf65" />
              </div>

              <div className="z-20 flex items-center justify-center">
                <Square width={18} color="#f10165" />
              </div>
            </div>
          </TooltipTrigger>
          <TooltipContent className="text-xs" side="top" sideOffset={10}>
            <Card className="gap-2 p-2">
              <CardHeader className="flex items-center text-xs font-semibold justify-center">
                Status
              </CardHeader>
              <CardContent className="p-1">
                <div className="grid grid-cols-3 gap-2">
                  <div className="flex items-center justify-center">Node</div>
                  <div className="flex items-center justify-center">Path</div>
                  <div className="flex items-center justify-center">Flow</div>

                  <div className="z-20 flex items-center justify-center">
                    <Dot width={30} color="#d4d3d2" />
                  </div>

                  <div className="z-20 flex items-center justify-center">
                    <Arrow width={27} color="#d4d3d2" />
                  </div>

                  <div className="z-20 flex items-center justify-center">
                    <Square width={18} color="#d4d3d2" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <TooltipArrow className="fill-[#d4d3d2]" />
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  );
};
