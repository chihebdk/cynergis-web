export const layoutConfig = {
  startNodePosition: {
    x: 20,
    y: 65,
  },
  initialViewport: {
    x: 0,
    y: 0,
    zoom: 0.8,
  },
};

export const baseNodeSize = {
  width: 165,
  height: 140,
};

// Height the properties panel opens at, and the smallest it can be dragged to.
// (They used to be the same value, so the panel could only ever grow.) The board
// view — header + a row of section columns — needs room, so it opens fairly tall.
export const initialConfigPanelHeight = 440;
export const minConfigPanelHeight = 120;

export const defaultNodeToolbar = [
  "addNode",
  "addCondition",
  "addError",
  "addReference",
  "addSubflow"
];

export const defaultNodeContextMenuItems = [
  "copyNode",
  "cutNode",
  "deleteNode",
  "pasteNode",
  "submapStart",
  "submapEnd",
  "markEndNode",
];
export const defaultNodeDecorators = ["Comments", "Status", "References"];

// ─── Canvas Config Defaults ──────────────────────────────────

import type { CanvasConfig, NodeConfig, EdgeConfig } from "./CanvasConfig";

export const defaultNodeConfig: NodeConfig = {
  toolbar: defaultNodeToolbar,
  contextMenu: defaultNodeContextMenuItems,
  decorators: defaultNodeDecorators,
  showEndMarker: true,
};

export const defaultEdgeConfig: EdgeConfig = {
  stroke: "#6b7280",
  strokeWidth: 1,
  opacity: 0.5,
  markerEnd: false,
  focusedStyle: "solid",
  unfocusedStyle: "dashed",
  toolbar: ["addNode", "addCondition", "addError", "addReference", "addSubflow"],
};

export const defaultCanvasConfig: CanvasConfig = {
  node: defaultNodeConfig,
  edge: defaultEdgeConfig,
};
