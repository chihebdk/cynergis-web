"use client";

import "@xyflow/react/dist/style.css";

import React, { useCallback, useEffect, useMemo, useRef } from "react";
import {
  ReactFlow,
  Background,
  ProOptions,
  Node,
  Edge,
  useReactFlow,
  getNodesBounds,
  getViewportForBounds,
} from "@xyflow/react";
import { BaseNodeData } from "../types/NodeTypes";
import { NodeTypes } from "@xyflow/react";
import { EdgeTypes } from "@xyflow/react";
import { useNodeDragActionsHandler } from "../hooks/useNodeDragActionsHandler";
import useLayout from "../hooks/useLayout";
import { useNodeCache, useDomainCache, useCanvasEphemeralStore as useEphemeralStore, useCanvasSidebar as useSidebar, useCanvasConfig } from "../CanvasProvider";
import { useLayoutStore } from "../stores/useLayoutStore";
import { getDescendants } from "../utils";
import { useDeleteNodeActions } from "../hooks/useDeleteNodeActions";
import { useSubmapHandler } from "../hooks/useSubmapHandler";
import { SubmapNameDialog } from "./SubmapNameDialog";
import { SubmapErrorDialog } from "./SubmapErrorDialog";
import { resolveNodeTypes, resolveEdgeTypes } from "./builtinTypes";
import { VerticalLanes } from "./VerticalLanes";
const proOptions: ProOptions = { account: "paid-pro", hideAttribution: true };

type CanvasProps = {
  nodeTypes?: NodeTypes;
  edgeTypes?: EdgeTypes;
  nodes: Node<BaseNodeData>[];
  edges: Edge[];
  viewport?: any;
  propertiesPanel?: React.ReactNode;
  lanes?: { show?: boolean; laneWidth?: number; colors?: string[]; opacity?: number; titles?: string[]; border?: { show?: boolean; color?: string; strokeWidth?: number } };
  onLaneTitleChange?: (index: number, title: string) => void;
};

export const Canvas: React.FC<CanvasProps> = ({
  nodeTypes,
  edgeTypes,
  nodes,
  edges,
  viewport: _viewport,
  propertiesPanel,
  lanes,
  onLaneTitleChange,
}) => {
  const {
    getItem: getNodeModel,
    setSelected: setSelectedNode,
    clearSelected: clearSelectedNode,
  } = useNodeCache();
  const { setSelected: setSelectedDomain, clearSelected: clearSelectedDomain } =
    useDomainCache();

  const canvasConfig = useCanvasConfig();
  const effectiveLanes = lanes ?? canvasConfig.lanes;

  const mergedNodeTypes = useMemo(() => resolveNodeTypes(nodeTypes), [nodeTypes]);
  const mergedEdgeTypes = useMemo(() => resolveEdgeTypes(edgeTypes), [edgeTypes]);

  const paneRef = useRef<HTMLDivElement>(null);
  const { setNodes, getNodes, getEdges, setViewport } = useReactFlow();
  const { setOpen } = useSidebar();
  const layoutMode = useLayoutStore((s) => s.mode);

  // Frame the whole flow in ONE viewport animation: compute the fitted transform
  // ourselves (instead of fitView) so mode-specific adjustments — org top-aligns,
  // tree centres — land in the same setViewport call. Chaining fitView + a second
  // setViewport made the map visibly move in two directions before settling.
  const frameView = useCallback((duration = 300) => {
    const el = paneRef.current;
    if (!el) return;
    const visible = getNodes().filter((n) => !n.hidden);
    if (!visible.length) return;
    const bounds = getNodesBounds(visible);
    const vp = getViewportForBounds(bounds, el.clientWidth, el.clientHeight, 0.5, 0.9, 0.2);
    if (layoutMode === "org") {
      // Org focuses one horizontal path with branches cascading down — centring
      // wastes the top of the pane, so pin the diagram just below the top edge.
      const TOP_MARGIN = 16;
      vp.y = TOP_MARGIN - bounds.y * vp.zoom;
    }
    setViewport(vp, { duration });
  }, [getNodes, setViewport, layoutMode]);

  // Fit all nodes into view AFTER the custom layout has positioned them (fitting via
  // the prop would fit the pre-layout stacked positions). Re-runs on mode switch so
  // toggling org↔tree re-frames.
  useEffect(() => {
    if (!canvasConfig.fitView) return;
    const t = setTimeout(() => frameView(300), 450);
    return () => clearTimeout(t);
  }, [canvasConfig.fitView, layoutMode, frameView]);

  // Re-fit when the canvas container itself resizes (e.g. inline ↔ fullscreen),
  // so the map stays framed for whatever size it is rendered at. The properties
  // panel is an overlay, so its resizing does not trigger this.
  useEffect(() => {
    if (!canvasConfig.fitView) return;
    const el = paneRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    let first = true;
    let t: ReturnType<typeof setTimeout>;
    const ro = new ResizeObserver(() => {
      if (first) { first = false; return; } // initial observe is handled by the mount fit above
      clearTimeout(t);
      t = setTimeout(() => frameView(250), 160);
    });
    ro.observe(el);
    return () => { clearTimeout(t); ro.disconnect(); };
  }, [canvasConfig.fitView, frameView]);
  const { onDragStop, onDragStart } = useNodeDragActionsHandler();
  const cutStore = useEphemeralStore("cutNode");
  const refNavStore = useEphemeralStore("refNavigation");
  const { cancelDelete } = useDeleteNodeActions();
  const { cancelSubmap } = useSubmapHandler();

  const cancelCut = useCallback(() => {
    const cutNodeId = cutStore.getItem("id") as string | undefined;
    if (!cutNodeId) return;

    const nodes = getNodes();
    const edges = getEdges();
    const descendants = getDescendants(cutNodeId, nodes, edges);
    const cutIds = new Set([cutNodeId, ...descendants.map((n) => n.id)]);

    setNodes((nds) =>
      nds.map((n) =>
        cutIds.has(n.id)
          ? { ...n, data: { ...(n.data as object), properties: { ...((n.data as any).properties as object), isCut: false } } }
          : n
      )
    );

    cutStore.setItem("id", undefined);
    cutStore.setItem("descendantIds", undefined);
  }, [cutStore, getNodes, getEdges, setNodes]);

  const onNodeClick = (e: React.MouseEvent, node: Node) => {
    node.selected = true;
    closeSidebar();
    setSelectedNode(node.id);
    refNavStore.setItem("targetNodeId", undefined);
    refNavStore.setItem("refNodeId", undefined);
    if (getNodeModel(node.id)?.domainId) {
      const domainId = getNodeModel(node.id)?.domainId;
      setSelectedDomain(domainId!);
    }
  };

  const deselectAll = useCallback((e: any) => {
    if (e.target.classList.contains("react-flow__pane")) {
      setNodes((nodes) =>
        nodes.map((n) => {
          n.selected = false;
          return n;
        })
      );
      setSelectedNode(null);
      clearSelectedNode();
      setSelectedDomain(null);
      clearSelectedDomain();
      cancelCut();
      cancelDelete();
      cancelSubmap();
      refNavStore.setItem("targetNodeId", undefined);
      refNavStore.setItem("refNodeId", undefined);
    }
  }, [cancelCut, cancelDelete, cancelSubmap, refNavStore]);

  useEffect(() => {
    if (paneRef.current) {
      const pane =
        paneRef.current.getElementsByClassName("react-flow__pane")?.[0];
      pane.addEventListener("dblclick", deselectAll);
    }
  }, [paneRef, deselectAll]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        cancelCut();
        cancelDelete();
        cancelSubmap();
      }
    };
    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [cancelCut, cancelDelete, cancelSubmap]);

  const closeSidebar = () => {
    setOpen(false);
  };

  useLayout();

  return (
    <>
      <ReactFlow
        ref={paneRef}
        onPaneClick={closeSidebar}
        defaultNodes={nodes}
        defaultEdges={edges}
        nodeTypes={mergedNodeTypes}
        edgeTypes={mergedEdgeTypes}
        minZoom={0.5}
        maxZoom={0.9}
        onNodeDragStart={(e, node: Node<BaseNodeData>) => onDragStart(node)}
        onNodeDragStop={(e, node: Node<BaseNodeData>) => onDragStop(node)}
        nodeDragThreshold={3}
        zoomOnScroll={false}
        nodesDraggable={true}
        nodesConnectable={false}
        zoomOnDoubleClick={false}
        panOnScroll={false}
        deleteKeyCode={null}
        proOptions={proOptions}
        onNodeClick={onNodeClick}
        noWheelClassName="no-wheel"
      >
        {effectiveLanes?.show && <VerticalLanes laneWidth={effectiveLanes.laneWidth} colors={effectiveLanes.colors} opacity={effectiveLanes.opacity} border={effectiveLanes.border} titles={effectiveLanes.titles} onTitleChange={onLaneTitleChange} />}
        <Background />

        {propertiesPanel}
      </ReactFlow>
      <SubmapNameDialog />
      <SubmapErrorDialog />
    </>
  );
};
