import { useEffect, useRef } from "react";
import {
  useReactFlow,
  useStore,
  Node,
  Edge,
  Viewport,
  ReactFlowState,
} from "@xyflow/react";
import { stratify, tree } from "d3-hierarchy";
import { timer } from "d3-timer";
import { orgLayout } from "../layouts/orgLayout";
import { horizontalTreeLayout } from "../layouts/horizontalTreeLayout";
import { useCanvasConfig } from "../CanvasProvider";
/* import {
  Layout,
  LayoutContext,
} from "../contexts/LayoutProvider"; */
import useSize from "./useWindowSize";
import { BaseNodeData } from "../types/NodeTypes";
import { layoutConfig } from "../config/settings";
import { useLayoutStore, LayoutMode } from "../stores/useLayoutStore";
/* import {
  SubflowGroupNode,
  SubflowGroupNodeData,
  SublfowNodeData,
  CopyNode,
} from "../components/nodes"; */

const layoutTransformation = {
  org: orgLayout,
  htree: horizontalTreeLayout,
};

const layout = tree<Node>()
  .nodeSize([200, 300])
  .separation(() => 1);

const options = { duration: 200 };

function layoutNodes(
  nodes: Node<BaseNodeData & any>[],
  edges: Edge[],
  width: number,
  height: number,
  viewport: Viewport,
  // currentLayout: Layout,
  changed: boolean,
  mode: LayoutMode = "org"
): any {
  if (nodes.length === 0) {
    return { newNodes: [], newEdges: [], newViewport: viewport, transientOrphanSubmapNodes: [] };
  }

  const nodeIds = new Set(nodes.map((n) => n.id));
  const safeEdges = edges.filter((e) => nodeIds.has(e.source) && nodeIds.has(e.target));

  // Remove orphan nodes (no incoming edge and not the single root) to avoid "multiple roots"
  const targets = new Set(safeEdges.map((e) => e.target));
  const roots = nodes.filter((n) => !targets.has(n.id));
  // If there's exactly one root, keep all nodes; if multiple, keep only one root + all non-roots
  let safeNodes = nodes;
  // SubmapNodes that are orphaned during transient React state updates — keep them out of layout
  // but preserve them in the output to prevent the layout from permanently dropping them.
  let transientOrphanSubmapNodes: Node[] = [];
  if (roots.length > 1) {
    // The "start" node is the expected root; remove other orphans.
    // SubmapNodes with no incoming edge are treated as transient orphans (edges may not have arrived yet).
    const rootId = roots.find((n) => n.id === "start")?.id ?? roots[0].id;
    transientOrphanSubmapNodes = nodes.filter(
      (n) => !targets.has(n.id) && n.id !== rootId && n.type === "SubmapNode"
    );
    safeNodes = nodes.filter((n) => targets.has(n.id) || n.id === rootId);
  }

  const hierarchy = stratify<Node>()
    .id((d) => d.id)
    .parentId((d: Node) => safeEdges.find((e: Edge) => e.target === d.id)?.source)(
    safeNodes
  );

  const root = layout(hierarchy);

  const layoutFn = layoutTransformation[mode] ?? orgLayout;
  const result = layoutFn(root, safeEdges, width, height, viewport, changed);
  return { ...result, transientOrphanSubmapNodes };
}

/* function adjustSubflowPositionAnsSize(subflowNodes: Node[], nodes: Node[]) {
  subflowNodes.forEach((subflowGroupNode) => {
    const subflowNodeChildrenIds = Array.from(
      (subflowGroupNode.data as SubflowGroupNodeData).model.children
    );

    const subflowNodeChildren = subflowNodeChildrenIds.map((id) =>
      nodes.find((n) => n.id === id)
    );
    const minX = Math.min(
      ...subflowNodeChildren.map((n) => Math.floor(n?.position.x || 0))
    );
    const minY = Math.min(
      ...subflowNodeChildren.map((n) => Math.floor(n?.position.y || 0))
    );
    const maxX = Math.max(
      ...subflowNodeChildren.map((n) =>
        Math.floor((n?.position.x || 0) + (n?.width || 0))
      )
    );
    const maxY = Math.max(
      ...subflowNodeChildren.map((n) =>
        Math.floor((n?.position.y || 0) + (n?.height || 0))
      )
    );

    subflowGroupNode.position = {
      x: minX - 50,
      y: minY - 50,
    };

    subflowGroupNode.width = maxX - minX + 100;
    subflowGroupNode.height = maxY - minY + 100;
  });

  return subflowNodes;
} */

const excludedNodeTypes = new Set(["CopyNode", "SubflowGroupStartNode", "SubmapGroupNode", "TerminalNode"]);

const nodeCountSelector = (state: ReactFlowState) =>
  state.nodes.filter((n) => !excludedNodeTypes.has(n.type ?? "")).length;
const nodeOrderSelector = (state: ReactFlowState) =>
  state.nodes
    .filter((n) => !excludedNodeTypes.has(n.type ?? ""))
    .reduce((acc, n) => acc + n.id, "");
const nodeDraggedSelector = (state: ReactFlowState) =>
  state.nodes.filter((n) => n.dragging).length;
const edgeOrderSelector = (state: ReactFlowState) =>
  state.edges
    .filter((e) => e.type !== "CopyEdge")
    .reduce((acc, e) => acc + e.id, "");

function useLayout() {
  const initial = useRef(true);

  const nodeCount = useStore(nodeCountSelector);
  const nodeOrder = useStore(nodeOrderSelector);
  const nodeDragged = useStore(nodeDraggedSelector);
  const edgeOrder = useStore(edgeOrderSelector);
  const layoutMode = useLayoutStore((s) => s.mode);
  const canvasConfig = useCanvasConfig();
  // const { layout } = useContext(LayoutContext);
  const layoutRef = useRef<string>("");

  const {
    getNodes,
    getNode,
    setNodes,
    setEdges,
    getEdges,
    getViewport,
    setViewport,
  } = useReactFlow();
  const [width, height] = useSize();

  useEffect(() => {
    if (nodeDragged || nodeCount <= 1) {
      return;
    }

    const [copyNodes, subflowGroupNodes, submapGroupNodes, terminalNodes, nodes] = getNodes().reduce(
      (acc: [Node[], Node[], Node[], Node[], Node[]], node) => {
        if (node && node.type === "CopyNode") {
          acc[0].push(node);
        } else if (node.type === "SubflowGroupNode") {
          acc[1].push(node);
        } else if (node.type === "SubmapGroupNode") {
          acc[2].push(node);
        } else if (node.type === "TerminalNode") {
          acc[3].push(node);
        } else {
          acc[4].push(node);
        }
        return acc;
      },
      [[], [], [], [], []]
    );

    //split edges into 3 arrays, one for copy edges, one for subflow edges and one for normal edges

    const [copyEdges, subflowEdges, edges, terminalEdges] = getEdges().reduce(
      (acc: [Edge[], Edge[], Edge[], Edge[]], edge) => {
        if (edge.type === "CopyEdge") {
          acc[0].push(edge);
        } else if (edge.type === "SubflowEdge") {
          acc[1].push(edge);
        } else if (edge.type === "TerminalEdge") {
          acc[3].push(edge);
        } else {
          acc[2].push(edge);
        }
        return acc;
      },
      [[], [], [], []]
    );

    const viewport =
      getViewport().x === 0 && getViewport().y === 0
        ? layoutConfig.initialViewport
        : getViewport();

    /*  const changed = layoutRef.current !== layout;
    if (changed) {
      layoutRef.current = layout;
    } */

    let layoutResult: ReturnType<typeof layoutNodes>;
    try {
      layoutResult = layoutNodes(nodes, edges, width, height, viewport, false, layoutMode);
    } catch (err) {
      console.warn("Layout error (non-fatal):", err);
      return;
    }
    const { newNodes, newEdges, newViewport, transientOrphanSubmapNodes } = layoutResult;

    // Preserve edges for transient orphan SubmapNodes (edges whose target is an orphaned SubmapNode)
    const transientOrphanIds = new Set(transientOrphanSubmapNodes.map((n: Node) => n.id));
    const preservedOrphanEdges = transientOrphanIds.size > 0
      ? edges.filter((e: Edge) => transientOrphanIds.has(e.target))
      : [];

    /*    const newSubflowGroupNodes = adjustSubflowPositionAnsSize(
      subflowGroupNodes,
      newNodes
    ); */

    const nodesMap = newNodes.reduce(
      (acc: { [key: string]: Node }, node: Node) => {
        acc[node.id] = node;
        return acc;
      },
      {}
    );

    const subflowNodes = newNodes.filter((n: Node) => n.type === "SubflowNode");

    /*     subflowNodes.forEach((subflowNode: Node<SublfowNodeData>) => {
      const subflowGroupNode = subflowGroupNodes.find(
        (n) => n.id === subflowNode.data.model.general.subflowGroupId
      ) as Node<SubflowGroupNodeData>;
      if (!subflowGroupNode) {
        return;
      }
      subflowGroupNode.position = subflowNode.position;
      subflowGroupNode.width = subflowNode.width;
      subflowGroupNode.height = subflowNode.height;
      subflowGroupNode.hidden = true;
      subflowGroupNode.data.model.children.forEach((child) => {
        nodesMap[child.id].position = subflowNode.position;
        nodesMap[child.id].hidden = true;
      });
    });
 */
    const newNodesArray = Object.values(nodesMap) as Node[];

    const transitions = newNodesArray.map((node) => {
      return {
        id: node.id,

        from: getNode(node.id)?.position || node.position,

        to: node.position,
        node,
      };
    });

    function adjustSubmapGroupNodes(layoutedNodes: Node[], submapGroupNodes: Node[]) {
      const paddingY = 30;
      // Half the horizontal gap between nodes (orgLayout uses 150px between non-root nodes).
      // The group right border must always keep at least this clearance from any member's right edge.
      const halfHorizontalGap = 75;
      return submapGroupNodes.map((sgn) => {
        const submapId = (sgn.data as any).submapId as string | undefined;
        const instanceId = (sgn.data as any).submapInstanceId as string | undefined;
        if (!submapId || !instanceId) return sgn;

        // Find all member node IDs stored in the group node's data
        const memberNodeIds = new Set<string>((sgn.data as any).memberNodeIds as string[] ?? []);
        // Only include visible (non-hidden) members in bounding box calculation
        const memberNodes = layoutedNodes.filter((n) => memberNodeIds.has(n.id) && !n.hidden);

        if (memberNodes.length === 0) return { ...sgn, hidden: true };

        // Member nodes bounding box
        const membersMinX = Math.min(...memberNodes.map((n) => n.position.x));
        const membersMinY = Math.min(...memberNodes.map((n) => n.position.y));
        const membersMaxX = Math.max(...memberNodes.map((n) => n.position.x + (n.width || 165)));
        const membersMaxY = Math.max(...memberNodes.map((n) => n.position.y + (n.height || 140)));

        // Find start/end marker nodes for this instance
        const startMarker = layoutedNodes.find((n) => n.id === `submap-start-${submapId}-${instanceId}`);
        const endMarker = layoutedNodes.find((n) => n.id === `submap-end-${submapId}-${instanceId}`);

        // Left border: midpoint between start marker right edge and first member left edge,
        // but never greater than membersMinX - padding to ensure all members are fully contained.
        let containerLeft: number;
        if (startMarker) {
          const startMarkerRight = startMarker.position.x + (startMarker.width || 165);
          const midpoint = startMarkerRight + (membersMinX - startMarkerRight) / 2;
          containerLeft = Math.min(midpoint, membersMinX - paddingY);
        } else {
          containerLeft = membersMinX - paddingY;
        }

        // Right border: midpoint between last member right edge and end marker left edge,
        // but always at least halfHorizontalGap beyond the rightmost member to guarantee
        // sufficient clearance even when a new child node is added near the end marker.
        let containerRight: number;
        if (endMarker) {
          const endMarkerLeft = endMarker.position.x;
          const midpoint = membersMaxX + (endMarkerLeft - membersMaxX) / 2;
          containerRight = Math.max(midpoint, membersMaxX + halfHorizontalGap);
        } else {
          containerRight = membersMaxX + halfHorizontalGap;
        }

        const w = containerRight - containerLeft;
        const h = membersMaxY - membersMinY + paddingY * 2;

        return {
          ...sgn,
          hidden: false,
          position: { x: containerLeft, y: membersMinY - paddingY },
          style: { ...sgn.style, zIndex: -1 },
          data: { ...sgn.data, width: w, height: h },
        };
      });
    }

    function positionTerminalNodes(layoutedNodes: Node[], tNodes: Node[]): { nodes: Node[]; focusedIds: Set<string> } {
      const nodesById: { [id: string]: Node } = {};
      layoutedNodes.forEach((n) => { nodesById[n.id] = n; });
      const focusedIds = new Set<string>();
      const nodes = tNodes.map((tNode) => {
        const parentEdge = terminalEdges.find((e) => e.target === tNode.id);
        const parent = parentEdge ? nodesById[parentEdge.source] : undefined;
        if (parent) {
          const inFocus = (parent.data as any)?.properties?.hasFocus;
          if (inFocus) {
            focusedIds.add(tNode.id);
            // Position is relative to parent (parentId set on node), so x offset from parent's right edge
            return { ...tNode, parentId: parent.id, position: { x: (parent.width || 165) + 80, y: 0 }, hidden: false, zIndex: -1 };
          } else {
            return { ...tNode, parentId: parent.id, position: { x: (parent.width || 165) + 80, y: 0 }, hidden: true, zIndex: -1 };
          }
        }
        return tNode;
      });
      return { nodes, focusedIds };
    }

    function visibilityTerminalEdges(focusedTerminalNodeIds: Set<string>): Edge[] {
      return terminalEdges.map((e) => ({ ...e, hidden: !focusedTerminalNodeIds.has(e.target) }));
    }

    const t = timer((elapsed: number) => {
      const s = elapsed / options.duration;

      const currNodes = transitions.map(({ node, from, to }) => {
        return {
          ...node,
          position: {
            x: from.x + (to.x - from.x) * s,
            y: from.y + (to.y - from.y) * s,
          },
        };
      });

      const adjustedSubmapNodes = adjustSubmapGroupNodes(currNodes, submapGroupNodes);
      const { nodes: positionedTerminalNodes, focusedIds } = positionTerminalNodes(currNodes, terminalNodes);
      setNodes([...currNodes, ...copyNodes, ...adjustedSubmapNodes, ...positionedTerminalNodes, ...transientOrphanSubmapNodes]);
      setEdges([...newEdges, ...copyEdges, ...visibilityTerminalEdges(focusedIds), ...preservedOrphanEdges]);

      if (elapsed > options.duration) {
        const finalNodes = transitions.map(({ node, to }) => {
          return {
            ...node,
            position: {
              x: to.x,
              y: to.y,
            },
          };
        });

        const finalSubmapNodes = adjustSubmapGroupNodes(finalNodes, submapGroupNodes);
        const { nodes: finalTerminalNodes, focusedIds: finalFocusedIds } = positionTerminalNodes(finalNodes, terminalNodes);
        setNodes([...finalNodes, ...copyNodes, ...finalSubmapNodes, ...finalTerminalNodes, ...transientOrphanSubmapNodes]);

        setEdges([...newEdges, ...copyEdges, ...visibilityTerminalEdges(finalFocusedIds), ...preservedOrphanEdges]);

        t.stop();

        if (initial.current) {
          initial.current = false;
        } else if (!canvasConfig.fitView) {
          // When fitView drives the framing (Canvas.frameView), the layout must not
          // fight it with its own viewport move — two animations aiming at different
          // targets make the map visibly wander before settling.
          setViewport(
            { x: newViewport.x, y: newViewport.y, zoom: newViewport.zoom },
            { duration: newViewport.duration }
          );
        }
      }
    });
    return () => {
      t.stop();
    };
  }, [nodeCount, nodeOrder, nodeDragged, edgeOrder, layoutMode, width, height]);
}

export default useLayout;
