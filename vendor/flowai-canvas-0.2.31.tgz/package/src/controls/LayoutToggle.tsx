"use client";

import { useLayoutStore } from "../stores/useLayoutStore";

export const LayoutToggle = () => {
  const { mode, available, toggle } = useLayoutStore();

  if (available.length <= 1) return null;

  return (
    <button
      onClick={toggle}
      title={mode === "org" ? "Switch to tree layout" : "Switch to org layout"}
      className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-gray-600 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors"
    >
      {mode === "org" ? (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
          <rect x="1" y="6" width="4" height="4" rx="0.5" />
          <line x1="5" y1="8" x2="7" y2="8" />
          <rect x="7" y="2" width="4" height="4" rx="0.5" />
          <rect x="7" y="10" width="4" height="4" rx="0.5" />
          <line x1="11" y1="4" x2="14" y2="4" />
          <line x1="11" y1="12" x2="14" y2="12" />
        </svg>
      ) : (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
          <rect x="6" y="1" width="4" height="3" rx="0.5" />
          <line x1="8" y1="4" x2="8" y2="6" />
          <line x1="3" y1="6" x2="13" y2="6" />
          <line x1="3" y1="6" x2="3" y2="8" />
          <line x1="8" y1="6" x2="8" y2="8" />
          <line x1="13" y1="6" x2="13" y2="8" />
          <rect x="1" y="8" width="4" height="3" rx="0.5" />
          <rect x="6" y="8" width="4" height="3" rx="0.5" />
          <rect x="11" y="8" width="4" height="3" rx="0.5" />
        </svg>
      )}
      {mode === "org" ? "Org" : "Tree"}
    </button>
  );
};
