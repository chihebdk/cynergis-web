export type NodeConfig = {
  toolbar?: string[];
  contextMenu?: string[];
  decorators?: string[];
  showEndMarker?: boolean;
};

export type EdgeConfig = {
  stroke?: string;
  strokeWidth?: number;
  opacity?: number;
  markerEnd?: boolean;
  focusedStyle?: "solid" | "dashed";
  unfocusedStyle?: "solid" | "dashed";
  toolbar?: string[];
  // Corner radius of the orthogonal step path (px). 0 = sharp right-angle lines.
  // Defaults to 15 (rounded) when unset, preserving existing behavior.
  borderRadius?: number;
};

export type LaneConfig = {
  show?: boolean;
  laneWidth?: number;
  colors?: string[];
  opacity?: number;
  titles?: string[];
  border?: {
    show?: boolean;
    color?: string;
    strokeWidth?: number;
  };
};

export type LayoutConfig = {
  available?: string[];
  default?: string;
};

export type PropertyTabConfig = {
  tab: string;
  title: string;
  icon?: string;
  iconSize?: number;
  className?: string;
  selectedCls?: string;
};

export type MapConfig = {
  properties?: PropertyTabConfig[];
};

export type CanvasConfig = {
  node?: NodeConfig;
  edge?: EdgeConfig;
  lanes?: LaneConfig;
  layout?: LayoutConfig;
  nodeTypes?: Record<string, NodeConfig>;
  edgeTypes?: Record<string, EdgeConfig>;
  map?: MapConfig;
};
