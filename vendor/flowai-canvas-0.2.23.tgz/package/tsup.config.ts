import { defineConfig } from "tsup";

export default defineConfig({
  entry: ["src/index.ts"],
  format: ["esm", "cjs"],
  tsconfig: "tsconfig.build.json",
  dts: true,
  splitting: false,
  clean: true,
  external: ["react", "react-dom", "@xyflow/react", "@flowai/state", "@paralleldrive/cuid2"],
  esbuildOptions(options) {
    // Treat CSS files as external (Next.js handles them via transpilePackages or app CSS)
    options.loader = { ...options.loader, ".css": "copy" };
  },
});
