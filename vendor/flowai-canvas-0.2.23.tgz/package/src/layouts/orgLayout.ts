import { Node, Edge } from "@xyflow/react";
import { layoutConfig } from "../config/settings";
import { BaseNodeData } from "../types/NodeTypes";
import { swapNodes } from "../utils";

//nodes, edges, viewport
export function orgLayout(
  root: any,
  edges: any,
  width: any,
  height: any,
  viewport: any,
  changed: any
) {
  const { x, y, zoom } = viewport;
  const screenWidth = Math.floor(width / zoom);

  //Get ancestry of the selected node
  const nodes = root.descendants();
  if (changed) {
    const selectedNode = root.descendants().find((d: any) => d.data.selected);
    if (selectedNode) {
      const ancestry = selectedNode.ancestors();
      ancestry.forEach((d: any) => {
        const siblings = d.parent?.children || [];
        const firstSibling = siblings.length > 0 ? siblings[0] : null;
        if (firstSibling) {
          swapNodes(nodes, d, firstSibling);
        }
      });
    }
  }

  const newEdges: Edge[] = [];
  const newNodes: Node<BaseNodeData>[] = nodes.map((d: any) => {
    const edge = edges.find((e: any) => e.target === d.id);

    if (d.id === root.id) {
      //d is root
      d.x = layoutConfig.startNodePosition.x;
      d.y = layoutConfig.startNodePosition.y;
      d.hidden = false;
    } else if (d.parent.y !== root.y) {
      //parent not focused
      d.x = d.parent.x;
      d.y = d.parent.y;
      d.hidden = true;
      d.data.data.properties.hasFocus = false;
      newEdges.push(edge);
    } else if (d.parent.y === root.y) {
      //parent focused
      const siblings = d.parent.children || [];
      const index = siblings.indexOf(d);

      if(d.parent.id === root.id) {
        d.x = d.parent.x + d.data.width + 50;
      } else {
        d.x = d.parent.x + d.data.width + 150;
      }

      d.y = d.parent.y + index * (d.data.height + 40);
      d.hidden = false;

      edge.type = "WorkflowEdge";
      if (index === 0) {
        d.data.data.properties.hasFocus = true;
        if (edge.data.properties.isSubflowStart) {
          edge.zIndex = -10;
        } else {
          edge.zIndex = 0;
        }
        edge.data.properties.hasFocus = true;
      } else {
        d.data.data.properties.hasFocus = false;
        edge.zIndex = edge.data.properties.isError ? -1 : -2;
        edge.data.properties.hasFocus = false;
      }
      newEdges.push(edge);
    }
    return {
      ...d.data,
      position: {
        x: d.x,
        y: d.y,
      },
      hidden: d.hidden,
    };
  });

  const selectedNode = newNodes.find((node) => node.selected);
  const lastFocused = newNodes
    .filter((node) => node.data.properties.hasFocus)
    .at(-1);

  const focusNode = selectedNode || lastFocused;

  // All values in canvas coordinates (screen pixels / zoom).
  const viewportLeft = -x / zoom;
  const viewportRight = viewportLeft + screenWidth;
  const nodeWidth = (focusNode as any)?.width || 165;
  const margin = 350 / zoom;
  const nodeRightEdge = (focusNode?.position.x || 0) + nodeWidth;
  const overflow = nodeRightEdge + margin - viewportRight;
  const delta = overflow > 0 ? -overflow * zoom : 0;

  const newViewport = {
    x: x + delta,
    y: layoutConfig.initialViewport.y,
    zoom: viewport.zoom,
    duration: 300,
  };

  return { newNodes, newEdges, newViewport };
}
