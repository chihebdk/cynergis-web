// ─── Canvas Provider ─────────────────────────────────────────
export {
  CanvasServicesProvider,
  useCanvasServices,
  useNodeCache,
  useSubmapCache,
  useEventMapCache,
  useDomainCache,
  useCanvasEphemeralStore,
  useCanvasSidebar,
  useCrudClient,
  useNodeTypes,
} from "./CanvasProvider";

export type {
  NodeModel,
  SubmapModel,
  DomainModel,
  MapModel,
  CacheStore,
  CanvasCrudAdapter,
  EphemeralStoreInstance,
  HeaderComponents,
  SidebarControl,
  CanvasServices,
} from "./CanvasProvider";

// ─── UI Components ──────────────────────────────────────────
export { Canvas } from "./ui/Canvas";
export { default as CanvasWithProviders } from "./ui/CanvasWithProviders";
export { BaseNode } from "./ui/BaseNode";
export { default as Handles } from "./ui/Handles";
export { MapDesignHeader } from "./ui/MapDesignHeader";
export { SubmapNameDialog } from "./ui/SubmapNameDialog";
export { SubmapErrorDialog } from "./ui/SubmapErrorDialog";
export { SubmapNode } from "./ui/SubmapNode";
export { default as SubmapGroupNode } from "./ui/SubmapGroupNode";
export { SubmapStartNode, SubmapEndNode } from "./ui/SubmapMarkerNode";
export { TerminalNode } from "./ui/TerminalNode";
export { TerminalEdge } from "./ui/TerminalEdge";

// ─── Controls ───────────────────────────────────────────────
export { EdgeToolbar } from "./controls/EdgeToolbar";
export { NodeToolbar } from "./controls/NodeToolbar";
export { NodeContextMenu } from "./controls/NodeContextMenu";
export { DeleteNodeToolbar } from "./controls/DeleteNodeToolbar";
export { default as MoveToTopToolbar } from "./controls/MoveToTopToolbar";
export { AddSubmapPopover } from "./controls/AddSubmapPopover";
export { AddReferencePopover } from "./controls/AddReferencePopover";
export { ReferenceListPopover } from "./controls/ReferenceListPopover";
export { ReferenceNodePreview } from "./controls/ReferenceNodePreview";

// ─── Hooks ──────────────────────────────────────────────────
export { useAddNodeHandler } from "./hooks/useAddNodeHandler";
export { useAddReferenceNodeHandler } from "./hooks/useAddReferenceNodeHandler";
export { useAddSubmapHandler } from "./hooks/useAddSubmapHandler";
export { useChildrenRotationScrollHandler } from "./hooks/useChildrenRotationScrollHandler";
export { useCopyNodeHandler } from "./hooks/useCopyNodeHandler";
export { useCutNodeHandler } from "./hooks/useCutNodeHandler";
export { useDeleteNodeActions } from "./hooks/useDeleteNodeActions";
export { useDeleteNodeHandler } from "./hooks/useDeleteNodeHandler";
export { useEndNodeHandler } from "./hooks/useEndNodeHandler";
export { useFocusNode } from "./hooks/useFocusNode";
export { useInsertNodeHandler } from "./hooks/useInsertNodeHandler";
export { default as useLayout } from "./hooks/useLayout";
export { useMoveToTopHandler } from "./hooks/useMoveToTopHandler";
export { useNodeDragActionsHandler } from "./hooks/useNodeDragActionsHandler";
export { usePasteNodeHandler } from "./hooks/usePasteNodeHandler";
export { useResolveSubmapNode } from "./hooks/useResolveSubmapNode";
export { useSubmapActions } from "./hooks/useSubmapActions";
export { useSubmapHandler } from "./hooks/useSubmapHandler";

// ─── Decorators ─────────────────────────────────────────────
export { Comments } from "./decorators/Comments";
export { References } from "./decorators/References";
export { Status } from "./decorators/Status";

// ─── Types ──────────────────────────────────────────────────
export type { BaseNodeData, SubmapNodeData, SubmapMarkerNodeData, SubmapGroupNodeData } from "./types/NodeTypes";
export type { WorkflowEdgeData, BaseEdgeData } from "./types/EdgeTypes";

// ─── Config ─────────────────────────────────────────────────
export { baseNodeSize, layoutConfig } from "./config/settings";

// ─── Utils ──────────────────────────────────────────────────
export { getChainBetween, getSiblings, getDescendants, readOptions } from "./utils";
export {
  buildSubmapNode,
  buildSubmapStartMarker,
  buildSubmapEndMarker,
  buildSubmapGroupNode,
  buildCollapsedEdges,
  buildExpandedEdges,
  getSubmapNodeId,
  getSubmapStartMarkerId,
  getSubmapEndMarkerId,
  getSubmapGroupNodeId,
  extractSubmapInstanceId,
  getEdgesForNodes,
  computeCollapseSubmap,
  pickSubmapColorIndex,
  getSubmapColor,
  SUBMAP_COLORS,
  SUBMAP_COLOR_COUNT,
} from "./utils/submapUtils";
export type { SubmapColor, CollapseResult } from "./utils/submapUtils";

// ─── Layouts ────────────────────────────────────────────────
export { orgLayout } from "./layouts/orgLayout";
export { horizontalTreeLayout } from "./layouts/horizontalTreeLayout";

// ─── Stores ─────────────────────────────────────────────────
export { useDecoratorsStore } from "./stores/useDecoratorsStore";

// ─── Icons ──────────────────────────────────────────────────
export * from "./icons/index.js";
