import {
  ContextMenuItem,
} from "../../components/shadcn/context-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "../../components/shadcn/tooltip";

type MenuItemProps = {
  name: string;
  shortcut?: string;
  show?: boolean;
  tooltip?: string;
  className?: string;
  onSelect?: () => void;
  children: React.ReactNode;
};

export const MenuItem = ({
  onSelect,
  children,
  className,
  tooltip,
  name,
  shortcut: _shortcut,
  show,
}: MenuItemProps) => {
  return (
    show && (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <ContextMenuItem
              title={name}
              onClick={(e) => {e.stopPropagation(); onSelect?.()}}
              className={className}
            >
              {children}
            </ContextMenuItem>
          </TooltipTrigger>
          <TooltipContent side="right">{tooltip}</TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  );
};
