"use client";

import {
  Card,
  CardContent,
  CardHeader,
} from "../components/shadcn/card";
import { baseNodeSize } from "../config/settings";
import { useDomainCache, useNodeTypes } from "../CanvasProvider";
import { tailwindColors as colors } from "../lib/Colors";

type ReferenceNodePreviewProps = {
  node: any;
  zoom?: number;
  onClick: () => void;
};

export const ReferenceNodePreview = ({ node, zoom = 1, onClick }: ReferenceNodePreviewProps) => {
  const { getItem: getDomain } = useDomainCache();
  const nodeTypes = useNodeTypes();
  const domain = getDomain(node?.domainId);
  const color = domain?.color || "gray";

  const NodeComponent = node.type ? nodeTypes[node.type] : undefined;

  if (NodeComponent) {
    // BaseNode renders card + toolbar side-by-side (flex row).
    // We clip to card width only and center the preview in the popup.
    // Render at full size internally, scale down visually via transform on the outer wrapper.
    const cardWidth = baseNodeSize.width + 30;
    const scale = zoom * 0.9;
    const scaledWidth = Math.round(cardWidth * scale);
    const scaledHeight = Math.round(baseNodeSize.height * scale);
    return (
      <div
        className="relative cursor-pointer shrink-0 hover:scale-[1.05] transition-transform duration-150 origin-top shadow-md hover:shadow-xl rounded-lg"
        data-testid={`ref-preview-${node.id}`}
        style={{ width: scaledWidth, height: scaledHeight, overflow: "hidden" }}
      >
        <div
          className="pointer-events-none absolute top-0 left-0"
          style={{ width: cardWidth, height: baseNodeSize.height, transform: `scale(${scale})`, transformOrigin: "top left" }}
        >
          <NodeComponent
            id={node.id}
            data={{ model: node, properties: { layoutCategory: "hierarchy" } }}
            selected={false}
          />
        </div>
        <div className="absolute inset-0 cursor-pointer" onClick={onClick} />
      </div>
    );
  }

  return (
    <div
      className="cursor-pointer hover:scale-[1.05] transition-transform duration-150 origin-top shrink-0"
      data-testid={`ref-preview-${node.id}`}
      onClick={onClick}
    >
      <Card
        className="gap-0 p-0 shadow-lg hover:shadow-2xl"
        style={{
          width: Math.round(baseNodeSize.width * zoom * 0.9),
          height: Math.round(baseNodeSize.height * zoom * 0.9),
          borderColor: colors[color as keyof typeof colors]["hex-500"],
        }}
      >
        <CardHeader
          className="rounded-t-lg p-2"
          style={{
            backgroundColor: colors[color as keyof typeof colors]["hex-500"],
          }}
        >
          <div className="flex text-white text-sm w-full justify-center" style={!domain ? { color: "transparent" } : undefined}>
            {domain?.name || "TBD"}
          </div>
        </CardHeader>
        <CardContent className="h-full p-0 rounded-b-xl bg-primary-foreground mb-[2px]">
          <div className="size-full text-sm p-2 overflow-hidden">
            {node.summary || node.name || node.id}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
