"use client";

import { useState, useRef, useCallback, ReactNode } from "react";
import { useReactFlow } from "@xyflow/react";
import { useNodeCache } from "../CanvasProvider";
import { useFocusNode } from "../hooks/useFocusNode";
import {
  Dialog,
  DialogPortal,
  DialogOverlay,
} from "../components/shadcn/dialog";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { ReferenceNodePreview } from "./ReferenceNodePreview";
import { baseNodeSize } from "../config/settings";

type ReferenceListPopoverProps = {
  targetId: string;
  referenceNodes: any[];
  children: ReactNode;
};

export const ReferenceListPopover = ({
  targetId,
  referenceNodes,
  children,
}: ReferenceListPopoverProps) => {
  const [open, setOpen] = useState(false);
  const [panelPos, setPanelPos] = useState<{ top: number; left: number } | null>(null);
  const triggerRef = useRef<HTMLDivElement>(null);
  const { getViewport } = useReactFlow();
  const { getItem: getNodeModel } = useNodeCache();
  const focusNode = useFocusNode();

  const handleOpen = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    if (triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect();
      setPanelPos({ top: rect.top, left: rect.left });
    }
    setOpen(true);
  }, []);

  const zoom = getViewport().zoom;

  const handleSelect = useCallback(
    (parentId: string) => {
      setOpen(false);
      // Delay focus so the dialog close doesn't trigger a canvas click that deselects
      setTimeout(() => focusNode(parentId), 50);
    },
    [focusNode]
  );

  // For each reference node, look up its parent to show in the preview
  const previewNodes = referenceNodes.map((ref) => {
    const parent = getNodeModel(ref.parentId) as any;
    return {
      parentId: ref.parentId as string,
      displayNode: parent || ref,
    };
  });

  return (
    <>
      <div ref={triggerRef} onClick={handleOpen}>
        {children}
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogPortal>
          <DialogOverlay className="bg-transparent" />
          <DialogPrimitive.Content
            role="dialog"
            className="bg-gray-200 fixed z-50 border-2 border-dashed border-gray-600 rounded-lg shadow-none overflow-hidden p-0"
            style={{
              top: (panelPos?.top ?? 0) - 20,
              left: (panelPos?.left ?? 0) + 15,
              width: (baseNodeSize.width + 20) * zoom + 20,
            }}
            onPointerDownOutside={() => setOpen(false)}
            onEscapeKeyDown={() => setOpen(false)}
            onWheel={(e) => e.stopPropagation()}
          >
            <DialogPrimitive.Title className="sr-only">
              Reference nodes
            </DialogPrimitive.Title>
            {previewNodes.length === 0 ? (
              <p className="text-sm text-muted-foreground p-2">No references</p>
            ) : (
              <div
                className="overflow-y-auto overflow-x-hidden no-scrollbar flex justify-center"
                style={{ maxHeight: (baseNodeSize.height * 3 + 17 * 2 + 20) * zoom }}
              >
                <div
                  style={{
                    transform: `scale(${zoom})`,
                    transformOrigin: "top center",
                    width: baseNodeSize.width + 20,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: 17,
                    padding: 10,
                  }}
                >
                  {previewNodes.map(({ parentId, displayNode }) => (
                    <ReferenceNodePreview
                      key={parentId}
                      node={displayNode}
                      onClick={() => handleSelect(parentId)}
                    />
                  ))}
                </div>
              </div>
            )}
          </DialogPrimitive.Content>
        </DialogPortal>
      </Dialog>
    </>
  );
};
