export const layoutConfig = {
  startNodePosition: {
    x: 20,
    y: 65,
  },
  initialViewport: {
    x: 0,
    y: 0,
    zoom: 0.8,
  },
};

export const baseNodeSize = {
  width: 165,
  height: 140,
};

export const initialConfigPanelHeight = 500;

export const defaultNodeToolbar = [
  "addNode",
  "addCondition",
  "addError",
  "addReference",
  "addSubflow"
];

export const defaultNodeContextMenuItems = [
  "copyNode",
  "cutNode",
  "deleteNode",
  "pasteNode",
  "submapStart",
  "submapEnd",
  "markEndNode",
];
export const defaultNodeDecorators = ["Comments", "Status", "References"];
