"use client";

import "./submap.css";
import { memo } from "react";
import { NodeProps } from "@xyflow/react";
import { BaseNode } from "./BaseNode";
import Handles from "./Handles";
import { baseNodeSize } from "../config/settings";
import { getSubmapColor } from "../utils/submapUtils";
import { useSubmapCache } from "../CanvasProvider";
import { useSubmapActions } from "../hooks/useSubmapActions";
import { ExpandSubflow } from "../components/icons";
import { SubmapModel as Submap } from "../CanvasProvider";

type SubmapNodeData = {
  submapId: string;
  submapInstanceId: string;
  name: string;
  properties?: {
    hasFocus?: boolean;
    dragging?: boolean;
  };
};

const SubmapNodeComponent = ({ id, data }: NodeProps) => {
  const { submapId, submapInstanceId, name, properties } = data as unknown as SubmapNodeData;
  const { getItem: getSubmap } = useSubmapCache();
  const { expandSubmap } = useSubmapActions();
  const color = getSubmapColor(submapId, (getSubmap(submapId) as Submap | undefined)?.colorIndex);

  return (
    <BaseNode
      id={id}
      inFocus={properties?.hasFocus}
      isDragged={properties?.dragging}
      options={{ toolbar: ["addNode", "addCondition", "addError", "addReference", "addSubflow"], contextMenuItems: ["submapExpand", "markEndNode"], decorators: [] }}
    >
      <div className="flex items-center relative">
        {properties?.hasFocus && (
          <button
            type="button"
            className="absolute -top-5 right-0 hover:scale-125 transition-transform duration-200 cursor-pointer"
            title="Expand Submap"
            onClick={(e) => {
              e.stopPropagation();
              expandSubmap(submapId, submapInstanceId);
            }}
          >
            <ExpandSubflow width={16} color={color.labelColor} />
          </button>
        )}
        <div
          className="submap-card flex flex-col items-center justify-center rounded-xl border-2 shadow-lg"
          style={
            {
              width: baseNodeSize.width,
              height: baseNodeSize.height,
              "--submap-bg": color.bg,
              "--submap-border": color.border,
              "--submap-label": color.labelColor,
            } as React.CSSProperties
          }
        >
          <p className="submap-label text-sm font-medium text-center px-2 truncate max-w-[140px]">
            {name}
          </p>
          <Handles />
        </div>
      </div>
    </BaseNode>
  );
};

export const SubmapNode = memo(SubmapNodeComponent);
