"use client";

import "@xyflow/react/dist/style.css";

import React, { useCallback, useEffect, useMemo, useRef } from "react";
import {
  ReactFlow,
  Background,
  ProOptions,
  Node,
  Edge,
  useReactFlow,
} from "@xyflow/react";
import { BaseNodeData } from "../types/NodeTypes";
import { NodeTypes } from "@xyflow/react";
import { EdgeTypes } from "@xyflow/react";
import { useNodeDragActionsHandler } from "../hooks/useNodeDragActionsHandler";
import useLayout from "../hooks/useLayout";
import { useNodeCache, useDomainCache, useCanvasEphemeralStore as useEphemeralStore, useCanvasSidebar as useSidebar } from "../CanvasProvider";
import { getDescendants } from "../utils";
import { useDeleteNodeActions } from "../hooks/useDeleteNodeActions";
import { useSubmapHandler } from "../hooks/useSubmapHandler";
import { SubmapNameDialog } from "./SubmapNameDialog";
import { SubmapErrorDialog } from "./SubmapErrorDialog";
import SubmapGroupNode from "./SubmapGroupNode";
import { SubmapNode } from "./SubmapNode";
import { SubmapStartNode, SubmapEndNode } from "./SubmapMarkerNode";
const proOptions: ProOptions = { account: "paid-pro", hideAttribution: true };

type CanvasProps = {
  nodeTypes: NodeTypes;
  edgeTypes: EdgeTypes;
  nodes: Node<BaseNodeData>[];
  edges: Edge[];
  viewport?: any;
  propertiesPanel?: React.ReactNode;
};

export const Canvas: React.FC<CanvasProps> = ({
  nodeTypes,
  edgeTypes,
  nodes,
  edges,
  viewport: _viewport,
  propertiesPanel,
}) => {
  const {
    getItem: getNodeModel,
    setSelected: setSelectedNode,
    clearSelected: clearSelectedNode,
  } = useNodeCache();
  const { setSelected: setSelectedDomain, clearSelected: clearSelectedDomain } =
    useDomainCache();

  const mergedNodeTypes = useMemo(
    () => ({ ...nodeTypes, SubmapGroupNode, SubmapNode, SubmapStartNode, SubmapEndNode }),
    [nodeTypes]
  );

  const paneRef = useRef<HTMLDivElement>(null);
  const { setNodes, getNodes, getEdges } = useReactFlow();
  const { setOpen } = useSidebar();
  const { onDragStop, onDragStart } = useNodeDragActionsHandler();
  const cutStore = useEphemeralStore("cutNode");
  const refNavStore = useEphemeralStore("refNavigation");
  const { cancelDelete } = useDeleteNodeActions();
  const { cancelSubmap } = useSubmapHandler();

  const cancelCut = useCallback(() => {
    const cutNodeId = cutStore.getItem("id") as string | undefined;
    if (!cutNodeId) return;

    const nodes = getNodes();
    const edges = getEdges();
    const descendants = getDescendants(cutNodeId, nodes, edges);
    const cutIds = new Set([cutNodeId, ...descendants.map((n) => n.id)]);

    setNodes((nds) =>
      nds.map((n) =>
        cutIds.has(n.id)
          ? { ...n, data: { ...(n.data as object), properties: { ...((n.data as any).properties as object), isCut: false } } }
          : n
      )
    );

    cutStore.setItem("id", undefined);
    cutStore.setItem("descendantIds", undefined);
  }, [cutStore, getNodes, getEdges, setNodes]);

  const onNodeClick = (e: React.MouseEvent, node: Node) => {
    node.selected = true;
    closeSidebar();
    setSelectedNode(node.id);
    refNavStore.setItem("targetNodeId", undefined);
    refNavStore.setItem("refNodeId", undefined);
    if (getNodeModel(node.id)?.domainId) {
      const domainId = getNodeModel(node.id)?.domainId;
      setSelectedDomain(domainId!);
    }
  };

  const deselectAll = useCallback((e: any) => {
    if (e.target.classList.contains("react-flow__pane")) {
      setNodes((nodes) =>
        nodes.map((n) => {
          n.selected = false;
          return n;
        })
      );
      setSelectedNode(null);
      clearSelectedNode();
      setSelectedDomain(null);
      clearSelectedDomain();
      cancelCut();
      cancelDelete();
      cancelSubmap();
      refNavStore.setItem("targetNodeId", undefined);
      refNavStore.setItem("refNodeId", undefined);
    }
  }, [cancelCut, cancelDelete, cancelSubmap, refNavStore]);

  useEffect(() => {
    if (paneRef.current) {
      const pane =
        paneRef.current.getElementsByClassName("react-flow__pane")?.[0];
      pane.addEventListener("dblclick", deselectAll);
    }
  }, [paneRef, deselectAll]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        cancelCut();
        cancelDelete();
        cancelSubmap();
      }
    };
    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [cancelCut, cancelDelete, cancelSubmap]);

  const closeSidebar = () => {
    setOpen(false);
  };

  useLayout();

  return (
    <>
      <ReactFlow
        ref={paneRef}
        onPaneClick={closeSidebar}
        defaultNodes={nodes}
        defaultEdges={edges}
        nodeTypes={mergedNodeTypes}
        edgeTypes={edgeTypes}
        minZoom={0.5}
        maxZoom={0.9}
        onNodeDragStart={(e, node: Node<BaseNodeData>) => onDragStart(node)}
        onNodeDragStop={(e, node: Node<BaseNodeData>) => onDragStop(node)}
        nodeDragThreshold={3}
        zoomOnScroll={false}
        nodesDraggable={true}
        nodesConnectable={false}
        zoomOnDoubleClick={false}
        panOnScroll={false}
        deleteKeyCode={null}
        proOptions={proOptions}
        onNodeClick={onNodeClick}
        noWheelClassName="no-wheel"
      >
        <Background />

        {propertiesPanel}
      </ReactFlow>
      <SubmapNameDialog />
      <SubmapErrorDialog />
    </>
  );
};
