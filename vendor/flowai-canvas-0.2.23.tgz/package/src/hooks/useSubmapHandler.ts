"use client";

import { useCallback } from "react";
import { useReactFlow } from "@xyflow/react";
import { useCanvasEphemeralStore as useEphemeralStore } from "../CanvasProvider";
import { useSubmapCache } from "../CanvasProvider";
import { useNodeCache } from "../CanvasProvider";
import { useEventMapCache } from "../CanvasProvider";
import { getChainBetween, isEligibleSubmapEnd } from "../utils";
import { layoutConfig } from "../config/settings";
import {
  buildSubmapNode,
  buildCollapsedEdges,
  pickSubmapColorIndex,
} from "../utils/submapUtils";
import { createId } from "@paralleldrive/cuid2";
import { NodeModel as EventNode, SubmapModel as Submap } from "../CanvasProvider";

export function useSubmapHandler() {
  const { getNodes, getEdges, setNodes, setEdges } = useReactFlow();
  const submapStore = useEphemeralStore("submapMode");
  const { addItem: addSubmap, getItems: getSubmaps } = useSubmapCache();
  const { getItem: getNodeModel, getItems: getNodeItems } = useNodeCache();
  const { selected: selectedEventMap } = useEventMapCache();

  const isSubmapMode = !!submapStore.getItem("startNodeId");
  const startNodeId = submapStore.getItem("startNodeId") as string | undefined;
  const showNameDialog = !!submapStore.getItem("showNameDialog");
  const errorMessage = submapStore.getItem("errorMessage") as string | undefined;

  const startSubmap = useCallback(
    (id: string) => {
      submapStore.setItem("startNodeId", id);
      submapStore.setItem("endNodeId", undefined);
      submapStore.setItem("showNameDialog", false);
    },
    [submapStore]
  );

  const endSubmap = useCallback(
    (id: string) => {
      const startId = submapStore.getItem("startNodeId") as string | undefined;
      if (!startId) return;

      const nodes = getNodes();
      const edges = getEdges();

      if (!isEligibleSubmapEnd(id, startId, nodes, edges)) {
        console.warn("Node is not eligible as submap end");
        return;
      }

      // Rule: block if any node in the proposed chain is the target of a
      // reference node elsewhere. The user must delete the reference first.
      const chain = getChainBetween(startId, id, nodes, edges);
      const chainIds = new Set(chain.map((n) => n.id));
      const allModels = getNodeItems() as EventNode[];
      const referencingNodes = allModels.filter(
        (n) => (n as any).refNodeId && chainIds.has((n as any).refNodeId as string)
      );
      if (referencingNodes.length > 0) {
        const targetIds = new Set(
          referencingNodes.map((r) => (r as any).refNodeId as string)
        );
        const targetNames = Array.from(targetIds)
          .map((tid) => {
            const m = allModels.find((n) => n.id === tid) as any;
            return m?.summary || m?.name || tid;
          })
          .join(", ");
        submapStore.setItem("startNodeId", undefined);
        submapStore.setItem("endNodeId", undefined);
        submapStore.setItem("showNameDialog", false);
        submapStore.setItem(
          "errorMessage",
          `Cannot create submap: one or more nodes in the selection are referenced (${targetNames}). Delete the reference node(s) first, then try again.`
        );
        return;
      }

      submapStore.setItem("endNodeId", id);
      submapStore.setItem("showNameDialog", true);
    },
    [submapStore, getNodes, getEdges, getNodeItems]
  );

  const confirmSubmap = useCallback(
    (name: string, description?: string) => {
      const startId = submapStore.getItem("startNodeId") as string;
      const endId = submapStore.getItem("endNodeId") as string;
      if (!startId || !endId) return;

      const nodes = getNodes();
      const edges = getEdges();

      const chain = getChainBetween(startId, endId, nodes, edges);
      if (chain.length === 0) {
        console.error("Cannot create submap: chain is empty");
        return;
      }

      // Rule: a submap cannot contain a reference node
      const hasReference = chain.some((node) => {
        if (node.type === "ReferenceNode") return true;
        const model = getNodeModel(node.id) as any;
        return model?.type === "ReferenceNode" || !!model?.refNodeId;
      });
      if (hasReference) {
        console.error("Cannot create submap: chain contains a reference node");
        // Clear ephemeral store so the user can start over
        submapStore.setItem("startNodeId", undefined);
        submapStore.setItem("endNodeId", undefined);
        submapStore.setItem("showNameDialog", false);
        return;
      }

      // Create submap entity (starts collapsed)
      const submapId = createId();
      const instanceId = createId();
      const usedColorIndices = (getSubmaps() as Submap[]).map((s) => s.colorIndex).filter((c): c is number => c !== undefined);
      const colorIndex = pickSubmapColorIndex(usedColorIndices);
      const currentMapId = selectedEventMap?.id;
      const submapData: Submap = {
        id: submapId,
        name,
        summary: name,
        description: description || "",
        startNodeId: startId,
        endNodeId: endId,
        collapsed: true,
        colorIndex,
        mapIds: currentMapId ? [currentMapId] : [],
      };
      addSubmap(submapData as any);

      // Assign submapId to all chain nodes via proxy
      chain.forEach((node) => {
        const nodeModel = getNodeModel(node.id) as EventNode | undefined;
        if (nodeModel) {
          (nodeModel as any).submapId = submapId;
        }
      });

      const chainIds = new Set(chain.map((n) => n.id));
      const startNodePos = nodes.find((n) => n.id === startId)?.position ?? layoutConfig.startNodePosition;

      const incomingToStart = edges.find((e) => e.target === startId);
      const outgoingFromEnd = edges.filter((e) => e.source === endId);

      const newEdges = buildCollapsedEdges(submapId, instanceId, incomingToStart, outgoingFromEnd);

      // Collect all edges to remove: incoming/outgoing of chain endpoints + internal
      const internalEdgeIds = new Set(
        edges
          .filter((e) => chainIds.has(e.source) && chainIds.has(e.target))
          .map((e) => e.id)
      );
      const edgesToRemove = new Set([
        ...(incomingToStart ? [incomingToStart.id] : []),
        ...outgoingFromEnd.map((e) => e.id),
        ...internalEdgeIds,
      ]);

      setNodes((nds) => [
        buildSubmapNode(submapId, instanceId, name, startNodePos),
        ...nds.filter((n) => !chainIds.has(n.id)),
      ]);
      setEdges((eds) => [
        ...eds.filter((e) => !edgesToRemove.has(e.id)),
        ...newEdges,
      ]);

      // Clear ephemeral store
      submapStore.setItem("startNodeId", undefined);
      submapStore.setItem("endNodeId", undefined);
      submapStore.setItem("showNameDialog", false);
    },
    [submapStore, getNodes, getEdges, addSubmap, getNodeModel, setNodes, setEdges]
  );

  const cancelSubmap = useCallback(() => {
    submapStore.setItem("startNodeId", undefined);
    submapStore.setItem("endNodeId", undefined);
    submapStore.setItem("showNameDialog", false);
  }, [submapStore]);

  const clearError = useCallback(() => {
    submapStore.setItem("errorMessage", undefined);
  }, [submapStore]);

  return {
    isSubmapMode,
    startNodeId,
    showNameDialog,
    errorMessage,
    startSubmap,
    endSubmap,
    confirmSubmap,
    cancelSubmap,
    clearError,
  };
}
