"use client";

import { useCallback } from "react";
import { useReactFlow } from "@xyflow/react";
import { useSubmapCache, useEventMapCache, useNodeCache, useCrudClient, NodeModel as EventNode, SubmapModel as Submap } from "../CanvasProvider";
import { buildSubmapNode, getSubmapNodeId } from "../utils/submapUtils";
import { createId } from "@paralleldrive/cuid2";

export function useAddSubmapHandler() {
  const { setNodes, setEdges, getNode } = useReactFlow();
  const { getItem: getSubmap } = useSubmapCache();
  const { selected: selectedEventMap } = useEventMapCache();
  const { addItem: addNodeToCache, getItem: getNodeModel } = useNodeCache();
  const { find } = useCrudClient();

  const addSubmap = useCallback(
    async (parentId: string, submapId: string) => {
      const submap = getSubmap(submapId) as Submap | undefined;
      if (!submap) return;

      // Always create a new independent instance on the canvas
      const instanceId = createId();
      const submapNodeId = getSubmapNodeId(submapId, instanceId);
      const parentPosition = getNode(parentId)?.position ?? { x: 0, y: 0 };
      const submapNode = buildSubmapNode(submapId, instanceId, submap.name ?? "", parentPosition);

      const newEdge = {
        id: `${parentId}=>${submapNodeId}`,
        source: parentId,
        target: submapNodeId,
        markerEnd: "SubmapNode",
        data: { properties: { isError: false } },
      };

      setNodes((nds) => [submapNode, ...nds]);
      setEdges((eds) => [...eds, newEdge]);

      // Resolve real DB node ID if the parent is a SubmapNode (canvas-only ID).
      // extraParentNodeIds must contain real EventNode IDs so useMapInit can
      // find them in nodeIdSet on reload.
      // When the parent is a SubmapNode reference, encode the containing
      // submap's ID so reload can wire SB2(ref) to SB1(ref) instead of primary.
      // Format: "nodeId" or "nodeId|viaSubmapId" for reference disambiguation.
      let dbParentId = parentId;
      let viaSubmapId: string | undefined;
      const parentCanvasNode = getNode(parentId);
      if (parentCanvasNode?.type === "SubmapNode") {
        const parentSubmapId = (parentCanvasNode.data as any)?.submapId as string | undefined;
        if (parentSubmapId) {
          const parentSubmap = (getSubmap(parentSubmapId) as Submap | undefined);
          if (parentSubmap) {
            dbParentId = parentSubmap.endNodeId;
            // Check if parent is a reference instance (has extraParentNodeIds)
            // by looking at its incoming edge source
            const parentExtraParents = parentSubmap.extraParentNodeIds ?? [];
            if (parentExtraParents.length > 0) {
              viaSubmapId = parentSubmapId;
            }
          }
        }
      }

      // Persist the extra canvas placement so it survives refresh.
      const existing = submap.extraParentNodeIds ?? [];
      const entry = viaSubmapId ? `${dbParentId}|${viaSubmapId}` : dbParentId;
      if (!existing.includes(entry)) {
        (submap as any).extraParentNodeIds = [...existing, entry];
      }

      // Add current map to submap's mapIds if not already present
      const currentMapId = selectedEventMap?.id;
      if (currentMapId) {
        const currentMapIds = (submap as any).mapIds ?? [];
        if (!currentMapIds.includes(currentMapId)) {
          (submap as any).mapIds = [...currentMapIds, currentMapId];
        }
      }

      // Copy chain nodes from the source map so expand works in the current map.
      // Capture IDs before the await to avoid stale references.
      const sourceMapId = submap.mapIds?.[0];
      const startNodeId = submap.startNodeId;
      const endNodeId = submap.endNodeId;
      if (sourceMapId && sourceMapId !== currentMapId) {
        try {
          const sourceMaps = await find("eventMap", { id: sourceMapId });
          const sourceMap = sourceMaps[0];
          if (sourceMap?.nodes) {
            const sourceNodes = sourceMap.nodes as EventNode[];
            const sourceNodesById = new Map(sourceNodes.map((n: EventNode) => [n.id, n]));

            // Walk from startNodeId collecting the chain via parentId
            const chainNodes: EventNode[] = [];
            const visited = new Set<string>();
            function collectChain(nodeId: string) {
              if (visited.has(nodeId)) return;
              visited.add(nodeId);
              const node = sourceNodesById.get(nodeId);
              if (!node) return;
              chainNodes.push(node);
              if (nodeId === endNodeId) return;
              for (const n of sourceNodes) {
                if (n.parentId === nodeId && !visited.has(n.id)) {
                  collectChain(n.id);
                }
              }
            }
            collectChain(startNodeId);

            // Add each chain node to the current map's node cache
            for (const node of chainNodes) {
              if (!getNodeModel(node.id)) {
                // Clear createdAt so the proxy treats this as a new item and persists it
                addNodeToCache({ ...node, eventMapId: currentMapId!, createdAt: null } as any);
              }
            }
          }
        } catch (err) {
          console.error("[useAddSubmapHandler] Failed to copy chain nodes from source map:", err);
        }
      }
    },
    [setNodes, setEdges, getNode, getSubmap, selectedEventMap, find, addNodeToCache, getNodeModel]
  );

  return addSubmap;
}
