export type BaseNodeData = {
  properties: {
    selected?: boolean;
    layoutCategory: "hierarchy" | "absolute";
    ref?: React.RefObject<any>;
    hasFocus?: boolean | undefined;
    isError?: boolean;
    isDisabled?: boolean;
    dragging?: boolean;
    isCut?: boolean;
    isMarkedForDelete?: boolean;
  };
};

/** Data shape for a collapsed SubmapNode */
export type SubmapNodeData = BaseNodeData & {
  submapId: string;
  submapInstanceId: string;
  name: string;
};

/** Data shape for SubmapStartNode / SubmapEndNode markers */
export type SubmapMarkerNodeData = BaseNodeData & {
  submapId: string;
  submapInstanceId: string;
  submapName: string;
  label: string;
};

/** Data shape for SubmapGroupNode (visual container) */
export type SubmapGroupNodeData = BaseNodeData & {
  submapId: string;
  submapInstanceId: string;
  name: string;
  memberNodeIds: string[];
  width?: number;
  height?: number;
};
