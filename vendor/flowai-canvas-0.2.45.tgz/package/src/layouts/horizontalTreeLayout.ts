export function horizontalTreeLayout(
  root: any,
  edges: any,
  width: any,
  height: any,
  viewport: any,
  _changed: any
) {
  const newNodes = root.descendants().map((d: any) => {
    d.data.hidden = false;
    d.data.data.properties = {
      hasFocus: undefined,
    };
    return {
      ...d.data,
      position: { x: d.y, y: d.x },
    };
  });
  const newEdges = edges.map((edge: any) => {
    const sourceNode = newNodes.find((node: any) => node.id === edge.source);
    const targetNode = newNodes.find((node: any) => node.id === edge.target);
    if (sourceNode && targetNode) {
      edge.type = "WorkflowEdge";
      edge.data.properties.hasFocus = true;
      edge.zIndex = edge.data.properties.isError ? 1 : 2;
    }
    return edge;
  });

  // Pull the start (root) node closer to its child. Depth spacing is a uniform
  // 300px, sized for a full-width (165px) node; the Start box is much narrower, so
  // it would otherwise leave an oversized edge. Position it a fixed distance from
  // its child instead, matching the visual gap between the other nodes.
  const startNode = newNodes.find((node: any) => node.id === "start");
  if (startNode) {
    const childEdge = edges.find((edge: any) => edge.source === "start");
    const childNode =
      childEdge && newNodes.find((node: any) => node.id === childEdge.target);
    if (childNode) {
      const START_CHILD_DISTANCE = 165; // start.x → child.x (≈ one node width)
      startNode.position = {
        ...startNode.position,
        x: childNode.position.x - START_CHILD_DISTANCE,
      };
    }
  }

  const { x, y } = viewport;
  const selectedNode = newNodes.find((node: any) => node.selected);

  const heightCenter = Math.floor(height / 2);

  const newViewport = {
    x: x,
    y: heightCenter - (selectedNode?.position.y || 0) - 200,
    zoom: 1.0,
    duration: 300,
  };

  return { newNodes, newEdges, newViewport };
}
