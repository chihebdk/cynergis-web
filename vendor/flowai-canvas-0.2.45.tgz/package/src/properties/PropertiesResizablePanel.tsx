"use client";

import React, { useState, useEffect, useRef } from "react";
import { Panel } from "@xyflow/react";
import { initialConfigPanelHeight, minConfigPanelHeight } from "../config/settings";
import useWindowSize from "../hooks/useWindowSize";

type PropertiesResizablePanelProps = {
  children?: React.ReactNode;
};

export const PropertiesResizablePanel: React.FC<PropertiesResizablePanelProps> = ({ children }) => {
  const [height, setHeight] = useState(initialConfigPanelHeight);
  const resizeRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const dragStart = useRef({ y: 0, h: initialConfigPanelHeight });
  const [, windowHeight] = useWindowSize();

  useEffect(() => {
    const resizeEl = resizeRef.current;
    if (!resizeEl) return;

    // Resize relative to where the drag began, clamped only by a small floor.
    // Dragging up grows the panel, dragging down shrinks it (to minConfigPanelHeight).
    const resizeHandler = (e: MouseEvent) => {
      const delta = dragStart.current.y - e.clientY;
      const newHeight = dragStart.current.h + delta;
      setHeight(Math.max(minConfigPanelHeight, newHeight));
    };

    const addResizeListener = (e: MouseEvent) => {
      dragStart.current = {
        y: e.clientY,
        h: panelRef.current?.getBoundingClientRect().height || initialConfigPanelHeight,
      };
      window.addEventListener("mousemove", resizeHandler);
    };

    const removeResizeListener = () => {
      window.removeEventListener("mousemove", resizeHandler);
    };

    resizeEl.addEventListener("mousedown", addResizeListener);
    window.addEventListener("mouseup", removeResizeListener);

    return () => {
      resizeEl.removeEventListener("mousedown", addResizeListener);
      window.removeEventListener("mouseup", removeResizeListener);
      window.removeEventListener("mousemove", resizeHandler);
    };
  }, [windowHeight]);

  return (
    <Panel
      position="bottom-center"
      className="w-full"
      style={{ height, margin: 0 }}
      onClick={(e) => e.stopPropagation()}
    >
      <div
        ref={panelRef}
        className="flex flex-col w-full h-full bg-slate-50"
        data-testid="properties-panel"
        onClick={(e) => e.stopPropagation()}
      >
        <div
          ref={resizeRef}
          className="w-full h-1 cursor-row-resize"
          data-testid="properties-resize-handle"
        />
        {children}
      </div>
    </Panel>
  );
};
