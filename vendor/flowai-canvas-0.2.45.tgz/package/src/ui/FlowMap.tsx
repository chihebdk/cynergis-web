"use client";

import React, { useEffect, useMemo } from "react";
import { ReactFlowProvider } from "@xyflow/react";
import { useGlobalCache, useDerivedCache, useEphemeralStore, useGlobalStore, useStateConfig } from "@flowai/state";
import { CanvasServicesProvider } from "../CanvasProvider";
import type {
  CacheStore,
  NodeModel,
  SubmapModel,
  MapModel,
  DomainModel,
  CanvasCrudAdapter,
  EphemeralStoreInstance,
  CanvasServices,
} from "../CanvasProvider";
import type { CanvasConfig } from "../config/CanvasConfig";
import type { PropertiesTabConfig } from "../properties/types";
import { Canvas } from "./Canvas";
import { NodeMarker, ReferenceNodeMarker } from "../components/icons";
import { PropertiesPanel } from "../properties/PropertiesPanel";
import { useBuildFlowGraph } from "../hooks/useBuildFlowGraph";
import { builtinPropertyTabs, builtinTabComponents } from "../properties/tabs";
import { LayoutToggle } from "../controls/LayoutToggle";
import { useLayoutStore, LayoutMode } from "../stores/useLayoutStore";

// ─── Full manual-wiring props (for advanced use) ─────────────────────

export type FlowMapProps = {
  nodeCache: CacheStore<NodeModel>;
  submapCache: CacheStore<SubmapModel>;
  mapCache: CacheStore<MapModel>;
  domainCache?: CacheStore<DomainModel>;
  crudAdapter?: CanvasCrudAdapter;
  ephemeralStore: (key: string) => EphemeralStoreInstance;
  config: CanvasConfig;
  propertiesTabs?: Record<string, PropertiesTabConfig>;
  tabComponents?: Record<string, React.ComponentType>;
};

// ─── Simplified self-wiring props ────────────────────────────────────

export type FlowMapSimpleProps = {
  mapId: string;
  config: CanvasConfig;
  propertiesTabs?: Record<string, PropertiesTabConfig>;
  tabComponents?: Record<string, React.ComponentType>;
};

// ─── Inner canvas renderer (shared) ─────────────────────────────────

const FlowMapInner: React.FC<{
  config: CanvasConfig;
  propertiesTabs?: Record<string, PropertiesTabConfig>;
  tabComponents?: Record<string, React.ComponentType>;
}> = ({ config, propertiesTabs, tabComponents }) => {
  const flowGraph = useBuildFlowGraph();

  const resolvedTabs = useMemo(() => {
    if (propertiesTabs) return propertiesTabs;
    if (config.map?.properties) {
      const tabs: Record<string, PropertiesTabConfig> = {};
      for (const p of config.map.properties) {
        tabs[p.tab] = {
          title: p.title,
          icon: p.icon,
          iconSize: p.iconSize,
          tab: p.tab,
          className: p.className ?? "text-slate-500",
          selectedCls: p.selectedCls,
        };
      }
      return tabs;
    }
    return builtinPropertyTabs;
  }, [propertiesTabs, config.map?.properties]);

  const resolvedTabComponents = useMemo(() => {
    return tabComponents ?? builtinTabComponents;
  }, [tabComponents]);

  if (!flowGraph) return null;

  return (
    <Canvas
      nodes={flowGraph.nodes}
      edges={flowGraph.edges}
      viewport={flowGraph.viewport}
      propertiesPanel={
        <PropertiesPanel tabs={resolvedTabs} tabComponents={resolvedTabComponents} />
      }
    />
  );
};

// ─── FlowMap (manual wiring) ─────────────────────────────────────────

export const FlowMap: React.FC<FlowMapProps> = ({
  nodeCache,
  submapCache,
  mapCache,
  domainCache,
  crudAdapter,
  ephemeralStore,
  config,
  propertiesTabs,
  tabComponents,
}) => {
  const services: CanvasServices = useMemo(
    () => ({
      nodeCache,
      submapCache,
      mapCache,
      domainCache,
      crudAdapter,
      ephemeralStore,
      canvasConfig: config,
    }),
    [nodeCache, submapCache, mapCache, domainCache, crudAdapter, ephemeralStore, config]
  );

  return (
    <CanvasServicesProvider value={services}>
      <ReactFlowProvider>
        <NodeMarker />
        <ReferenceNodeMarker />
        <FlowMapInner
          config={config}
          propertiesTabs={propertiesTabs}
          tabComponents={tabComponents}
        />
      </ReactFlowProvider>
    </CanvasServicesProvider>
  );
};

// ─── FlowMapSelfWired (config-driven, handles its own wiring) ────────

const useNodeCacheFromMap = (map: MapModel | null) => {
  const rawMap = map ? (map as any).record || map : null;
  const nodes: (NodeModel & { id: string })[] = rawMap?.nodes || [];
  return useDerivedCache<NodeModel & { id: string }>(
    "mapNode",
    nodes,
    { parentId: map?.id || "" },
    map?.id || "none"
  );
};

export const FlowMapSelfWired: React.FC<FlowMapSimpleProps> = ({
  mapId,
  config,
  propertiesTabs,
  tabComponents,
}) => {
  const mapCache = useGlobalCache<MapModel>("map", { query: { id: mapId } });
  const { initialized, setSelected, selected: selectedMap } = mapCache;

  const nodeCache = useNodeCacheFromMap(selectedMap);
  const submapCache = useGlobalCache<SubmapModel & { id: string }>("submap", { query: {} });
  const domainCache = useGlobalStore<DomainModel & { id: string }>("domain")();

  const { crudAdapter: adapterHook } = useStateConfig();
  const adapter = adapterHook();

  useEffect(() => {
    if (!initialized) return;
    setSelected(mapId);
  }, [initialized, mapId, setSelected]);

  // Sync layout config to store
  const configureLayout = useLayoutStore((s) => s.configure);
  useEffect(() => {
    const layoutCfg = config?.layout;
    const available = (layoutCfg?.available ?? ["org", "htree"]) as LayoutMode[];
    const defaultMode = (layoutCfg?.default ?? "org") as LayoutMode;
    configureLayout(available, defaultMode);
  }, [config?.layout, configureLayout]);

  const crudAdapter: CanvasCrudAdapter = useMemo(() => ({
    find: adapter.find,
    save: adapter.save,
    remove: adapter.remove,
    pushEmbedded: adapter.pushEmbedded,
    updateEmbedded: adapter.updateEmbedded,
    pullEmbedded: adapter.pullEmbedded,
  }), [adapter]);

  const services: CanvasServices = useMemo(
    () => ({
      nodeCache: nodeCache as any,
      submapCache: submapCache as any,
      mapCache: mapCache as any,
      domainCache: domainCache as any,
      crudAdapter,
      ephemeralStore: useEphemeralStore,
      canvasConfig: config,
    }),
    [nodeCache, submapCache, mapCache, domainCache, crudAdapter, config]
  );

  return (
    <div className="flex flex-col h-full">
      <header className="flex items-center px-4 py-2 border-b bg-white">
        <p className="text-lg font-medium text-gray-600 flex-1 min-w-0 truncate">{selectedMap?.name}</p>
        <div className="flex-1 flex justify-center"><LayoutToggle /></div>
        <div className="flex-1" />
      </header>

      {selectedMap && (
        <div className="w-full flex-1 min-h-0 overflow-hidden">
          <CanvasServicesProvider value={services}>
            <ReactFlowProvider>
              <NodeMarker />
              <ReferenceNodeMarker />
              <FlowMapInner
                config={config}
                propertiesTabs={propertiesTabs}
                tabComponents={tabComponents}
              />
            </ReactFlowProvider>
          </CanvasServicesProvider>
        </div>
      )}
    </div>
  );
};
