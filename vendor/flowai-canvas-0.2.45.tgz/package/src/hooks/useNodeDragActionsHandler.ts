"use client";

import { useCallback } from "react";
import { useReactFlow } from "@xyflow/react";
import { getSiblings } from "../utils";
import { BaseNodeData } from "../types/NodeTypes";
import { Node } from "@xyflow/react";

export function useNodeDragActionsHandler() {
  const { getEdges, getNodes, setNodes } = useReactFlow();

  const onDragStart = useCallback((node: Node<BaseNodeData>) => {
    node.data.properties.dragging = true;
  }, []);

  // Reorder a node among its siblings based on WHERE it was dropped (its vertical
  // center relative to the siblings), rather than requiring it to geometrically
  // overlap exactly two of them. This makes "drop between two siblings" reliable
  // in any layout / spacing, and also handles drop-above-first and drop-below-last.
  const onDragStop = useCallback((node: Node<BaseNodeData>) => {
    node.data.properties.dragging = false;

    const siblings = getSiblings(node, getNodes(), getEdges());
    if (!siblings || siblings.length === 0) return;

    const heightOf = (n: any) => n.measured?.height ?? n.height ?? 0;
    const centerY = (n: any) => n.position.y + heightOf(n) / 2;

    const dropCenter = centerY(node);
    const sorted = [...siblings].sort((a, b) => centerY(a) - centerY(b));
    // the first sibling that sits below the drop point → insert the node before it
    const before = sorted.find((s) => dropCenter < centerY(s));

    setNodes((nodes) => {
      const others = nodes.filter((n) => n.id !== node.id);
      let insertIndex: number;
      if (before) {
        insertIndex = others.findIndex((n) => n.id === before.id);
      } else {
        const last = sorted[sorted.length - 1];
        insertIndex = others.findIndex((n) => n.id === last.id) + 1;
      }
      const next = [...others];
      next.splice(insertIndex, 0, node);
      // only commit if the sibling order actually changed (avoid churn on a nudge)
      const changed = next.some((n, i) => n.id !== nodes[i]?.id);
      return changed ? next : nodes;
    });
  }, [getNodes, getEdges, setNodes]);

  return { onDragStart, onDragStop };
}
