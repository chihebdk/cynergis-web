"use client";

import { useEffect, useRef } from "react";
import { useGlobalStore, State, Actions } from "./useGlobalStore";
import { proxy as proxyObj } from "./proxy";
import { useStateConfig } from "./StateProvider";
import { BaseEntity, EmbeddedContext } from "./types";

// Track last query key per store to detect query changes across navigations
const lastQueryKeys = new Map<string, string>();

type GlobalCacheProps = {
  query?: {};
  key?: string;
};

export type Store<T extends BaseEntity> = State<T> & Actions<T>;

/**
 * Cache for top-level entities (flow, domain, schema, resource, etc.)
 * Fetches data from the API and wraps items with proxy for auto-save.
 */
export const useGlobalCache = <T extends BaseEntity>(
  entity: string,
  props?: GlobalCacheProps
): Store<T> => {
  const config = useStateConfig();
  const { find } = config.crudAdapter();
  const store = useGlobalStore<T>(entity, props?.key)();
  const loadingRef = useRef(false);

  const queryKey = props?.query ? JSON.stringify(props.query) : undefined;
  const cacheKey = `${entity}-${props?.key || entity}`;

  const makeProxy = (item: T) =>
    proxyObj<T>({ entity, obj: item, store, config });

  useEffect(() => {
    if (!queryKey || loadingRef.current) return;

    // Re-fetch when returning to a broader query (e.g. single-item view → full list)
    const lastQueryKey = lastQueryKeys.get(cacheKey);
    const queryChanged = lastQueryKey !== undefined && lastQueryKey !== queryKey;
    const query = JSON.parse(queryKey);
    const isBroaderQuery = queryChanged && Object.keys(query).length < Object.keys(JSON.parse(lastQueryKey!)).length;
    if (store.initialized && !isBroaderQuery) return;

    let cancelled = false;
    loadingRef.current = true;
    store.setLoading(true);
    store.setError(null);

    find(entity, query)
      .then((items) => {
        if (cancelled) return;
        const asItems = items.map((item: T) => makeProxy(item));
        store.init(asItems);
        lastQueryKeys.set(cacheKey, queryKey);
        loadingRef.current = false;
        store.setLoading(false);
      })
      .catch((err) => {
        if (cancelled) return;
        loadingRef.current = false;
        store.setLoading(false);
        store.setError(err instanceof Error ? err.message : "Failed to load data");
      });

    return () => {
      cancelled = true;
    };
  }, [entity, queryKey, props?.key]);

  return {
    init: store.init,
    items: store.items,
    initialized: store.initialized,
    isLoading: store.isLoading,
    error: store.error,
    getItem: store.getItem,
    getItems: store.getItems,
    addItem: (item: T, transient = false) =>
      proxyObj<T>({ entity, obj: item, store, config, transient }),
    deleteItem: store.deleteItem,
    updateItem: (item: T) => store.updateItem(makeProxy(item)),
    selected: store.selected,
    selectedMulti: store.selectedMulti,
    removeSelected: store.removeSelected,
    setSelected: store.setSelected,
    addSelected: store.addSelected,
    clearSelected: store.clearSelected,
    filterItems: store.filterItems,
    clear: store.clear,
    setLoading: store.setLoading,
    setError: store.setError,
  };
};

/**
 * Derived cache for embedded entities (nodes inside flows, tables inside domains, etc.)
 * Reads data from a parent document's array field and wraps with proxy for embedded CRUD.
 */
export const useDerivedCache = <T extends BaseEntity>(
  entity: string,
  items: T[],
  embeddedContext: EmbeddedContext,
  cacheKey: string
): Store<T> => {
  const config = useStateConfig();
  const store = useGlobalStore<T>(entity, cacheKey)();

  const makeProxy = (item: T) =>
    proxyObj<T>({ entity, obj: item, store, config, embeddedContext });

  // Initialize from parent document on first load only.
  // After init, the store is the source of truth —
  // addItem/deleteItem handle mutations directly.
  useEffect(() => {
    if (store.initialized) return;

    const proxiedItems = items.map((item) => makeProxy(item));
    store.init(proxiedItems);
  }, [store.initialized]);

  return {
    init: store.init,
    items: store.items,
    initialized: store.initialized,
    isLoading: store.isLoading,
    error: store.error,
    getItem: store.getItem,
    getItems: store.getItems,
    addItem: (item: T, transient = false) =>
      proxyObj<T>({ entity, obj: item, store, config, transient, embeddedContext }),
    deleteItem: store.deleteItem,
    updateItem: (item: T) => store.updateItem(makeProxy(item)),
    selected: store.selected,
    selectedMulti: store.selectedMulti,
    removeSelected: store.removeSelected,
    setSelected: store.setSelected,
    addSelected: store.addSelected,
    clearSelected: store.clearSelected,
    filterItems: store.filterItems,
    clear: store.clear,
    setLoading: store.setLoading,
    setError: store.setError,
  };
};
