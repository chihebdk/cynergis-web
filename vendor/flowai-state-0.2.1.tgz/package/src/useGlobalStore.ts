import { create, StoreApi, UseBoundStore } from "zustand";

export type ID = { id: string };

export type State<T extends ID> = {
  items: Record<string, T>;
  selected: T | null;
  selectedMulti: T[];
  initialized: boolean;
  isLoading: boolean;
  error: string | null;
};

export type Actions<T extends ID> = {
  init: (items: T[]) => void;
  getItems: () => T[];
  getItem: (id: string | null | undefined) => T | undefined;
  addItem: (item: T, transient?: boolean) => T;
  updateItem: (updatedItem: T) => void;
  deleteItem: (id: string) => void;
  setSelected: (id: string | null) => void;
  addSelected: (id: string) => void;
  removeSelected: (id: string) => void;
  clearSelected: () => void;
  clear: () => void;
  filterItems: (predicate: (item: T) => boolean) => T[];
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
};

export interface GlobalStore<T extends ID> extends State<T>, Actions<T> {}

const stores = new Map<string, UseBoundStore<StoreApi<any>>>();

export const useGlobalStore = <T extends ID>(
  entity: string,
  key?: string
) => {
  const cacheKey = `${entity}-${key || entity}`;
  if (!stores.has(cacheKey)) {
    const store = create<GlobalStore<T>>((set, get) => ({
      items: {} as Record<T["id"], T>,
      selected: null,
      selectedMulti: [],
      initialized: false,
      isLoading: false,
      error: null,

      setLoading: (loading: boolean) => set({ isLoading: loading }),
      setError: (error: string | null) => set({ error }),

      clear: () =>
        set({
          items: {},
          initialized: false,
          isLoading: false,
          error: null,
          selected: null,
          selectedMulti: [],
        }),

      getItems: () => Object.values(get().items),

      getItem: (id: string | null | undefined) => {
        if (!id) return undefined;
        return get().items[id];
      },

      setSelected: (id: string | null) => {
        set({ selected: id ? get().items[id] : null });
      },

      addSelected: (id: string) => {
        set((state) => ({
          selectedMulti: [...state.selectedMulti, get().items[id]],
        }));
      },

      removeSelected: (id: string) =>
        set((state) => ({
          selectedMulti: state.selectedMulti.filter((item) => item.id !== id),
        })),

      clearSelected: () => set({ selected: null, selectedMulti: [] }),

      init: (items: T[]) => {
        set((_state) => ({
          items: items.reduce(
            (acc, item) => ({
              ...acc,
              [item.id]: item,
            }),
            {} as Record<T["id"], T>
          ),
          initialized: true,
        }));
        set({ selected: null, selectedMulti: [] });
      },

      addItem: (item: T) => {
        set((state) => ({
          items: { ...state.items, [item.id]: item },
        }));
        return item;
      },

      updateItem: (item: T) =>
        set((state) => ({
          items: { ...state.items, [item.id]: item },
        })),

      deleteItem: (id: string) =>
        set((state) => ({
          items: {
            ...Object.fromEntries(
              Object.entries(state.items).filter(([key]) => key !== id)
            ),
          },
          selected: state.selected?.id === id ? null : state.selected,
          selectedMulti: state.selectedMulti.filter((item) => item.id !== id),
        })),

      filterItems: (predicate: (item: T) => boolean) => {
        return Object.values(get().items).filter(predicate);
      },
    }));
    stores.set(cacheKey, store);
  }

  const store = stores.get(cacheKey) as
    | UseBoundStore<StoreApi<GlobalStore<T>>>
    | undefined;
  if (!store) {
    throw new Error(`Store with key "${cacheKey}" not found`);
  }
  return store;
};
