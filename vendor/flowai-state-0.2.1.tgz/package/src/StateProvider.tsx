"use client";

import { createContext, useContext, ReactNode } from "react";
import { StateConfig } from "./types";

const StateConfigContext = createContext<StateConfig | null>(null);

export const useStateConfig = (): StateConfig => {
  const config = useContext(StateConfigContext);
  if (!config) {
    throw new Error("useStateConfig must be used within a StateProvider");
  }
  return config;
};

export const StateProvider = ({
  config,
  children,
}: {
  config: StateConfig;
  children: ReactNode;
}) => {
  return (
    <StateConfigContext.Provider value={config}>
      {children}
    </StateConfigContext.Provider>
  );
};
