"use client";

import { create, StoreApi, UseBoundStore } from "zustand";

type State = {
  items: Record<string, unknown>;
};

type Actions = {
  setItem: (key: string, value: unknown) => void;
  getItem: (key: string) => unknown;
  readOnce: (key: string) => unknown;
};

const initialState: State = {
  items: {},
};

export interface EphemeralStore extends State, Actions {}

const stores = new Map<string, UseBoundStore<StoreApi<any>>>();

export const useEphemeralStore = (mapKey: string) => {
  if (!stores.has(mapKey)) {
    const store = create<EphemeralStore>((set, get) => ({
      ...initialState,
      setItem: (key: string, value: unknown) => {
        console.log("setItem: ", key, value);
        set({ items: { ...get().items, [key]: value } });
      },
      getItem: (key: string) => get().items[key],
      readOnce: (key: string) => {
        const value = get().items[key];
        get().items[key] = undefined;
        return value;
      },
    }));
    stores.set(mapKey, store);
  }

  const store = stores.get(mapKey) as
    | UseBoundStore<StoreApi<EphemeralStore>>
    | undefined;
  if (!store) {
    throw new Error(`Store with key "${mapKey}" not found`);
  }
  return store();
};
