// ─── Types ───────────────────────────────────────────────────
export type {
  EntityConfig,
  EmbeddedEntityConfig,
  EntityRegistry,
  EmbeddedContext,
  CrudAdapter,
  StateConfig,
  BaseEntity,
  ProxyEntity,
} from "./types";

// ─── Provider ────────────────────────────────────────────────
export { StateProvider, useStateConfig } from "./StateProvider";

// ─── Stores ──────────────────────────────────────────────────
export { useGlobalStore } from "./useGlobalStore";
export type { ID, State, Actions, GlobalStore } from "./useGlobalStore";

export { useGlobalCache, useDerivedCache } from "./useGlobalCache";
export type { Store } from "./useGlobalCache";

export { useEphemeralStore } from "./useEphemeralStore";
export type { EphemeralStore } from "./useEphemeralStore";

// ─── Proxy ───────────────────────────────────────────────────
export { proxy } from "./proxy";
