import { GlobalStore } from "./useGlobalStore";
import { StateConfig, EmbeddedContext } from "./types";
import { createId } from "@paralleldrive/cuid2";

// Track active autosave intervals so they can be cleaned up
const activeIntervals = new Map<string, ReturnType<typeof setInterval>>();

// Track dirty proxies for flush-on-unload
const activeProxies = new Map<string, { proxy: any; save: (record: any) => void }>();

if (typeof window !== "undefined") {
  window.addEventListener("beforeunload", () => {
    for (const [, { proxy, save }] of activeProxies) {
      if (proxy.dirty) {
        save(proxy.record);
        proxy.dirty = false;
      }
    }
  });
}

export const proxy = <T extends { id: string }>({
  entity,
  obj,
  store,
  config,
  transient = false,
  embeddedContext,
  existing = false,
}: {
  entity: string;
  obj: (T & any) | undefined | null;
  store: GlobalStore<T>;
  config: StateConfig;
  transient?: boolean;
  embeddedContext?: EmbeddedContext;
  existing?: boolean;
}) => {
  const { save, remove, pushEmbedded, updateEmbedded, pullEmbedded } =
    config.crudAdapter();

  const structure =
    config.registry.entities[entity]?.fields ??
    config.registry.embeddedEntities[entity]?.fields ??
    [];

  const isEmbedded = entity in config.registry.embeddedEntities;

  const validators = config.registry.validators;
  const autosaveInterval = config.autosaveInterval ?? 5000;

  // ─── Save/remove adapters based on entity type ──────────────

  const doSave = (record: any) => {
    if (isEmbedded && embeddedContext) {
      updateEmbedded(
        entity,
        embeddedContext.parentId,
        record,
        embeddedContext.parentEmbeddedId
      ).catch((err: any) => console.error(`[proxy] updateEmbedded failed for ${entity}:`, err));
    } else {
      save(entity, record)
        .catch((err: any) => console.error(`[proxy] save failed for ${entity}:`, err));
    }
  };

  const doCreate = (record: any) => {
    if (isEmbedded && embeddedContext) {
      pushEmbedded(
        entity,
        embeddedContext.parentId,
        record,
        embeddedContext.parentEmbeddedId
      ).catch((err: any) => console.error(`[proxy] pushEmbedded failed for ${entity}:`, err));
    } else {
      save(entity, record)
        .catch((err: any) => console.error(`[proxy] save failed for ${entity}:`, err));
    }
  };

  const doRemove = (id: string) => {
    if (isEmbedded && embeddedContext) {
      pullEmbedded(
        entity,
        embeddedContext.parentId,
        id,
        embeddedContext.parentEmbeddedId
      );
    } else {
      remove(entity, id);
    }
  };

  // ─── Proxy object ──────────────────────────────────────────

  const proxyObj = {
    id: obj?.id,
    dirty: false,
    record: obj || {},
    persisted: existing || (obj?.createdAt ? true : false),
    changeUUID: "",
    embeddedContext,
    init: () => {
      if (!obj.createdAt) {
        store.addItem(proxyObj);
        obj.createdAt = new Date();

        if (!existing && !transient && proxyObj.isValid()) {
          proxyObj.persisted = true;
          doCreate(obj);
        }
      }
    },
    delete: () => {
      proxyObj.dispose();
      doRemove(proxyObj.record.id);
      store.deleteItem(proxyObj.record.id);
    },
    discard: () => {
      proxyObj.dispose();
      store.deleteItem(proxyObj.record.id);
    },
    dispose: () => {
      const intervalKey = `${entity}-${obj?.id}`;
      const interval = activeIntervals.get(intervalKey);
      if (interval) {
        clearInterval(interval);
        activeIntervals.delete(intervalKey);
      }
      activeProxies.delete(intervalKey);
    },
    changed: () => {
      proxyObj.changeUUID = createId();
    },
    persist: () => {
      store.updateItem(proxyObj);
      if (!transient && proxyObj.isValid()) {
        if (!proxyObj.persisted) {
          proxyObj.record.updatedAt = new Date();
          doCreate(proxyObj.record);
          proxyObj.persisted = true;
        } else {
          proxyObj.dirty = true;
        }
      }
    },
    isValid: () => {
      let valid = true;
      structure.forEach((key) => {
        const validator = validators?.[key];
        valid =
          valid &&
          (!validator
            ? true
            : validator.safeParse(proxyObj.record[key]).success);
      });
      return valid;
    },
  } as T & any;

  // Clean up any existing interval for this entity instance
  const intervalKey = `${entity}-${obj?.id}`;
  const existingInterval = activeIntervals.get(intervalKey);
  if (existingInterval) {
    clearInterval(existingInterval);
  }

  if (!transient) {
    const interval = setInterval(() => {
      if (proxyObj.dirty) {
        doSave(proxyObj.record);
        proxyObj.dirty = false;
      }
    }, autosaveInterval);
    activeIntervals.set(intervalKey, interval);
    activeProxies.set(intervalKey, { proxy: proxyObj, save: doSave });
  }

  proxyObj.init();

  structure.forEach((key) => {
    Object.defineProperty(proxyObj, key, {
      get() {
        return proxyObj.record[key];
      },
      set(value) {
        proxyObj.record[key] = value;
        proxyObj.persist();
      },
    });
  });

  return proxyObj as T;
};
