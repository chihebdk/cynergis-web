import { ZodSchema } from "zod";

// ─── Entity Registry ──────────────────────────────────────────

export type EntityConfig = {
  collection: string;
  fields: readonly string[];
};

export type EmbeddedEntityConfig = {
  rootCollection: string;
  arrayField: string;
  parentEmbedded?: string;
  parentArrayField?: string;
  fields: readonly string[];
};

export type EntityRegistry = {
  entities: Record<string, EntityConfig>;
  embeddedEntities: Record<string, EmbeddedEntityConfig>;
  validators?: Record<string, ZodSchema>;
};

// ─── Embedded Context ─────────────────────────────────────────

export type EmbeddedContext = {
  parentId: string;
  parentEmbeddedId?: string;
};

// ─── CRUD Adapter ─────────────────────────────────────────────

export type CrudAdapter = {
  find: (entity: string, filter?: Record<string, unknown>) => Promise<any[]>;
  save: (entity: string, data: Record<string, any>) => Promise<void>;
  remove: (entity: string, id: string) => Promise<void>;
  pushEmbedded: (entity: string, parentId: string, data: Record<string, any>, parentEmbeddedId?: string) => Promise<void>;
  updateEmbedded: (entity: string, parentId: string, data: Record<string, any>, parentEmbeddedId?: string) => Promise<void>;
  pullEmbedded: (entity: string, parentId: string, itemId: string, parentEmbeddedId?: string) => Promise<void>;
};

// ─── State Config ─────────────────────────────────────────────

export type StateConfig = {
  registry: EntityRegistry;
  crudAdapter: () => CrudAdapter;
  autosaveInterval?: number; // default 5000
  scope?: string; // namespace for store isolation (e.g. databaseName)
};

// ─── Base Entity ──────────────────────────────────────────────

export type BaseEntity = {
  id: string;
  name?: string;
  createdAt?: Date | string;
  updatedAt?: Date | string;
  [key: string]: any;
};

// ─── Proxy Entity ─────────────────────────────────────────────

export type ProxyEntity = {
  persisted: boolean;
  dirty: boolean;
  record: Record<string, any>;
  changeUUID: string;
  embeddedContext?: EmbeddedContext;
  init: () => void;
  delete: () => void;
  discard: () => void;
  dispose: () => void;
  changed: () => void;
  persist: () => void;
  isValid: () => boolean;
};
