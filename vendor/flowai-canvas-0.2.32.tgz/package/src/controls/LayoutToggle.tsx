"use client";

import { useLayoutStore } from "../stores/useLayoutStore";

const OrgIcon = () => (
  <svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
    <rect x="1" y="6" width="4" height="4" rx="0.5" />
    <line x1="5" y1="8" x2="7" y2="8" />
    <rect x="7" y="2" width="4" height="4" rx="0.5" />
    <rect x="7" y="10" width="4" height="4" rx="0.5" />
    <line x1="11" y1="4" x2="14" y2="4" />
    <line x1="11" y1="12" x2="14" y2="12" />
  </svg>
);

const TreeIcon = () => (
  <svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
    <rect x="6" y="1" width="4" height="3" rx="0.5" />
    <line x1="8" y1="4" x2="8" y2="6" />
    <line x1="3" y1="6" x2="13" y2="6" />
    <line x1="3" y1="6" x2="3" y2="8" />
    <line x1="8" y1="6" x2="8" y2="8" />
    <line x1="13" y1="6" x2="13" y2="8" />
    <rect x="1" y="8" width="4" height="3" rx="0.5" />
    <rect x="6" y="8" width="4" height="3" rx="0.5" />
    <rect x="11" y="8" width="4" height="3" rx="0.5" />
  </svg>
);

// Segmented 2-button group (Org | Tree). Each button selects its layout directly.
export const LayoutToggle = () => {
  const { mode, available, setMode } = useLayoutStore();

  if (available.length <= 1) return null;

  const seg = (active: boolean) =>
    `flex items-center gap-1.5 px-3 py-1 text-sm font-medium rounded-[5px] transition-colors ${
      active ? "bg-white text-gray-800 shadow-sm" : "text-gray-500 hover:text-gray-700"
    }`;

  return (
    <div className="inline-flex items-center gap-0.5 rounded-md bg-gray-100 p-0.5">
      <button type="button" onClick={() => setMode("org")} className={seg(mode === "org")} title="Org layout" aria-pressed={mode === "org" ? "true" : "false"}>
        <OrgIcon /> Org
      </button>
      <button type="button" onClick={() => setMode("htree")} className={seg(mode === "htree")} title="Tree layout" aria-pressed={mode === "htree" ? "true" : "false"}>
        <TreeIcon /> Tree
      </button>
    </div>
  );
};
