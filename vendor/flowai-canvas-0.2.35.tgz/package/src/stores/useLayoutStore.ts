import { create } from "zustand";

export type LayoutMode = "org" | "htree";

type LayoutState = {
  mode: LayoutMode;
  available: LayoutMode[];
  setMode: (mode: LayoutMode) => void;
  toggle: () => void;
  configure: (available: LayoutMode[], defaultMode: LayoutMode) => void;
};

export const useLayoutStore = create<LayoutState>()((set, get) => ({
  mode: "org",
  available: ["org", "htree"],
  setMode: (mode) => set({ mode }),
  toggle: () =>
    set((s) => {
      const idx = s.available.indexOf(s.mode);
      const next = s.available[(idx + 1) % s.available.length];
      return { mode: next };
    }),
  configure: (available, defaultMode) => {
    const current = get();
    if (
      current.available.length !== available.length ||
      !current.available.every((v, i) => v === available[i])
    ) {
      set({ available, mode: defaultMode });
    }
  },
}));
